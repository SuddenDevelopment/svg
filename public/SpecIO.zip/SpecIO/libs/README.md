# SVGElements Library

This directory is intended to contain the SVGElements Python library for SVG processing.

## Installation

To include the SVGElements library in this addon:

1. Download or clone the SVGElements library from: https://github.com/meerk40t/svgelements
2. Copy the `svgelements` package directory into this `libs/` folder
3. The structure should be: `libs/svgelements/__init__.py` etc.

## Usage

The library can be imported in the addon code as:

```python
from .libs import svgelements
```

or

```python
import sys
import os
libs_path = os.path.join(os.path.dirname(__file__), "libs")
if libs_path not in sys.path:
    sys.path.append(libs_path)

import svgelements
```

## Note

The SVGElements library is not included in this repository to avoid licensing conflicts.
Users should install it separately according to their needs and local licensing requirements.
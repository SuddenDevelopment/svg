"""Properties and preferences for SpecIO addon."""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import AddonPreferences, PropertyGroup


def _addon_preferences() -> AddonPreferences | None:
    addon = bpy.context.preferences.addons.get("SpecIO") if bpy.context.preferences else None
    return addon.preferences if addon else None


_SCENE_TO_PREFERENCE_DEFAULTS = {
    "import_scale": "default_import_scale",
    "import_resolution": "default_resolution",
    "import_height_mode": "default_import_height_mode",
    "import_height_step": "default_import_height_step",
    "import_stroke_overlay_offset": "default_import_stroke_overlay_offset",
    "import_intelligent_split_paths": "default_import_intelligent_split_paths",
    "export_scale": "default_export_scale",
    "export_precision": "precision",
    "export_default_fill_color": "default_export_fill_color",
    "export_default_stroke_color": "default_export_stroke_color",
    "export_apply_stroke": "default_export_apply_stroke",
    "export_stroke_width": "default_export_stroke_width",
    "export_cull_to_camera": "default_export_cull_to_camera",
    "export_mesh_color_mode": "default_export_mesh_color_mode",
}


def _scene_property_default(name: str):
    property_definition = SpecIOSceneProperties.bl_rna.properties[name]
    default_array = getattr(property_definition, "default_array", None)
    if default_array and len(default_array) > 0:
        return tuple(default_array)
    return property_definition.default


def _default_setting_value(name: str, prefs: AddonPreferences | None):
    preference_name = _SCENE_TO_PREFERENCE_DEFAULTS.get(name)
    if prefs is not None and preference_name is not None:
        return getattr(prefs, preference_name)
    return _scene_property_default(name)


def _iter_registered_scenes():
    scenes = getattr(bpy.data, "scenes", None)
    if scenes is None:
        return ()
    return tuple(scenes)


def apply_preferences_to_scene(scene: bpy.types.Scene, force: bool = False) -> None:
    """Initialize a scene's SpecIO settings from addon preferences once."""
    prefs = _addon_preferences()
    settings = getattr(scene, "specio", None)
    if settings is None:
        return

    if settings.defaults_initialized and not force:
        return

    settings.import_scale = _default_setting_value("import_scale", prefs)
    settings.import_resolution = _default_setting_value("import_resolution", prefs)
    settings.import_height_mode = _default_setting_value("import_height_mode", prefs)
    settings.import_height_step = _default_setting_value("import_height_step", prefs)
    settings.import_stroke_overlay_offset = _default_setting_value("import_stroke_overlay_offset", prefs)
    settings.import_intelligent_split_paths = _default_setting_value("import_intelligent_split_paths", prefs)
    settings.export_scale = _default_setting_value("export_scale", prefs)
    settings.export_precision = _default_setting_value("export_precision", prefs)
    settings.export_default_fill_color = _default_setting_value("export_default_fill_color", prefs)
    settings.export_default_stroke_color = _default_setting_value("export_default_stroke_color", prefs)
    settings.export_apply_stroke = _default_setting_value("export_apply_stroke", prefs)
    settings.export_stroke_width = _default_setting_value("export_stroke_width", prefs)
    settings.export_cull_to_camera = _default_setting_value("export_cull_to_camera", prefs)
    settings.export_mesh_color_mode = _default_setting_value("export_mesh_color_mode", prefs)
    settings.defaults_initialized = True


def _update_material_gradient(self, context):
    material = getattr(self, "id_data", None)
    if material is None or material.get("_specio_suspend_gradient_updates"):
        return

    from ..io_svg.gradient_materials import sync_specio_gradient_material

    sync_specio_gradient_material(material)


class SpecIOPreferences(AddonPreferences):
    """Addon-wide preferences for SpecIO."""

    bl_idname = "SpecIO"

    # Default settings
    default_import_scale: FloatProperty(
        name="Default Import Scale",
        description="Default scale factor for imported SVG files",
        default=1.0,
        min=0.001,
        max=1000.0,
    )
    
    default_export_scale: FloatProperty(
        name="Default Export Scale", 
        description="Default scale factor for exported SVG files",
        default=1.0,
        min=0.001,
        max=1000.0,
    )
    
    default_resolution: IntProperty(
        name="Default Resolution",
        description="Default resolution for SVG import",
        default=64,
        min=1,
        max=512,
    )

    default_import_height_mode: EnumProperty(
        name="Default Height Mode",
        description="Default Z placement mode for imported SVG objects",
        items=(
            ("FLAT", "Flat", "Import all objects on the same Z height"),
            ("PER_OBJECT", "Per Object", "Offset each imported object by a fixed Z step"),
            ("PER_LAYER", "Per Layer", "Offset imported objects by top-level SVG layer"),
        ),
        default="PER_OBJECT",
    )

    default_import_height_step: FloatProperty(
        name="Default Height Step Ratio",
        description="Default Z step ratio relative to the imported SVG size; 0.001 is about 0.1% of the document size",
        default=0.001,
        min=0.0,
        max=100.0,
    )

    default_import_stroke_overlay_offset: FloatProperty(
        name="Default Stroke Overlay Ratio",
        description="Default extra Z ratio relative to the imported SVG size used to place synthetic stroke helpers above fills",
        default=0.001,
        min=0.0,
        max=100.0,
    )

    default_import_intelligent_split_paths: BoolProperty(
        name="Default Intelligent Split Paths",
        description="Split complex evenodd paths into local contour families during import when that better matches SVG rendering",
        default=True,
    )
    
    precision: IntProperty(
        name="Precision",
        description="Decimal precision for SVG export",
        default=3,
        min=0,
        max=10,
    )

    default_export_fill_color: FloatVectorProperty(
        name="Default Fill Color",
        description="Fallback SVG fill color used when an exported object has no preserved SVG fill or Blender material color",
        default=(0.5, 0.5, 0.5),
        size=3,
        min=0.0,
        max=1.0,
        subtype='COLOR',
    )

    default_export_stroke_color: FloatVectorProperty(
        name="Default Stroke Color",
        description="Stroke color applied during export when export stroke is enabled and the object has no explicit SVG stroke",
        default=(0.0, 0.0, 0.0),
        size=3,
        min=0.0,
        max=1.0,
        subtype='COLOR',
    )

    default_export_apply_stroke: BoolProperty(
        name="Apply Stroke On Export",
        description="Add a default SVG stroke to exported objects that do not already have one",
        default=False,
    )

    default_export_stroke_width: FloatProperty(
        name="Default Stroke Width",
        description="Stroke width used when export stroke is enabled",
        default=1.0,
        min=0.001,
        max=1000.0,
    )

    default_export_cull_to_camera: BoolProperty(
        name="Cull to Camera on Export",
        description="Skip geometry entirely outside the camera viewport during export",
        default=True,
    )

    default_export_mesh_color_mode: EnumProperty(
        name="Default Mesh Color Mode",
        description="How camera-projected mesh export chooses SVG fill colors",
        items=(
            ("MATERIAL_HEURISTIC", "Material Heuristic", "Use material and node colors without rendering"),
            ("CAMERA_SAMPLE", "Sample Final Camera Color", "Render Eevee from the active camera, keep centroid-visible faces only, and sample the final shaded color per face"),
        ),
        default="CAMERA_SAMPLE",
    )
    
    use_svgelements: BoolProperty(
        name="Use SVGElements Library",
        description="Use the included SVGElements library for SVG processing",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        
        # Import Settings
        box = layout.box()
        box.label(text="Import Settings", icon='IMPORT')
        col = box.column()
        col.prop(self, "default_import_scale")
        col.prop(self, "default_resolution")
        col.prop(self, "default_import_height_mode")
        col.prop(self, "default_import_height_step")
        col.prop(self, "default_import_stroke_overlay_offset")
        col.prop(self, "default_import_intelligent_split_paths")
        
        # Export Settings
        box = layout.box()
        box.label(text="Export Settings", icon='EXPORT')
        col = box.column()
        col.prop(self, "default_export_scale")
        col.prop(self, "precision")
        col.prop(self, "default_export_fill_color")
        col.prop(self, "default_export_apply_stroke")
        stroke_col = col.column()
        stroke_col.active = self.default_export_apply_stroke
        stroke_col.prop(self, "default_export_stroke_color")
        stroke_col.prop(self, "default_export_stroke_width")
        col.prop(self, "default_export_cull_to_camera")
        col.prop(self, "default_export_mesh_color_mode")
        
        # Library Settings
        box = layout.box()
        box.label(text="Library Settings", icon='SCRIPT')
        col = box.column()
        col.prop(self, "use_svgelements")


class SpecIOSceneProperties(PropertyGroup):
    """Per-scene settings used by SpecIO operators and panels."""

    defaults_initialized: BoolProperty(
        name="Defaults Initialized",
        description="Internal flag tracking whether scene settings have been initialized from addon preferences",
        default=False,
        options={'HIDDEN'},
    )

    import_scale: FloatProperty(
        name="Import Scale",
        description="Scale factor for imported SVG",
        default=1.0,
        min=0.001,
        max=1000.0,
    )
    
    import_resolution: IntProperty(
        name="Resolution",
        description="Resolution for SVG import",
        default=64,
        min=1,
        max=512,
    )

    import_height_mode: EnumProperty(
        name="Height Mode",
        description="How imported SVG objects are offset on the Z axis to reduce z-fighting",
        items=(
            ("FLAT", "Flat", "Import all objects on the same Z height"),
            ("PER_OBJECT", "Per Object", "Offset each imported SVG object by a fixed Z step"),
            ("PER_LAYER", "Per Layer", "Offset objects by their top-level SVG layer or group"),
        ),
        default="PER_OBJECT",
    )

    import_height_step: FloatProperty(
        name="Height Step Ratio",
        description="Z offset ratio relative to the imported SVG size used for per-object or per-layer height placement",
        default=0.001,
        min=0.0,
        max=100.0,
    )

    import_stroke_overlay_offset: FloatProperty(
        name="Stroke Overlay Ratio",
        description="Extra Z offset ratio relative to the imported SVG size so synthetic stroke helper objects render above fills",
        default=0.001,
        min=0.0,
        max=100.0,
    )

    import_intelligent_split_paths: BoolProperty(
        name="Intelligent Split Paths",
        description="Split complex evenodd paths into local contour families during import when that better matches SVG rendering",
        default=True,
    )
    
    export_scale: FloatProperty(
        name="Export Scale",
        description="Scale factor for exported SVG",
        default=1.0,
        min=0.001,
        max=1000.0,
    )
    
    export_precision: IntProperty(
        name="Precision",
        description="Decimal precision for SVG export",
        default=3,
        min=0,
        max=10,
    )

    export_default_fill_color: FloatVectorProperty(
        name="Default Fill Color",
        description="Fallback SVG fill color used when an exported object has no preserved SVG fill or Blender material color",
        default=(0.5, 0.5, 0.5),
        size=3,
        min=0.0,
        max=1.0,
        subtype='COLOR',
    )

    export_default_stroke_color: FloatVectorProperty(
        name="Default Stroke Color",
        description="Stroke color applied during export when export stroke is enabled and the object has no explicit SVG stroke",
        default=(0.0, 0.0, 0.0),
        size=3,
        min=0.0,
        max=1.0,
        subtype='COLOR',
    )

    export_apply_stroke: BoolProperty(
        name="Apply Stroke On Export",
        description="Add a default SVG stroke to exported objects that do not already have one",
        default=False,
    )

    export_stroke_width: FloatProperty(
        name="Default Stroke Width",
        description="Stroke width used when export stroke is enabled",
        default=1.0,
        min=0.001,
        max=1000.0,
    )

    export_cull_to_camera: BoolProperty(
        name="Cull to Camera",
        description="Skip geometry that falls entirely outside the camera viewport during export",
        default=True,
    )

    export_mesh_color_mode: EnumProperty(
        name="Mesh Color Mode",
        description="How camera-projected mesh export chooses SVG fill colors",
        items=(
            ("MATERIAL_HEURISTIC", "Material Heuristic", "Use material and node colors without rendering"),
            ("CAMERA_SAMPLE", "Sample Final Camera Color", "Render Eevee from the active camera, keep centroid-visible faces only, and sample the final shaded color per visible face"),
        ),
        default="CAMERA_SAMPLE",
    )

    image_export_mode: EnumProperty(
        name="Image Mode",
        description="How raster images are included in exported SVG files",
        items=(
            ("EMBED", "Embed", "Base64-encode images directly into the SVG file"),
            ("LINK", "Link", "Reference the original external image file path"),
        ),
        default="EMBED",
    )


class SpecIOMaterialGradientProperties(PropertyGroup):
    """Managed SpecIO gradient settings stored on Blender materials."""

    enabled: BoolProperty(
        name="Enable SpecIO Gradient",
        description="Use this material as a SpecIO-managed SVG gradient material",
        default=False,
        update=_update_material_gradient,
    )

    paint_target: EnumProperty(
        name="Paint Target",
        description="Choose whether this managed gradient exports as fill or stroke",
        items=(
            ("FILL", "Fill", "Export this material as the SVG fill paint"),
            ("STROKE", "Stroke", "Export this material as the SVG stroke paint"),
        ),
        default="FILL",
        update=_update_material_gradient,
    )

    gradient_id: StringProperty(
        name="Gradient ID",
        description="Optional SVG gradient id override; leave blank to derive it from the material name",
        default="",
        update=_update_material_gradient,
    )

    gradient_type: EnumProperty(
        name="Type",
        description="SVG gradient type used for preview and export",
        items=(
            ("LINEAR", "Linear", "Export and preview a linear gradient"),
            ("RADIAL", "Radial", "Export and preview a radial gradient"),
        ),
        default="LINEAR",
        update=_update_material_gradient,
    )

    spread_method: EnumProperty(
        name="Spread",
        description="How values outside the gradient range are handled",
        items=(
            ("pad", "Pad", "Clamp the gradient outside the stop range"),
            ("repeat", "Repeat", "Repeat the gradient pattern"),
            ("reflect", "Reflect", "Repeat the gradient by mirroring it"),
        ),
        default="pad",
        update=_update_material_gradient,
    )

    start_color: FloatVectorProperty(
        name="Start Color",
        description="First gradient stop color",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0),
        update=_update_material_gradient,
    )

    start_alpha: FloatProperty(
        name="Start Alpha",
        description="Opacity of the first gradient stop",
        default=1.0,
        min=0.0,
        max=1.0,
        update=_update_material_gradient,
    )

    start_offset: FloatProperty(
        name="Start Offset",
        description="Location of the first stop in the 0..1 gradient range",
        default=0.0,
        min=0.0,
        max=1.0,
        update=_update_material_gradient,
    )

    end_color: FloatVectorProperty(
        name="End Color",
        description="Last gradient stop color",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.1, 0.1, 0.1),
        update=_update_material_gradient,
    )

    end_alpha: FloatProperty(
        name="End Alpha",
        description="Opacity of the last gradient stop",
        default=1.0,
        min=0.0,
        max=1.0,
        update=_update_material_gradient,
    )

    end_offset: FloatProperty(
        name="End Offset",
        description="Location of the last stop in the 0..1 gradient range",
        default=1.0,
        min=0.0,
        max=1.0,
        update=_update_material_gradient,
    )

    linear_x1: FloatProperty(name="X1", default=0.0, min=-4.0, max=4.0, update=_update_material_gradient)
    linear_y1: FloatProperty(name="Y1", default=0.0, min=-4.0, max=4.0, update=_update_material_gradient)
    linear_x2: FloatProperty(name="X2", default=1.0, min=-4.0, max=4.0, update=_update_material_gradient)
    linear_y2: FloatProperty(name="Y2", default=0.0, min=-4.0, max=4.0, update=_update_material_gradient)
    radial_cx: FloatProperty(name="Center X", default=0.5, min=-4.0, max=4.0, update=_update_material_gradient)
    radial_cy: FloatProperty(name="Center Y", default=0.5, min=-4.0, max=4.0, update=_update_material_gradient)
    radial_r: FloatProperty(name="Radius", default=0.5, min=0.001, max=4.0, update=_update_material_gradient)
    radial_fx: FloatProperty(name="Focal X", default=0.5, min=-4.0, max=4.0, update=_update_material_gradient)
    radial_fy: FloatProperty(name="Focal Y", default=0.5, min=-4.0, max=4.0, update=_update_material_gradient)


classes = (
    SpecIOPreferences,
    SpecIOSceneProperties,
    SpecIOMaterialGradientProperties,
)


def register():
    """Register property classes and scene state."""
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.specio = PointerProperty(type=SpecIOSceneProperties)
    bpy.types.Material.specio_gradient = PointerProperty(type=SpecIOMaterialGradientProperties)
    for scene in _iter_registered_scenes():
        apply_preferences_to_scene(scene, force=True)


def unregister():
    """Unregister property classes and scene state."""
    del bpy.types.Material.specio_gradient
    del bpy.types.Scene.specio

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
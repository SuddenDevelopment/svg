"""
Properties module for SpecIO addon
"""

from . import svg_properties


def register():
    """Register all property classes"""
    svg_properties.register()


def unregister():
    """Unregister all property classes"""
    svg_properties.unregister()
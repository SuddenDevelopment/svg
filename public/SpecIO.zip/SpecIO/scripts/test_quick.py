"""Run the default SpecIO development validation workflow.

This is the fast path for day-to-day changes:

1. Pure Python regression tests
2. Headless Blender smoke suite

Use ``scripts/test_full.py`` when a change touches packaging, registration,
extension installation, or other release-sensitive behavior.
"""

from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BLENDER = r"C:\Program Files\Blender Foundation\Blender 5.1\blender.exe"


def _resolve_blender() -> str:
    env_value = os.environ.get("BLENDER_BIN")
    if env_value:
        return env_value

    default_path = Path(DEFAULT_BLENDER)
    if default_path.exists():
        return str(default_path)

    blender_on_path = shutil.which("blender")
    if blender_on_path:
        return blender_on_path

    raise FileNotFoundError(
        "Blender executable not found. Set BLENDER_BIN, install Blender to the default path, or add blender to PATH."
    )


def main(argv: list[str]) -> int:
    blender = _resolve_blender()
    command = [sys.executable, "scripts/validate.py", "--blender", blender, *argv]
    subprocess.run(command, cwd=REPO_ROOT, check=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
"""Build, install, verify, and remove the SpecIO extension in a clean Blender profile."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BLENDER = r"C:\Program Files\Blender Foundation\Blender 5.1\blender.exe"
PACKAGE_ID = "SpecIO"
REPO_ID = "user_default"


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a clean-profile Blender extension packaging smoke test")
    parser.add_argument(
        "--blender",
        default=DEFAULT_BLENDER,
        help="Path to the Blender executable.",
    )
    return parser.parse_args(argv)


def run_command(command: list[str], env: dict[str, str], label: str) -> str:
    print(f"==> {label}")
    print(" ".join(command))
    completed = subprocess.run(
        command,
        cwd=REPO_ROOT,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    if completed.stdout:
        print(completed.stdout)
    if completed.stderr:
        print(completed.stderr, file=sys.stderr)
    return completed.stdout


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    blender = Path(args.blender)
    if not blender.exists():
        raise FileNotFoundError(f"Blender executable not found: {blender}")

    with tempfile.TemporaryDirectory(prefix="specio-package-") as temp_dir:
        temp_root = Path(temp_dir)
        user_resources = temp_root / "blender-user"
        extensions_root = user_resources / "extensions"
        build_dir = temp_root / "build"
        zip_path = build_dir / "SpecIO-smoke.zip"
        user_resources.mkdir(parents=True, exist_ok=True)
        (extensions_root / "blender_org").mkdir(parents=True, exist_ok=True)
        (extensions_root / REPO_ID).mkdir(parents=True, exist_ok=True)
        build_dir.mkdir(parents=True, exist_ok=True)

        env = os.environ.copy()
        env["BLENDER_USER_RESOURCES"] = str(user_resources)

        run_command(
            [str(blender), "--command", "extension", "validate", str(REPO_ROOT)],
            env,
            "Validate extension manifest",
        )
        run_command(
            [
                str(blender),
                "--command",
                "extension",
                "build",
                "--source-dir",
                str(REPO_ROOT),
                "--output-filepath",
                str(zip_path),
            ],
            env,
            "Build extension package",
        )
        if not zip_path.exists():
            raise FileNotFoundError(f"Expected built extension archive: {zip_path}")

        run_command(
            [str(blender), "--command", "extension", "repo-list"],
            env,
            "Inspect clean-profile extension repositories",
        )
        run_command(
            [
                str(blender),
                "--command",
                "extension",
                "install-file",
                "-r",
                REPO_ID,
                "-e",
                str(zip_path),
            ],
            env,
            "Install and enable built extension package",
        )
        list_output = run_command(
            [str(blender), "--command", "extension", "list"],
            env,
            "List installed extensions after install",
        )
        if PACKAGE_ID not in list_output:
            raise RuntimeError("Expected SpecIO to appear in extension list after install")

        run_command(
            [
                str(blender),
                "-b",
                "--python-exit-code",
                "1",
                "--python",
                "tests/installed_extension_check.py",
            ],
            env,
            "Verify installed extension operators and runtime behavior",
        )

        run_command(
            [str(blender), "--command", "extension", "remove", PACKAGE_ID],
            env,
            "Remove installed extension package",
        )
        list_after_remove = run_command(
            [str(blender), "--command", "extension", "list"],
            env,
            "List installed extensions after removal",
        )
        if PACKAGE_ID in list_after_remove:
            raise RuntimeError("Expected SpecIO to be absent from extension list after removal")

    print("Package smoke completed successfully.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
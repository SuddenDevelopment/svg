"""Run the SpecIO validation suite in one command.

This script runs:

1. Pure Python regression tests
2. Blender headless smoke tests

Usage:

    python scripts/validate.py

Optional overrides:

    python scripts/validate.py --blender "C:/Program Files/Blender Foundation/Blender 5.1/blender.exe"
    python scripts/validate.py --scenario style-roundtrip
    python scripts/validate.py --with-visual-roundtrip --with-package-smoke

The Blender executable is resolved in this order:

1. ``--blender`` CLI argument
2. ``BLENDER_BIN`` environment variable
3. ``blender`` on PATH
"""

from __future__ import annotations

import argparse
from pathlib import Path
import os
import shutil
import subprocess
import sys


REPO_ROOT = Path(__file__).resolve().parents[1]
PYTHON_TEST_MODULES = (
    "tests.test_svg_gradients",
    "tests.test_svg_path_parser",
    "tests.test_svg_document",
    "tests.test_svg_style",
    "tests.test_svg_transform",
)


def parse_args(argv: list[str]) -> argparse.Namespace:
    """Parse command-line arguments for the validation runner."""
    parser = argparse.ArgumentParser(description="Run SpecIO validation checks")
    parser.add_argument(
        "--blender",
        help="Path to the Blender executable. Defaults to BLENDER_BIN or blender on PATH.",
    )
    parser.add_argument(
        "--scenario",
        default="all",
        help="Blender smoke scenario to run. Defaults to all.",
    )
    parser.add_argument(
        "--skip-python",
        action="store_true",
        help="Skip the pure Python regression tests.",
    )
    parser.add_argument(
        "--skip-blender",
        action="store_true",
        help="Skip the Blender smoke suite.",
    )
    parser.add_argument(
        "--with-visual-roundtrip",
        action="store_true",
        help="Run the render-based Blender roundtrip regression script.",
    )
    parser.add_argument(
        "--with-package-smoke",
        action="store_true",
        help="Run the clean-profile extension validate/build/install/remove smoke script.",
    )
    parser.add_argument(
        "--with-camera-mesh-regression",
        action="store_true",
        help="Run the numeric camera-mesh regression script for the dedicated blend fixture.",
    )
    parser.add_argument(
        "--with-camera-mesh-visual",
        action="store_true",
        help="Run the render-based camera-mesh visual regression script for the dedicated blend fixture.",
    )
    parser.add_argument(
        "--camera-mesh-blend",
        help="Optional blend file path override for the dedicated camera-mesh regression scripts.",
    )
    return parser.parse_args(argv)


def resolve_blender_executable(override: str | None) -> str:
    """Resolve the Blender executable path or command name."""
    if override:
        return override

    env_value = os.environ.get("BLENDER_BIN")
    if env_value:
        return env_value

    blender_on_path = shutil.which("blender")
    if blender_on_path:
        return blender_on_path

    raise FileNotFoundError(
        "Blender executable not found. Pass --blender, set BLENDER_BIN, or add blender to PATH."
    )


def run_command(command: list[str], label: str) -> None:
    """Run a subprocess command and fail fast on non-zero exit codes."""
    print(f"==> {label}")
    print(" ".join(command))
    subprocess.run(command, cwd=REPO_ROOT, check=True)


def main(argv: list[str]) -> int:
    """Run the configured validation steps."""
    args = parse_args(argv)

    try:
        blender_executable = None if args.skip_blender else resolve_blender_executable(args.blender)

        if not args.skip_python:
            run_command(
                [sys.executable, "-m", "unittest", *PYTHON_TEST_MODULES],
                "Pure Python regression tests",
            )

        if blender_executable is not None:
            run_command(
                [
                    blender_executable,
                    "-b",
                    "--factory-startup",
                    "--python-exit-code",
                    "1",
                    "--python",
                    "tests/blender_smoke.py",
                    "--",
                    "--scenario",
                    args.scenario,
                ],
                "Blender smoke suite",
            )

            if args.with_visual_roundtrip:
                run_command(
                    [
                        blender_executable,
                        "-b",
                        "--factory-startup",
                        "--python-exit-code",
                        "1",
                        "--python",
                        "tests/blender_visual_roundtrip.py",
                    ],
                    "Blender visual roundtrip regression",
                )

            if args.with_package_smoke:
                run_command(
                    [
                        sys.executable,
                        "scripts/package_smoke.py",
                        "--blender",
                        blender_executable,
                    ],
                    "Extension packaging smoke suite",
                )

            if args.with_camera_mesh_regression:
                command = [
                    blender_executable,
                    "-b",
                    "--factory-startup",
                    "--python-exit-code",
                    "1",
                    "--python",
                    "tests/blender_camera_mesh_regression.py",
                ]
                if args.camera_mesh_blend:
                    command.extend(["--", "--blend", args.camera_mesh_blend])
                run_command(command, "Camera mesh numeric regression")

            if args.with_camera_mesh_visual:
                command = [
                    blender_executable,
                    "-b",
                    "--factory-startup",
                    "--python-exit-code",
                    "1",
                    "--python",
                    "tests/blender_camera_mesh_visual.py",
                ]
                if args.camera_mesh_blend:
                    command.extend(["--", "--blend", args.camera_mesh_blend])
                run_command(command, "Camera mesh visual regression")
    except subprocess.CalledProcessError as exc:
        print(f"Validation failed with exit code {exc.returncode}", file=sys.stderr)
        return exc.returncode
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    print("Validation completed successfully.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
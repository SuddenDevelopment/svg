"""Standalone SVG visibility and Z-order diagnostic tool.

Usage:
    python scripts/svg_debug_visibility.py tests/Brasao_de_Pelotas.svg
    python scripts/svg_debug_visibility.py tests/Brasao_de_Pelotas.svg --blender-names path_001,path_009,path_020,path_021
    python scripts/svg_debug_visibility.py tests/Brasao_de_Pelotas.svg --color red

Run without Blender.  Resolves CSS classes, inherited styles, and effective fill/stroke
for every drawn element, then prints a table showing:
  - SVG document order  (= painter's-algorithm back-to-front draw order)
  - Expected Blender object name  (path_NNN, polygon_NNN, …)
  - Expected PER_OBJECT import Z-index  (0 = furthest back, higher = closer to camera)
  - Resolved fill color and stroke color
  - fill-rule
  - Sub-path count (M commands), closed sub-path count (Z commands)
  - Visibility flags

The SVG document order equals the Blender PER_OBJECT Z-index: element 1 in the SVG
gets Z-index 0 (furthest back) and the last element gets the highest Z-index (closest
to the camera / on top).  If that is not what you expect for a specific element, the
SVG painter ordering and Blender Z ordering are in conflict.
"""

from __future__ import annotations

import argparse
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


# ---------------------------------------------------------------------------
# CSS keyword → sRGB approximate label
# ---------------------------------------------------------------------------

_HEX_COLOR_NAMES: dict[str, str] = {
    "#000000": "black",
    "#ffffff": "white",
    "#ff0000": "red",
    "#00ff00": "green",
    "#0000ff": "blue",
    "#ffff00": "yellow",
    "#ff8000": "orange",
    "#800080": "purple",
    "#008000": "darkgreen",
    "#e20613": "red(SVG)",
    "#009540": "green(SVG)",
    "#005ca8": "blue(SVG)",
    "#ffcb00": "yellow(SVG)",
    "#ad9575": "brown(SVG)",
    "#fff":    "white",
}

_CSS_KEYWORDS: dict[str, str] = {
    "black": "#000000",
    "white": "#ffffff",
    "red": "#ff0000",
    "green": "#008000",
    "blue": "#0000ff",
    "yellow": "#ffff00",
    "none": "none",
}


def _color_label(value: str | None) -> str:
    if not value:
        return "(none)"
    v = value.strip().lower()
    if v == "none":
        return "none"
    if v in _CSS_KEYWORDS:
        v = _CSS_KEYWORDS[v]
    label = _HEX_COLOR_NAMES.get(v, "")
    if label:
        return f"{value}({label})"
    return value


def _color_matches(value: str | None, target: str) -> bool:
    """Return True when the resolved fill/stroke looks like the target color keyword."""
    if not value:
        return False
    v = value.strip().lower()
    if target == "red":
        return v in {"red", "#ff0000", "#e20613"} or "e206" in v or "ff0000" in v
    if target == "green":
        return v in {"green", "#008000", "#009540"} or "009540" in v
    if target == "blue":
        return v in {"blue", "#0000ff", "#005ca8"} or "005ca8" in v
    if target == "yellow":
        return v in {"yellow", "#ffff00", "#ffcb00"} or "ffcb00" in v or "ffff00" in v
    if target == "white":
        return v in {"white", "#ffffff", "#fff"}
    return target.lower() in v


# ---------------------------------------------------------------------------
# Minimal CSS <style> block parser
# ---------------------------------------------------------------------------

_CSS_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_CSS_RULE = re.compile(r"([^{}]+)\{([^{}]*)\}")


def _parse_css_declarations(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for chunk in text.split(";"):
        chunk = chunk.strip()
        if ":" not in chunk:
            continue
        k, v = chunk.split(":", 1)
        k = k.strip()
        v = v.strip()
        if k and v:
            result[k] = v
    return result


def parse_css_block(text: str) -> dict[str, dict[str, str]]:
    """Return a mapping from class name → CSS property dict."""
    by_class: dict[str, dict[str, str]] = {}
    cleaned = _CSS_COMMENT.sub("", text)
    for match in _CSS_RULE.finditer(cleaned):
        selectors_raw = match.group(1)
        props = _parse_css_declarations(match.group(2))
        if not props:
            continue
        for sel in selectors_raw.split(","):
            sel = sel.strip()
            if sel.startswith("."):
                name = sel[1:]
                by_class.setdefault(name, {}).update(props)
    return by_class


# ---------------------------------------------------------------------------
# Style resolution helpers
# ---------------------------------------------------------------------------

def _resolve_element_style(
    element: ET.Element,
    css_by_class: dict[str, dict[str, str]],
    inherited: dict[str, str],
) -> dict[str, str]:
    """Return the fully merged style for *element* including CSS and inheritance."""
    # Inherited values carry forward unless overridden.
    merged: dict[str, str] = dict(inherited)

    # CSS class rules (medium specificity)
    class_attr = element.get("class", "").strip()
    if class_attr:
        for cls in class_attr.split():
            cls_props = css_by_class.get(cls)
            if cls_props:
                merged.update(cls_props)

    # Presentation attributes (e.g. fill="red") - same specificity as class per CSS spec.
    for attr in ("fill", "stroke", "stroke-width", "display", "visibility", "opacity",
                 "fill-rule", "fill-opacity", "stroke-opacity"):
        val = element.get(attr)
        if val is not None:
            merged[attr] = val.strip()

    # Inline style attribute – highest specificity.
    inline_style = element.get("style", "")
    if inline_style:
        merged.update(_parse_css_declarations(inline_style))

    return merged


# ---------------------------------------------------------------------------
# Path complexity helpers
# ---------------------------------------------------------------------------

def _count_path_commands(d: str) -> tuple[int, int]:
    """Return (M_count, Z_count) for a path d attribute."""
    m_count = len(re.findall(r"[Mm]", d))
    z_count = len(re.findall(r"[Zz]", d))
    return m_count, z_count


def _is_effectively_closed(d: str) -> bool:
    """Rough check: does the path end with Z/z?"""
    stripped = d.strip().rstrip()
    return bool(stripped) and stripped[-1].lower() == "z"


# ---------------------------------------------------------------------------
# Main walker
# ---------------------------------------------------------------------------

DRAWN_TAGS = {"path", "polygon", "polyline", "rect", "circle", "ellipse", "line"}


class ElementRecord:
    __slots__ = (
        "svg_order",
        "blender_name",
        "import_z_index",
        "tag",
        "cls",
        "fill",
        "stroke",
        "fill_rule",
        "m_count",
        "z_count",
        "is_visible",
        "hidden_reason",
        "path_data_preview",
    )

    def __init__(self) -> None:
        self.svg_order: int = 0
        self.blender_name: str = ""
        self.import_z_index: int = 0
        self.tag: str = ""
        self.cls: str = ""
        self.fill: str = "black"
        self.stroke: str = "none"
        self.fill_rule: str = ""
        self.m_count: int = 0
        self.z_count: int = 0
        self.is_visible: bool = True
        self.hidden_reason: str = ""
        self.path_data_preview: str = ""


def walk_svg(
    root: ET.Element,
) -> tuple[list[ElementRecord], dict[str, dict[str, str]]]:
    """Walk the SVG tree and return records for every drawn element."""
    # 1. Collect CSS from all <style> elements.
    css_by_class: dict[str, dict[str, str]] = {}
    for el in root.iter():
        tag = el.tag.split("}")[-1] if "}" in el.tag else el.tag
        if tag == "style" and el.text:
            css_by_class.update(parse_css_block(el.text))

    records: list[ElementRecord] = []
    name_counters: dict[str, int] = {}
    svg_order_counter = [0]
    import_z_counter = [0]

    def next_name(prefix: str) -> str:
        count = name_counters.get(prefix, 0) + 1
        name_counters[prefix] = count
        return f"{prefix}_{count:03d}"

    def recurse(el: ET.Element, inherited: dict[str, str]) -> None:
        tag_raw = el.tag
        tag = tag_raw.split("}")[-1] if "}" in tag_raw else tag_raw

        # Always resolve style for potential inheritance propagation.
        style = _resolve_element_style(el, css_by_class, inherited)

        # Check visibility.
        display = style.get("display", "").lower()
        visibility = style.get("visibility", "").lower()
        is_hidden = display == "none" or visibility in {"hidden", "collapse"}

        if tag in DRAWN_TAGS:
            svg_order_counter[0] += 1
            rec = ElementRecord()
            rec.svg_order = svg_order_counter[0]
            rec.tag = tag
            rec.cls = el.get("class", "")

            if is_hidden:
                rec.is_visible = False
                rec.hidden_reason = (
                    f"display={display!r}" if display == "none"
                    else f"visibility={visibility!r}"
                )
            else:
                rec.is_visible = True

            # Blender name uses per-tag counter (polygon stays polygon_, etc.)
            blender_prefix = tag
            rec.blender_name = (el.get("id") or next_name(blender_prefix)).replace(" ", "_")

            # Z-index only increments for visible objects.
            rec.import_z_index = import_z_counter[0]
            import_z_counter[0] += 1

            rec.fill = style.get("fill", "black")
            rec.stroke = style.get("stroke", "none")
            rec.fill_rule = style.get("fill-rule", "")

            d = el.get("d", "") or el.get("points", "")
            rec.m_count, rec.z_count = _count_path_commands(d) if d else (0, 0)
            rec.path_data_preview = d[:120]

            records.append(rec)
            # Do not recurse into drawn elements.
            return

        # Recurse into container elements (svg, g, defs, …) propagating style.
        if tag in {"svg", "g", "symbol", "a"}:
            for child in el:
                recurse(child, style)
        elif tag != "defs":
            # Unknown container – still recurse just in case.
            for child in el:
                recurse(child, style)

    recurse(root, {})
    return records, css_by_class


# ---------------------------------------------------------------------------
# Output formatting
# ---------------------------------------------------------------------------

_RESET = ""
_RED = ""
_GREEN = ""
_YELLOW = ""
_CYAN = ""
_BOLD = ""

try:
    import os
    if sys.stdout.isatty() or os.environ.get("FORCE_COLOR"):
        _RESET = "\033[0m"
        _RED = "\033[31m"
        _GREEN = "\033[32m"
        _YELLOW = "\033[33m"
        _CYAN = "\033[36m"
        _BOLD = "\033[1m"
except Exception:
    pass


def _row_color(rec: ElementRecord) -> str:
    if not rec.is_visible:
        return _YELLOW
    fill = rec.fill.strip().lower()
    if _color_matches(fill, "red"):
        return _RED
    if _color_matches(fill, "green"):
        return _GREEN
    if _color_matches(fill, "blue"):
        return _CYAN
    return ""


def print_table(
    records: list[ElementRecord],
    filter_blender_names: set[str] | None = None,
    filter_color: str | None = None,
) -> None:
    header = (
        f"{'SVG#':>5}  {'Z-idx':>5}  {'Blender name':<18}  {'tag':<8}  "
        f"{'fill':<26}  {'stroke':<20}  {'fill-rule':<10}  {'M':>4}  {'Z':>4}  {'visible'}"
    )
    print(_BOLD + header + _RESET)
    print("-" * len(header))

    for rec in records:
        if filter_blender_names and rec.blender_name not in filter_blender_names:
            continue
        if filter_color and not (
            _color_matches(rec.fill, filter_color)
            or _color_matches(rec.stroke, filter_color)
        ):
            continue

        color = _row_color(rec)
        visible_str = "YES" if rec.is_visible else f"HIDDEN({rec.hidden_reason})"
        fill_label = _color_label(rec.fill)
        stroke_label = _color_label(rec.stroke)
        cls_note = f"  [{rec.cls}]" if rec.cls else ""

        row = (
            f"{rec.svg_order:>5}  {rec.import_z_index:>5}  {rec.blender_name:<18}  "
            f"{rec.tag:<8}  {fill_label:<26}  {stroke_label:<20}  "
            f"{rec.fill_rule:<10}  {rec.m_count:>4}  {rec.z_count:>4}  "
            f"{visible_str}{cls_note}"
        )
        print(color + row + _RESET)


def print_z_order_summary(records: list[ElementRecord]) -> None:
    """Print elements sorted by Z-index (low = back, high = front)."""
    print()
    print(_BOLD + "Z-ORDER SUMMARY (low Z-idx = furthest back, high = closest to camera)" + _RESET)
    print("In SVG painter order, the LAST element drawn is visually ON TOP.")
    print("PER_OBJECT import maps each element's draw order position directly to Z height.")
    print()
    for rec in records:
        if not rec.is_visible:
            continue
        bar = "░" * (rec.import_z_index) + "█"
        fill_label = _color_label(rec.fill)
        print(f"  Z={rec.import_z_index:>3}  {rec.blender_name:<18}  fill={fill_label:<26}  {bar}")


def print_potential_issues(records: list[ElementRecord]) -> None:
    """Highlight suspicious elements that might cause visible problems in Blender."""
    issues: list[str] = []

    for rec in records:
        if not rec.is_visible:
            continue

        # Open path with fill + nearly-closed endpoints (SVG floating-point gap).
        if rec.tag == "path" and not rec.z_count and rec.m_count == 1:
            issues.append(
                f"  {rec.blender_name}: single open path (no Z) with fill — "
                f"endpoints may need auto-closure (check gap vs 1.0-unit threshold)."
            )

        # Very complex paths (many subpaths).
        if rec.m_count > 50:
            issues.append(
                f"  {rec.blender_name}: {rec.m_count} M commands, {rec.z_count} Z commands → "
                f"very complex path; evenodd winding reversal may be slow or produce holes."
            )

        # Suspected evenodd winding issue: multiple closed subpaths with evenodd.
        if rec.fill_rule == "evenodd" and rec.z_count >= 2 and rec.m_count >= 2:
            issues.append(
                f"  {rec.blender_name}: evenodd with {rec.m_count} subpaths and {rec.z_count} closes "
                f"→ winding reversal applied; visually verify holes match SVG."
            )

    if issues:
        print()
        print(_BOLD + "POTENTIAL ISSUES" + _RESET)
        for msg in issues:
            print(_YELLOW + msg + _RESET)
    else:
        print()
        print(_GREEN + "No structural issues detected." + _RESET)


def print_red_elements(records: list[ElementRecord]) -> None:
    """List elements with red or near-red fill/stroke for quick cross-reference."""
    reds = [r for r in records if _color_matches(r.fill, "red") or _color_matches(r.stroke, "red")]
    print()
    print(_BOLD + f"RED ELEMENTS ({len(reds)} found)" + _RESET)
    for rec in reds:
        vis = "visible" if rec.is_visible else f"HIDDEN"
        print(
            f"  {rec.blender_name:<18}  SVG#{rec.svg_order:>3}  Z={rec.import_z_index:>3}  "
            f"fill={rec.fill}  stroke={rec.stroke}  {vis}"
        )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Diagnose SVG element visibility and expected Blender Z order."
    )
    parser.add_argument("svg_file", help="Path to the SVG file to analyse.")
    parser.add_argument(
        "--blender-names",
        help="Comma-separated Blender object names to focus on, e.g. path_001,path_009",
    )
    parser.add_argument(
        "--color",
        help="Only show elements whose fill or stroke matches this color keyword "
             "(red, green, blue, yellow, white).",
    )
    parser.add_argument(
        "--z-order",
        action="store_true",
        help="Print a Z-order bar chart instead of the main table.",
    )
    parser.add_argument(
        "--issues",
        action="store_true",
        default=True,
        help="Print potential structural issues (default: on).",
    )
    parser.add_argument(
        "--no-issues",
        action="store_false",
        dest="issues",
    )
    parser.add_argument(
        "--show-path-data",
        action="store_true",
        help="Print the first 120 characters of each element's d/points data.",
    )
    args = parser.parse_args(argv)

    svg_path = Path(args.svg_file)
    if not svg_path.exists():
        print(f"ERROR: file not found: {svg_path}", file=sys.stderr)
        return 1

    try:
        tree = ET.parse(svg_path)
    except ET.ParseError as exc:
        print(f"ERROR: SVG parse failed: {exc}", file=sys.stderr)
        return 1

    root = tree.getroot()
    records, css_by_class = walk_svg(root)

    print(f"\nSVG: {svg_path.name}  ({len(records)} drawn elements)\n")

    # Print CSS classes for quick reference.
    if css_by_class:
        print(_BOLD + "CSS CLASSES:" + _RESET)
        for cls_name in sorted(css_by_class):
            props = css_by_class[cls_name]
            prop_str = "; ".join(f"{k}:{v}" for k, v in sorted(props.items()))
            print(f"  .{cls_name}  {{ {prop_str} }}")
        print()

    filter_names: set[str] | None = None
    if args.blender_names:
        filter_names = {n.strip() for n in args.blender_names.split(",")}

    if args.z_order:
        print_z_order_summary(records)
    else:
        print_table(records, filter_blender_names=filter_names, filter_color=args.color)

    print_red_elements(records)

    if args.issues:
        print_potential_issues(records)

    # Always print a Z-comparison for the user-reported problem pair.
    if not args.z_order and not filter_names and not args.color:
        _pairs = [("path_001", "path_009"), ("path_020", "path_021")]
        z_map = {r.blender_name: r for r in records}
        print()
        print(_BOLD + "Z-ORDER COMPARISON FOR REPORTED PROBLEM PAIRS:" + _RESET)
        print("NOTE: In PER_OBJECT import mode, SVG document order maps directly to Blender Z.")
        print("      SVG draws FIRST elements at the BACK (low Z).  LAST elements are on TOP (high Z).")
        print("      If you want a specific element visually IN FRONT of another, it should be drawn")
        print("      LATER in the SVG file (higher SVG order = higher Z = closer to camera).")
        print()
        for a_name, b_name in _pairs:
            a = z_map.get(a_name)
            b = z_map.get(b_name)
            if a and b:
                higher = a_name if a.import_z_index > b.import_z_index else b_name
                lower = b_name if higher == a_name else a_name
                print(
                    f"  {a_name} (Z={a.import_z_index}, SVG#{a.svg_order}, fill={_color_label(a.fill)})"
                )
                print(
                    f"  {b_name} (Z={b.import_z_index}, SVG#{b.svg_order}, fill={_color_label(b.fill)})"
                )
                print(
                    f"    → {_BOLD}{higher}{_RESET} is HIGHER Z (closer to camera / on top of {lower})"
                )
                svg_a = a.svg_order
                svg_b = b.svg_order
                if svg_a < svg_b:
                    print(f"    → SVG draw order: {a_name} painted FIRST = background behind {b_name}")
                else:
                    print(f"    → SVG draw order: {b_name} painted FIRST = background behind {a_name}")
                print()

    if args.show_path_data:
        print()
        print(_BOLD + "PATH DATA PREVIEW (first 120 chars):" + _RESET)
        shown = [r for r in records if filter_names is None or r.blender_name in filter_names]
        for rec in shown:
            if rec.path_data_preview:
                print(f"  {rec.blender_name}: {rec.path_data_preview!r}")

    return 0


if __name__ == "__main__":
    sys.exit(main())

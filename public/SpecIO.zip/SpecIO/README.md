# SpecIO
Blender Addon for SVG Import and Export

A Blender 5.1+ addon for importing and exporting SVG files with a modern extension packaging path.

## Features

- **SVG Import**: Import `svg`, `g`, `image`, `rect`, `circle`, `ellipse`, `line`, `polyline`, `polygon`, and `path` elements using `M`, `L`, `H`, `V`, `C`, `S`, `Q`, `T`, `A`, and `Z` commands, including relative variants, with affine `transform` support on supported elements and groups
- **SVG Export**: Export selected Blender curve objects as SVG path data, project selected mesh objects through the active scene camera into SVG silhouettes, normalize imported arcs to cubic path segments, and export imported raster image planes back as SVG `<image>` elements
- **Style-Aware Roundtrip**: Preserve `fill`, `stroke`, `stroke-width`, `stroke-linecap`, and `stroke-linejoin` attributes on imported objects, map practical stroke display settings into imported Blender curves, build Blender node materials for imported `linearGradient` and `radialGradient` paint servers on the primary paint slot, keep explicit `fill="none"` and `stroke="none"` values, skip hidden SVG content marked with `display="none"` or `visibility="hidden"`, and still use fallback solid paint colors when a referenced paint server cannot be reconstructed
- **Managed Gradient Materials**: Create a SpecIO gradient material from the SVG sidebar, preview linear or radial gradients directly in Blender, and export matching SVG `defs` plus `url(#...)` references from the managed material properties
- **Raster Image Roundtrip**: Import local-file or embedded-data SVG `<image>` elements as textured Blender planes and export them either as embedded data URIs or linked image paths
- **N-Panel Interface**: Easy-to-use sidebar panel in the 3D Viewport
- **Collection Hierarchy**: Preserve SVG group structure on import and export through Blender collections and SVG `g` elements where supported
- **Rounded Geometry**: Preserve rounded `rect` corner geometry through `rx` and `ry` import as bezier curves
- **Customizable Settings**: Import/export scale, import resolution, height placement, stroke overlay, export precision, image export mode, and reset-to-default scene settings

## Installation

1. Download or clone this repository
2. In Blender 5.1+, go to Edit > Preferences > Extensions
3. Use "Install from Disk" and select a built extension zip, or install the source tree during development
4. Enable "SpecIO" in the extensions list

## Managed Gradient Workflow

1. Select one or more curve objects in the 3D Viewport.
2. Open the `SVG` sidebar tab and use `Assign SpecIO Gradient`.
3. Edit the active material's managed gradient settings in the `Gradient Material` section.
4. Export with `Export SVG` to write matching `linearGradient` or `radialGradient` definitions into the SVG `defs` block.

## Packaging

SpecIO now targets Blender's extension workflow for Blender 5.1+.

- `blender_manifest.toml` is the primary extension manifest for Blender 5.1+
- `manifest.json` is kept in the repository so older project tooling does not break while the repo transitions

Build or validate from a Windows shell with Blender on your `PATH` or by using the full `blender.exe` path:

```powershell
blender --command extension validate
blender --command extension build
```

## Usage

1. Open the 3D Viewport
2. Press `N` to open the sidebar
3. Click on the "SVG" tab
4. Use `Import SVG` to load supported SVG elements into the scene
5. Select one or more supported objects and use `Export SVG` to write SVG output
6. Mesh selections export through the active scene camera when a camera is set on the scene
7. Use the `Images` export option to embed imported raster images as data URIs or keep linked file paths
8. Adjust per-scene import and export settings as needed, or use `Reset Scene Defaults` to restore addon defaults for the active scene

## Supported SVG Subset

SpecIO currently targets a practical, tested SVG subset for Blender 5.1+.

- **Containers and structure**: `svg`, `g`, nested group hierarchy, deterministic sibling order, stored SVG group ids, and synthetic root collection filtering on export
- **Vector geometry**: `rect`, rounded `rect` via `rx` and `ry`, `circle`, `ellipse`, `line`, `polyline`, `polygon`, and `path`
- **Path commands**: `M`, `L`, `H`, `V`, `C`, `S`, `Q`, `T`, `A`, and `Z`, including relative variants
- **Paint and presentation**: `fill`, `stroke`, `stroke-width`, `stroke-linecap`, `stroke-linejoin`, `display`, `visibility`, inherited style attributes, CSS style blocks, `linearGradient`, and `radialGradient`
- **Raster images**: SVG `<image>` elements using local file paths or embedded `data:` URIs
- **Transforms**: affine transforms on supported elements and groups, including nested transform stacks exercised by the transform smoke fixture

The current implementation does not aim to fully support the wider SVG feature set. In particular, treat these as unsupported or only partially supported unless documented otherwise in a release:

- `text`, `tspan`, `textPath`, `use`, `symbol`, `clipPath`, `mask`, filters, animation, and script content
- Remote raster image URLs such as `http://`, `https://`, `ftp://`, or protocol-relative `//` references
- Full SVG unit and layout behavior outside the validated transform and sample fixtures
- Exact preservation of original path command forms, since exported output may normalize curves and arcs

## Requirements

- Blender 5.1.0 or later
- Optional: SVGElements Python library (for advanced SVG processing)
- Windows, macOS, and Linux are expected targets, but validation in this workspace was performed on Windows

## File Structure

```
SpecIO/
├── __init__.py              # Main addon file
├── blender_manifest.toml    # Blender 5.1+ extension manifest
├── manifest.json            # Transitional metadata kept aligned with the addon
├── io_svg/                  # SVG parsing and conversion helpers
│   ├── __init__.py
│   ├── curve_builder.py     # Blender curve construction helpers
│   ├── document.py          # Pure SVG document assembly helpers
│   ├── gradient_materials.py # Managed gradient material helpers
│   ├── gradients.py         # SVG gradient parsing and serialization helpers
│   ├── formatting.py        # Pure SVG number and point formatting helpers
│   ├── image_util.py        # Raster image import/export helpers
│   ├── path_parser.py       # Pure SVG path parsing helpers
│   ├── style.py             # Pure SVG style parsing and export helpers
│   ├── transform.py         # SVG transform parsing helpers
│   ├── exporter.py          # Current SVG exporter implementation
│   └── importer.py          # Current SVG importer implementation
├── panels/                  # UI panels
│   ├── __init__.py
│   └── svg_panel.py         # SVG N-panel interface
├── operators/               # Blender operators
│   ├── __init__.py
│   ├── svg_importer.py      # Backward-compatible importer shim
│   └── svg_operators.py     # Blender operator entry points
├── properties/              # Addon properties
│   ├── __init__.py
│   └── svg_properties.py    # Settings and preferences
├── tests/                   # Pure Python regression tests
│   ├── blender_smoke.py     # Headless Blender smoke-test runner
│   ├── test_svg_document.py
│   ├── test_svg_gradients.py
│   ├── test_svg_path_parser.py
│   ├── test_svg_style.py
│   └── test_svg_transform.py
└── libs/                    # Third-party libraries
    └── README.md            # Instructions for SVGElements
```

## Development

This addon follows Blender 5.1+ extension-era practices including:
- Extension manifest metadata
- Modular structure with separate panels, operators, and properties
- Proper registration/unregistration patterns
- N-Panel sidebar integration

### Validation

Use the quick validation wrapper after normal development changes:

```powershell
python scripts/test_quick.py
```

Use the full validation wrapper when a change affects registration, packaging, install or enable flow, manifests, or release readiness:

```powershell
python scripts/test_full.py
```

Both wrappers resolve Blender automatically from `BLENDER_BIN`, the default Windows Blender 5.1 install path, or `blender` on your `PATH`.

To run a focused Blender smoke scenario while iterating, pass through the existing validate flags:

```powershell
python scripts/test_quick.py --scenario style-roundtrip
```

For lower-level control, you can still call the validation runner directly. Run the full automated validation suite from the repository root:

```powershell
python scripts/validate.py
```

Include the optional render-based roundtrip regression and clean-profile extension packaging smoke checks:

```powershell
python scripts/validate.py --with-visual-roundtrip --with-package-smoke
```

To run the Blender smoke suite with an explicit Blender executable:

```powershell
python scripts/validate.py --blender "C:/Program Files/Blender Foundation/Blender 5.1/blender.exe"
```

Run the pure Python regression tests from the repository root:

```powershell
python -m unittest tests.test_svg_gradients tests.test_svg_path_parser tests.test_svg_document tests.test_svg_style tests.test_svg_transform
```

Run the reusable Blender headless smoke tests from the repository root:

```powershell
blender -b --factory-startup --python tests/blender_smoke.py -- --scenario all
```

Supported Blender smoke scenarios are `path-rich`, `rotated-arc`, `large-arc`, `compound-fill`, `height-offsets`, `scene-defaults-reset`, `collection-hierarchy`, `hierarchy-order-roundtrip`, `malformed-input`, `style-roundtrip`, `gradient-material`, `managed-gradient-export`, `multi-spline-export`, `sample-camera-roundtrip`, `transform-stack-roundtrip`, and `all`.

Run the dedicated visual regression harness against the default complex sample SVG:

```powershell
blender -b --factory-startup --python tests/blender_visual_roundtrip.py
```

Run the dedicated numeric mesh-export regression against the `logo_cube_2.blend` fixture:

```powershell
blender -b --factory-startup --python tests/blender_camera_mesh_regression.py
```

Run the dedicated visual mesh-export regression against the same fixture:

```powershell
blender -b --factory-startup --python tests/blender_camera_mesh_visual.py
```

Run the clean-profile extension package smoke workflow from the repository root:

```powershell
python scripts/package_smoke.py --blender "C:/Program Files/Blender Foundation/Blender 5.1/blender.exe"
```

For the full release validation matrix and ship checklist, see [RELEASE_READINESS.md](RELEASE_READINESS.md).

### Development Guidelines

For comprehensive development standards and best practices, see:
- [DEVELOPMENT_GUIDELINES.md](DEVELOPMENT_GUIDELINES.md) - Complete development standards
- [AGENTS.md](AGENTS.md) - Repo-specific agent and development rules
- [.github/copilot-instructions.md](.github/copilot-instructions.md) - Instructions for GitHub Copilot

These documents provide detailed guidance on:
- Blender 5.1+ extension requirements
- Code architecture and organization  
- Development principles (KISS, DRY, Separation of Concerns)
- Testing guidelines and best practices
- Performance and security considerations

## License

GPL-3.0-or-later

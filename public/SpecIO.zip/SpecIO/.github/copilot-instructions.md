# GitHub Copilot Instructions for SpecIO Blender Addon

## Project Context

SpecIO is a Blender 4.3+ addon for importing and exporting SVG files. The addon follows modern Blender development practices and maintains a modular architecture.

## Key Development Guidelines

### Blender 4.3+ Best Practices

**Manifest System:**
- Use `manifest.json` for addon metadata (required for Blender 4.3+)
- Include proper schema version, permissions, and dependencies
- Maintain version consistency between manifest.json and __init__.py

**Registration Pattern:**
```python
def register():
    """Register all addon components"""
    properties.register()  # First
    operators.register()   # Second  
    panels.register()      # Third

def unregister():
    """Unregister all addon components"""
    panels.unregister()     # Reverse order
    operators.unregister()
    properties.unregister()
```

**Class Naming Conventions:**
- Operators: `SPECIO_OT_operation_name`
- Panels: `SPECIO_PT_panel_name`
- Properties: `SPECIO_PR_property_name`
- Preferences: `SpecIOPreferences`

### Property Implementation

**Scene Properties:**
```python
class SpecIOSceneProperties(PropertyGroup):
    property_name: FloatProperty(
        name="Display Name",
        description="Detailed description for tooltip",
        default=1.0,
        min=0.001,
        max=1000.0,
    )
```

**Addon Preferences:**
```python
class SpecIOPreferences(AddonPreferences):
    bl_idname = "SpecIO"
    
    setting_name: BoolProperty(
        name="Setting Display Name",
        description="What this setting controls",
        default=True,
    )
```

### Operator Implementation

**Standard Operator Pattern:**
```python
class SPECIO_OT_operation_name(Operator):
    """Operator description for tooltip"""
    
    bl_idname = "specio.operation_name"
    bl_label = "Operation Label"
    bl_description = "Detailed description"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            # Implementation here
            self.report({'INFO'}, "Success message")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Error: {str(e)}")
            return {'CANCELLED'}
```

**File Import/Export Pattern:**
```python
class SPECIO_OT_import_svg(Operator, ImportHelper):
    """Import SVG file"""
    
    bl_idname = "specio.import_svg"
    bl_label = "Import SVG"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".svg"
    filter_glob: StringProperty(
        default="*.svg",
        options={'HIDDEN'},
        maxlen=255,
    )
```

### Panel Implementation

**N-Panel Sidebar Pattern:**
```python
class SPECIO_PT_main_panel(Panel):
    """Main panel description"""
    
    bl_label = "Panel Title"
    bl_idname = "SPECIO_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SVG'
    bl_context = "objectmode"
    
    def draw(self, context):
        layout = self.layout
        # UI implementation
```

## Code Quality Standards

### Error Handling Pattern
```python
def process_svg_file(filepath):
    """Process SVG file with proper error handling"""
    try:
        # File processing logic
        return result
    except FileNotFoundError:
        raise FileNotFoundError(f"SVG file not found: {filepath}")
    except ET.ParseError as e:
        raise ValueError(f"Invalid SVG format: {e}")
    except Exception as e:
        raise RuntimeError(f"SVG processing failed: {e}")
```

### Type Hints and Documentation
```python
from typing import Optional, Dict, Any, List
import bpy
from bpy.types import Context, Operator

def import_svg_elements(filepath: str, context: Context) -> Dict[str, Any]:
    """Import SVG elements from file.
    
    Args:
        filepath: Path to SVG file
        context: Blender context
        
    Returns:
        Dictionary with import results and statistics
        
    Raises:
        FileNotFoundError: If SVG file doesn't exist
        ValueError: If SVG format is invalid
    """
```

### Performance Considerations
- Avoid expensive operations in panel `draw()` methods
- Cache computation results when appropriate
- Use lazy loading for optional dependencies
- Handle large SVG files efficiently

## Development Principles

### KISS (Keep It Simple)
- Prefer clear, readable code over clever solutions
- Break complex functions into smaller, focused ones
- Use descriptive names for variables and functions
- Avoid unnecessary abstraction layers

### DRY (Don't Repeat Yourself)
- Extract common functionality into utility modules
- Use inheritance for shared operator/panel behavior
- Centralize configuration and constants
- Create reusable UI components

### Separation of Concerns
- Keep UI logic separate from data processing
- Use dedicated modules: `/operators`, `/panels`, `/properties`
- Separate import/export logic from conversion utilities
- Isolate Blender API calls from pure Python logic

### Logic Nesting Limits
- Maximum nesting depth: 4 levels
- Use early returns to reduce nesting
- Extract nested logic into helper functions
- Prefer guard clauses over deep if-else chains

## Testing Guidelines

### Unit Testing Approach
```python
import unittest
from unittest.mock import Mock, patch

class TestSVGImporter(unittest.TestCase):
    def setUp(self):
        self.importer = SVGImporter()
    
    def test_parse_valid_svg(self):
        """Test parsing of valid SVG content"""
        # Test implementation
        
    def test_handle_invalid_svg(self):
        """Test graceful handling of invalid SVG"""
        # Test implementation
```

### Manual Testing Checklist
- Test with various SVG file types and complexities
- Verify UI responsiveness and error messages
- Test addon installation/uninstallation
- Validate import/export roundtrip consistency
- Check compatibility with different Blender scenes

## Common Patterns to Follow

### Property Registration
```python
def register():
    """Register properties on appropriate types"""
    bpy.types.Scene.specio_import_scale = FloatProperty(
        name="Import Scale",
        default=1.0,
        min=0.001,
        max=1000.0,
    )

def unregister():
    """Clean up registered properties"""
    del bpy.types.Scene.specio_import_scale
```

### File Path Handling
```python
import os
from pathlib import Path

def validate_svg_file(filepath: str) -> bool:
    """Validate SVG file exists and has correct extension"""
    path = Path(filepath)
    return path.exists() and path.suffix.lower() == '.svg'
```

### UI Layout Patterns
```python
def draw_import_settings(self, context, layout):
    """Draw import settings UI section"""
    box = layout.box()
    box.label(text="Import Settings", icon='IMPORT')
    col = box.column(align=True)
    col.prop(context.scene, "specio_import_scale")
    col.prop(context.scene, "specio_import_resolution")
```

## Security and Validation

### Input Validation
- Always validate file paths and extensions
- Sanitize user input before processing
- Check context appropriateness in operators
- Validate object types and states

### Safe File Processing
- Use try-except for all file operations
- Validate SVG structure before processing
- Handle malformed XML gracefully
- Limit resource usage for large files

## Dependencies and Libraries

### Optional Dependency Pattern
```python
try:
    from .libs import svgelements
    HAS_SVGELEMENTS = True
except ImportError:
    HAS_SVGELEMENTS = False
    
def process_with_fallback():
    """Use SVGElements if available, fallback otherwise"""
    if HAS_SVGELEMENTS:
        # Use advanced processing
        pass
    else:
        # Use basic XML parsing
        pass
```

Remember: Always prioritize code clarity, user experience, and maintainability. Follow Blender's UI conventions and provide helpful error messages to users.
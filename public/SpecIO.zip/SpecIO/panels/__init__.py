"""
Panels module for SpecIO addon
"""

from . import svg_panel


def register():
    """Register all panel classes"""
    svg_panel.register()


def unregister():
    """Unregister all panel classes"""
    svg_panel.unregister()
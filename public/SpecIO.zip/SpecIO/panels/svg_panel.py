"""SVG panel for the N-panel sidebar in the 3D Viewport."""

import bpy
from bpy.types import Panel


class SPECIO_PT_svg_main(Panel):
    """Root panel for the SpecIO SVG addon."""

    bl_label = "SpecIO"
    bl_idname = "SPECIO_PT_svg_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SVG'
    bl_context = "objectmode"

    def draw(self, context):
        pass


class SPECIO_PT_import(Panel):
    """Import sub-panel: options then action."""

    bl_label = "Import"
    bl_idname = "SPECIO_PT_import"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SVG'
    bl_context = "objectmode"
    bl_parent_id = "SPECIO_PT_svg_main"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.specio

        col = layout.column(align=True)
        col.prop(settings, "import_scale", text="Scale")
        col.prop(settings, "import_resolution", text="Resolution")
        col.prop(settings, "import_height_mode", text="Height")
        col.prop(settings, "import_height_step", text="Height Step Ratio")
        col.prop(settings, "import_stroke_overlay_offset", text="Stroke Overlay Ratio")
        col.prop(settings, "import_intelligent_split_paths", text="Intelligent Split Paths")

        layout.separator()
        layout.operator("specio.import_svg", text="Import SVG", icon='IMPORT')


class SPECIO_PT_export(Panel):
    """Export sub-panel: options then action."""

    bl_label = "Export"
    bl_idname = "SPECIO_PT_export"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SVG'
    bl_context = "objectmode"
    bl_parent_id = "SPECIO_PT_svg_main"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.specio

        col = layout.column(align=True)
        col.prop(settings, "export_scale", text="Scale")
        col.prop(settings, "export_precision", text="Precision")
        col.prop(settings, "export_default_fill_color", text="Default Fill")
        col.separator()
        col.prop(settings, "export_apply_stroke", text="Apply Stroke")
        stroke_col = col.column(align=True)
        stroke_col.active = settings.export_apply_stroke
        stroke_col.prop(settings, "export_default_stroke_color", text="Stroke Color")
        stroke_col.prop(settings, "export_stroke_width", text="Stroke Width")
        col.separator()
        col.prop(settings, "image_export_mode", text="Images")
        col.prop(settings, "export_cull_to_camera", text="Cull to Camera")
        col.prop(settings, "export_mesh_color_mode", text="Mesh Color")

        layout.separator()
        layout.operator("specio.export_svg", text="Export SVG", icon='EXPORT')


class SPECIO_PT_tools(Panel):
    """Curve tools sub-panel."""

    bl_label = "Tools"
    bl_idname = "SPECIO_PT_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SVG'
    bl_context = "objectmode"
    bl_parent_id = "SPECIO_PT_svg_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        active_object = context.active_object

        col = layout.column(align=True)
        col.operator("specio.split_selected_path", text="Split Selected Path", icon='UV_SYNC_SELECT')
        if active_object is None or active_object.type != 'CURVE':
            col.label(text="Select a curve path", icon='INFO')
        elif len(active_object.data.splines) < 2:
            col.label(text="Selected path has one spline", icon='INFO')


class SPECIO_PT_gradient(Panel):
    """Gradient material sub-panel."""

    bl_label = "Gradient Material"
    bl_idname = "SPECIO_PT_gradient"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SVG'
    bl_context = "objectmode"
    bl_parent_id = "SPECIO_PT_svg_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        active_object = context.active_object
        active_material = None
        if active_object and active_object.type == 'CURVE' and active_object.data.materials:
            active_material = active_object.data.materials[0]

        col = layout.column(align=True)
        col.operator("specio.assign_gradient_material", text="Assign SpecIO Gradient", icon='MATERIAL')

        if active_material is None:
            col.label(text="Select a curve object", icon='INFO')
            return

        col.label(text=f"Material: {active_material.name}")
        props = active_material.specio_gradient
        col.prop(props, "enabled", text="Managed Gradient")
        if not props.enabled:
            col.label(text="Assign or enable to edit", icon='INFO')
            return

        col.prop(props, "paint_target")
        col.prop(props, "gradient_id")
        col.prop(props, "gradient_type")
        col.prop(props, "spread_method")
        col.separator()
        col.prop(props, "start_color")
        col.prop(props, "start_alpha")
        col.prop(props, "start_offset")
        col.prop(props, "end_color")
        col.prop(props, "end_alpha")
        col.prop(props, "end_offset")
        col.separator()
        if props.gradient_type == "LINEAR":
            col.prop(props, "linear_x1")
            col.prop(props, "linear_y1")
            col.prop(props, "linear_x2")
            col.prop(props, "linear_y2")
        else:
            col.prop(props, "radial_cx")
            col.prop(props, "radial_cy")
            col.prop(props, "radial_r")
            col.prop(props, "radial_fx")
            col.prop(props, "radial_fy")


class SPECIO_PT_addon(Panel):
    """Addon preferences sub-panel."""

    bl_label = "Addon"
    bl_idname = "SPECIO_PT_addon"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SVG'
    bl_context = "objectmode"
    bl_parent_id = "SPECIO_PT_svg_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("specio.open_preferences", text="Open Preferences", icon='PREFERENCES')
        col.operator("specio.reset_scene_defaults", text="Reset Scene Defaults")


classes = (
    SPECIO_PT_svg_main,
    SPECIO_PT_import,
    SPECIO_PT_export,
    SPECIO_PT_tools,
    SPECIO_PT_gradient,
    SPECIO_PT_addon,
)


def register():
    """Register all panel classes"""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister all panel classes"""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
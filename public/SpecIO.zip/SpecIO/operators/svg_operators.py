"""SVG operators for SpecIO addon."""

import json

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper, ExportHelper

from ..io_svg.gradient_materials import sync_specio_gradient_material
from ..io_svg import SVGExporter, SVGImporter
from ..properties.svg_properties import apply_preferences_to_scene


class SPECIO_OT_import_svg(Operator, ImportHelper):
    """Import an SVG file into the active scene as curves."""

    bl_idname = "specio.import_svg"
    bl_label = "Import SVG"
    bl_description = "Import SVG file as curves"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".svg"
    filter_glob: StringProperty(
        default="*.svg",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        try:
            apply_preferences_to_scene(context.scene)
            settings = context.scene.specio
            scale = settings.import_scale
            importer = SVGImporter(
                scale=scale,
                height_mode=settings.import_height_mode,
                height_step=settings.import_height_step,
                stroke_overlay_offset=settings.import_stroke_overlay_offset,
                intelligent_split_paths=settings.import_intelligent_split_paths,
            )
            result = importer.import_svg(self.filepath, context)
            self.report({'INFO'}, f"Successfully imported SVG from: {self.filepath}")
            return result

        except Exception as exc:
            self.report({'ERROR'}, f"Failed to import SVG: {exc}")
            return {'CANCELLED'}


class SPECIO_OT_export_svg(Operator, ExportHelper):
    """Export selected curves, images, or camera-view meshes as an SVG file."""

    bl_idname = "specio.export_svg"
    bl_label = "Export SVG"
    bl_description = "Export selected curves, imported images, or camera-view mesh silhouettes as SVG data"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".svg"
    filter_glob: StringProperty(
        default="*.svg",
        options={'HIDDEN'},
        maxlen=255,
    )
    selected_object_names: StringProperty(
        default="",
        options={'HIDDEN'},
    )
    project_from_camera: BoolProperty(
        default=False,
        options={'HIDDEN'},
    )

    def _is_camera_perspective_view(self, context) -> bool:
        area = getattr(context, "area", None)
        if area is None or area.type != "VIEW_3D":
            return False

        space = getattr(context, "space_data", None)
        region_3d = getattr(space, "region_3d", None) if space is not None else None
        return bool(space is not None and space.type == "VIEW_3D" and region_3d is not None and region_3d.view_perspective == "CAMERA")

    def _validate_camera_projection_context(self, context) -> tuple[bool, str | None]:
        if bpy.app.background:
            return False, None
        if context.scene.camera is None:
            return False, "Active scene camera required for SVG export"
        if not self._is_camera_perspective_view(context):
            return False, "SVG export requires the active 3D viewport to be in camera perspective"
        return True, None

    def invoke(self, context, event):
        is_valid, error_message = self._validate_camera_projection_context(context)
        if error_message is not None:
            self.report({'ERROR'}, error_message)
            return {'CANCELLED'}

        self.selected_object_names = json.dumps([obj.name for obj in context.selected_objects])
        self.project_from_camera = is_valid
        return ExportHelper.invoke(self, context, event)

    def _resolve_selected_objects(self, context):
        """Return the intended export selection, preserving names across file-browser context changes."""
        objects = list(context.selected_objects)
        if objects:
            return objects

        if not self.selected_object_names:
            return []

        resolved_objects = []
        for object_name in json.loads(self.selected_object_names):
            obj = bpy.data.objects.get(object_name)
            if obj is not None:
                resolved_objects.append(obj)
        return resolved_objects

    def execute(self, context):
        try:
            apply_preferences_to_scene(context.scene)
            is_valid, error_message = self._validate_camera_projection_context(context)
            if error_message is not None:
                raise ValueError(error_message)

            settings = context.scene.specio
            exporter = SVGExporter(
                scale=settings.export_scale,
                precision=settings.export_precision,
                image_mode=settings.image_export_mode,
                default_fill_color=settings.export_default_fill_color,
                default_stroke_color=settings.export_default_stroke_color,
                apply_stroke=settings.export_apply_stroke,
                stroke_width=settings.export_stroke_width,
                project_through_camera=self.project_from_camera or is_valid,
            )
            result = exporter.export_objects(
                self.filepath,
                self._resolve_selected_objects(context),
                context.scene,
            )
            self.report({'INFO'}, f"Successfully exported SVG to: {self.filepath}")
            return result
        except Exception as exc:
            self.report({'ERROR'}, f"Failed to export SVG: {exc}")
            return {'CANCELLED'}


class SPECIO_OT_open_preferences(Operator):
    """Open the SpecIO preferences in Blender."""

    bl_idname = "specio.open_preferences"
    bl_label = "Open Preferences"
    bl_description = "Open SpecIO addon preferences"
    bl_options = {'REGISTER'}

    def execute(self, context):
        bpy.ops.preferences.addon_show(module="SpecIO")
        return {'FINISHED'}


class SPECIO_OT_reset_scene_defaults(Operator):
    """Reset active scene SpecIO settings to addon defaults."""

    bl_idname = "specio.reset_scene_defaults"
    bl_label = "Reset Scene Defaults"
    bl_description = "Reset this scene's SpecIO settings to the addon default values"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        apply_preferences_to_scene(context.scene, force=True)
        self.report({'INFO'}, "Reset SpecIO scene settings to addon defaults")
        return {'FINISHED'}


class SPECIO_OT_assign_gradient_material(Operator):
    """Create and assign a SpecIO-managed gradient material to selected curve objects."""

    bl_idname = "specio.assign_gradient_material"
    bl_label = "Assign SpecIO Gradient"
    bl_description = "Assign a managed SpecIO gradient material that previews in Blender and exports to SVG"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        curve_objects = [obj for obj in context.selected_objects if obj.type == "CURVE" and obj.data]
        if not curve_objects:
            self.report({'ERROR'}, "Select at least one curve object")
            return {'CANCELLED'}

        for obj in curve_objects:
            material = bpy.data.materials.new(name=f"SpecIOGradient_{obj.name}")
            material["_specio_suspend_gradient_updates"] = True
            try:
                props = material.specio_gradient
                props.enabled = True
                props.paint_target = "FILL"
                props.gradient_type = "LINEAR"
                props.spread_method = "pad"
                props.gradient_id = ""
                props.start_color = (1.0, 1.0, 1.0)
                props.start_alpha = 1.0
                props.start_offset = 0.0
                props.end_color = (0.2, 0.2, 0.2)
                props.end_alpha = 1.0
                props.end_offset = 1.0
                props.linear_x1 = 0.0
                props.linear_y1 = 0.0
                props.linear_x2 = 1.0
                props.linear_y2 = 0.0
                props.radial_cx = 0.5
                props.radial_cy = 0.5
                props.radial_r = 0.5
                props.radial_fx = 0.5
                props.radial_fy = 0.5
            finally:
                material["_specio_suspend_gradient_updates"] = False

            if obj.data.materials:
                obj.data.materials[0] = material
            else:
                obj.data.materials.append(material)
            sync_specio_gradient_material(material, obj, context.scene.specio.export_scale)

        self.report({'INFO'}, f"Assigned SpecIO gradient material to {len(curve_objects)} object(s)")
        return {'FINISHED'}


class SPECIO_OT_split_selected_path(Operator):
    """Split the active curve path into separate objects using SpecIO path-family logic."""

    bl_idname = "specio.split_selected_path"
    bl_label = "Split Selected Path"
    bl_description = "Split the active multi-spline curve into separate path parts and place them in a new collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        active_object = context.active_object
        if active_object is None or active_object.type != "CURVE" or active_object.data is None:
            self.report({'ERROR'}, "Select a curve object to split")
            return {'CANCELLED'}
        if len(active_object.data.splines) < 2:
            self.report({'ERROR'}, "Selected curve must contain at least two splines")
            return {'CANCELLED'}

        settings = context.scene.specio
        importer = SVGImporter(
            scale=settings.import_scale,
            height_mode=settings.import_height_mode,
            height_step=settings.import_height_step,
            stroke_overlay_offset=settings.import_stroke_overlay_offset,
            intelligent_split_paths=True,
        )
        split_objects = importer.split_curve_object(active_object, context)
        if not split_objects:
            self.report({'WARNING'}, "No split parts were created")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        for obj in split_objects:
            obj.select_set(True)
        context.view_layer.objects.active = split_objects[0]

        split_collection_name = split_objects[0].users_collection[0].name if split_objects[0].users_collection else ""
        if split_collection_name:
            self.report({'INFO'}, f"Split path into {len(split_objects)} object(s) in collection {split_collection_name}")
        else:
            self.report({'INFO'}, f"Split path into {len(split_objects)} object(s)")
        return {'FINISHED'}


classes = (
    SPECIO_OT_import_svg,
    SPECIO_OT_export_svg,
    SPECIO_OT_open_preferences,
    SPECIO_OT_reset_scene_defaults,
    SPECIO_OT_assign_gradient_material,
    SPECIO_OT_split_selected_path,
)


def register():
    """Register all operator classes"""
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    """Unregister all operator classes"""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
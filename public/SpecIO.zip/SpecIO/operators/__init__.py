"""
Operators module for SpecIO addon
"""

from . import svg_operators


def register():
    """Register all operator classes"""
    svg_operators.register()


def unregister():
    """Unregister all operator classes"""
    svg_operators.unregister()
"""Backward-compatible import location for the SVG importer."""

from ..io_svg import SVGImporter

__all__ = ("SVGImporter",)
"""Render-based roundtrip regression for SpecIO SVG imports and exports.

Run with Blender from the repository root, for example:

    blender -b --factory-startup --python tests/blender_visual_roundtrip.py -- --svg sample_svgs/AJ_Digital_Camera.svg
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import tempfile

import bpy
from mathutils import Vector


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT.parent))

import SpecIO


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _reset_scene() -> None:
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

    for collection in list(bpy.data.collections):
        if collection.users == 0:
            bpy.data.collections.remove(collection)


def _import_root_collection_name(input_path: Path) -> str:
    return f"{input_path.stem}_SVG"


def _remove_collection_tree(collection_name: str) -> None:
    collection = bpy.data.collections.get(collection_name)
    if collection is None:
        return

    for child_name in [child.name for child in collection.children]:
        _remove_collection_tree(child_name)

    for object_name in [obj.name for obj in collection.objects]:
        obj = bpy.data.objects.get(object_name)
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)

    for scene in bpy.data.scenes:
        if collection.name in scene.collection.children:
            scene.collection.children.unlink(collection)

    for parent in bpy.data.collections:
        if collection.name in parent.children:
            parent.children.unlink(collection)

    if collection.name in bpy.data.collections:
        bpy.data.collections.remove(collection)


def _collection_object_names(collection_name: str) -> list[str]:
    collection = bpy.data.collections.get(collection_name)
    _assert(collection is not None, f"Expected collection '{collection_name}'")
    names: list[str] = []

    def visit(current) -> None:
        for obj in current.objects:
            if obj.name not in names:
                names.append(obj.name)
        for child in current.children:
            visit(child)

    visit(collection)
    return names


def _import_svg(svg_path: Path) -> list[str]:
    return list(bpy.ops.specio.import_svg(filepath=str(svg_path)))


def _export_selected(output_path: Path, object_names: list[str]) -> list[str]:
    bpy.ops.object.select_all(action="DESELECT")
    active = None
    for object_name in object_names:
        obj = bpy.data.objects.get(object_name)
        _assert(obj is not None, f"Expected object '{object_name}'")
        obj.select_set(True)
        if active is None:
            active = obj
    _assert(active is not None, "Expected at least one object to export")
    bpy.context.view_layer.objects.active = active
    return list(bpy.ops.specio.export_svg(filepath=str(output_path)))


def _bounds_for_objects(object_names: list[str]) -> tuple[float, float, float, float]:
    xs: list[float] = []
    ys: list[float] = []
    for object_name in object_names:
        obj = bpy.data.objects.get(object_name)
        _assert(obj is not None, f"Expected object '{object_name}'")
        for corner in obj.bound_box:
            world = obj.matrix_world @ Vector(corner)
            xs.append(float(world.x))
            ys.append(float(world.y))
    _assert(xs and ys, "Expected non-empty object bounds")
    return (min(xs), min(ys), max(xs), max(ys))


def _ensure_camera(bounds: tuple[float, float, float, float]):
    scene = bpy.context.scene
    camera = bpy.data.objects.get("SpecIOVisualCamera")
    if camera is None:
        camera_data = bpy.data.cameras.new("SpecIOVisualCamera")
        camera = bpy.data.objects.new("SpecIOVisualCamera", camera_data)
        scene.collection.objects.link(camera)

    width = max(bounds[2] - bounds[0], 1.0)
    height = max(bounds[3] - bounds[1], 1.0)
    center_x = (bounds[0] + bounds[2]) / 2.0
    center_y = (bounds[1] + bounds[3]) / 2.0

    camera.data.type = "ORTHO"
    camera.data.ortho_scale = max(width, height) * 1.15
    camera.location = (center_x, center_y, 100.0)
    camera.rotation_euler = (0.0, 0.0, 0.0)
    camera.data.clip_start = 0.1
    camera.data.clip_end = 1000.0
    scene.camera = camera
    return camera


def _ensure_sun_light() -> None:
    light = bpy.data.objects.get("SpecIOVisualSun")
    if light is None:
        light_data = bpy.data.lights.new("SpecIOVisualSun", type="SUN")
        light = bpy.data.objects.new("SpecIOVisualSun", light_data)
        bpy.context.scene.collection.objects.link(light)
    light.location = (0.0, 0.0, 100.0)
    light.rotation_euler = (0.0, 0.0, 0.0)
    light.data.energy = 3.0


def _configure_render(output_path: Path) -> None:
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys() else "BLENDER_EEVEE"
    scene.render.resolution_x = 320
    scene.render.resolution_y = 320
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = True
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.filepath = str(output_path)


def _render_to_file(output_path: Path) -> None:
    _configure_render(output_path)
    bpy.ops.render.render(write_still=True)


def _load_pixels(image_path: Path) -> tuple[list[float], tuple[int, int]]:
    image = bpy.data.images.load(str(image_path), check_existing=False)
    try:
        pixels = list(image.pixels)
        size = (int(image.size[0]), int(image.size[1]))
    finally:
        bpy.data.images.remove(image)
    return pixels, size


def _compare_pixels(reference_pixels: list[float], candidate_pixels: list[float]) -> dict[str, float]:
    _assert(len(reference_pixels) == len(candidate_pixels), "Expected rendered images to have the same pixel count")
    total = 0.0
    max_delta = 0.0
    changed_pixels = 0
    pixel_count = len(reference_pixels) // 4

    for index in range(0, len(reference_pixels), 4):
        pixel_delta = 0.0
        for channel in range(4):
            delta = abs(reference_pixels[index + channel] - candidate_pixels[index + channel])
            total += delta
            pixel_delta += delta
            if delta > max_delta:
                max_delta = delta
        if pixel_delta > 0.12:
            changed_pixels += 1

    return {
        "mean_absolute_error": total / len(reference_pixels),
        "max_channel_delta": max_delta,
        "changed_pixel_ratio": changed_pixels / max(pixel_count, 1),
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run render-based SVG roundtrip validation for SpecIO")
    parser.add_argument(
        "--svg",
        default=str(REPO_ROOT / "sample_svgs" / "AJ_Digital_Camera.svg"),
        help="SVG file to import, render, export, reimport, and rerender.",
    )
    parser.add_argument(
        "--mae-threshold",
        type=float,
        default=0.02,
        help="Maximum allowed mean absolute pixel error.",
    )
    parser.add_argument(
        "--changed-pixel-threshold",
        type=float,
        default=0.08,
        help="Maximum allowed fraction of pixels with meaningful RGBA change.",
    )
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    svg_path = Path(args.svg).resolve()
    _assert(svg_path.exists(), f"SVG file does not exist: {svg_path}")

    _reset_scene()
    bpy.context.scene.specio.import_scale = 1.0
    bpy.context.scene.specio.export_scale = 1.0
    bpy.context.scene.specio.export_precision = 3

    with tempfile.TemporaryDirectory(prefix="specio-visual-") as temp_dir:
        work_dir = Path(temp_dir)
        imported_png = work_dir / "imported.png"
        roundtrip_svg = work_dir / "roundtrip.svg"
        roundtrip_png = work_dir / "roundtrip.png"

        import_result = _import_svg(svg_path)
        _assert(import_result == ["FINISHED"], "Initial SVG import did not finish successfully")
        root_collection_name = _import_root_collection_name(svg_path)
        imported_object_names = _collection_object_names(root_collection_name)
        _assert(imported_object_names, "Expected imported objects for visual regression")

        fixed_bounds = _bounds_for_objects(imported_object_names)
        _ensure_camera(fixed_bounds)
        _ensure_sun_light()
        _render_to_file(imported_png)

        export_result = _export_selected(roundtrip_svg, imported_object_names)
        _assert(export_result == ["FINISHED"], "Roundtrip SVG export did not finish successfully")

        _remove_collection_tree(root_collection_name)
        reimport_result = _import_svg(roundtrip_svg)
        _assert(reimport_result == ["FINISHED"], "Roundtrip SVG reimport did not finish successfully")
        _render_to_file(roundtrip_png)

        imported_pixels, imported_size = _load_pixels(imported_png)
        roundtrip_pixels, roundtrip_size = _load_pixels(roundtrip_png)
        _assert(imported_size == roundtrip_size, "Expected imported and roundtrip renders to have the same dimensions")

        metrics = _compare_pixels(imported_pixels, roundtrip_pixels)
        _assert(metrics["mean_absolute_error"] <= args.mae_threshold, f"Visual roundtrip MAE too high: {metrics['mean_absolute_error']:.6f}")
        _assert(metrics["changed_pixel_ratio"] <= args.changed_pixel_threshold, f"Visual roundtrip changed-pixel ratio too high: {metrics['changed_pixel_ratio']:.6f}")

        print(
            json.dumps(
                {
                    "ok": True,
                    "svg": str(svg_path),
                    "import_result": import_result,
                    "export_result": export_result,
                    "reimport_result": reimport_result,
                    "object_count": len(imported_object_names),
                    "render_size": imported_size,
                    "metrics": metrics,
                },
                indent=2,
            )
        )
    return 0


if __name__ == "__main__":
    SpecIO.register()
    try:
        sys.exit(main(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []))
    finally:
        SpecIO.unregister()
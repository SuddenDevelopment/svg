import unittest
import xml.etree.ElementTree as ET

from io_svg.document import SVGPathElement, build_svg_document
from io_svg.gradients import SVGGradient, SVGGradientStop
from io_svg.transform import IDENTITY_TRANSFORM


class TestSVGDocument(unittest.TestCase):
    def test_builds_nested_groups(self):
        svg = build_svg_document(
            [
                SVGPathElement(
                    path_id="shape1",
                    path_data="M 0 0 L 10 10",
                    bounds=(0.0, 0.0, 10.0, 10.0),
                    group_path=("SpecIO_Test", "layer1"),
                )
            ],
            precision=3,
        )

        groups = svg.findall("g")
        self.assertEqual([group.attrib["id"] for group in groups], ["SpecIO_Test"])
        inner_groups = groups[0].findall("g")
        self.assertEqual([group.attrib["id"] for group in inner_groups], ["layer1"])
        path = inner_groups[0].find("path")
        self.assertIsNotNone(path)
        self.assertEqual(path.attrib["id"], "shape1")

    def test_sets_document_bounds(self):
        svg = build_svg_document(
            [
                SVGPathElement("a", "M 0 0", (0.0, 0.0, 10.0, 10.0)),
                SVGPathElement("b", "M 0 0", (-5.0, 5.0, 15.0, 25.0)),
            ],
            precision=2,
        )

        self.assertEqual(svg.attrib["width"], "20")
        self.assertEqual(svg.attrib["height"], "25")
        self.assertEqual(svg.attrib["viewBox"], "-5 0 20 25")

    def test_preserves_supplied_path_order(self):
        svg = build_svg_document(
            [
                SVGPathElement("zeta", "M 0 0", (0.0, 0.0, 1.0, 1.0), ("b",)),
                SVGPathElement("alpha", "M 0 0", (0.0, 0.0, 1.0, 1.0), ("a",)),
                SVGPathElement("beta", "M 0 0", (0.0, 0.0, 1.0, 1.0), ("a",)),
            ],
            precision=2,
        )

        xml_text = ET.tostring(svg, encoding="unicode")
        self.assertLess(xml_text.index('id="zeta"'), xml_text.index('id="alpha"'))
        self.assertLess(xml_text.index('id="alpha"'), xml_text.index('id="beta"'))

    def test_preserves_path_presentation_attributes(self):
        svg = build_svg_document(
            [
                SVGPathElement(
                    "styled",
                    "M 0 0",
                    (0.0, 0.0, 1.0, 1.0),
                    attributes={"fill": "red", "stroke": "blue", "stroke-width": "2.5"},
                )
            ],
            precision=2,
        )

        path = svg.find("path")
        self.assertIsNotNone(path)
        self.assertEqual(path.attrib["fill"], "red")
        self.assertEqual(path.attrib["stroke"], "blue")
        self.assertEqual(path.attrib["stroke-width"], "2.5")

    def test_writes_gradient_defs(self):
        svg = build_svg_document(
            [
                SVGPathElement(
                    "gradientShape",
                    "M 0 0",
                    (0.0, 0.0, 1.0, 1.0),
                    attributes={"fill": "url(#bodyGradient)", "stroke": "none"},
                )
            ],
            precision=3,
            gradients=[
                SVGGradient(
                    gradient_id="bodyGradient",
                    kind="linear",
                    gradient_units="objectBoundingBox",
                    spread_method="pad",
                    transform=IDENTITY_TRANSFORM,
                    x1=0.0,
                    y1=0.0,
                    x2=1.0,
                    y2=0.0,
                    stops=[
                        SVGGradientStop(0.0, (1.0, 0.0, 0.0, 1.0)),
                        SVGGradientStop(1.0, (0.0, 0.0, 1.0, 0.5)),
                    ],
                )
            ],
        )

        defs = svg.find("defs")
        self.assertIsNotNone(defs)
        gradient = defs.find("linearGradient")
        self.assertIsNotNone(gradient)
        self.assertEqual(gradient.attrib["id"], "bodyGradient")
        stops = gradient.findall("stop")
        self.assertEqual(len(stops), 2)
        self.assertEqual(stops[0].attrib["stop-color"], "#ff0000")
        self.assertEqual(stops[1].attrib["stop-opacity"], "0.5")


if __name__ == "__main__":
    unittest.main()
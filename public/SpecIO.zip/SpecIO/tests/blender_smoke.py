"""Headless Blender smoke tests for SpecIO.

Run with Blender from the repository root, for example:

    blender -b --factory-startup --python tests/blender_smoke.py -- --scenario all
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys
import tempfile
import xml.etree.ElementTree as ET

import bpy
from mathutils import Vector


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT.parent))

import SpecIO
from SpecIO.io_svg import SVGExporter


SCENARIO_NAMES = (
    "path-rich",
    "rotated-arc",
    "large-arc",
    "compound-fill",
    "height-offsets",
    "scene-defaults-reset",
    "transform-stack-roundtrip",
    "collection-hierarchy",
    "hierarchy-order-roundtrip",
    "malformed-input",
    "style-roundtrip",
    "gradient-material",
    "managed-gradient-export",
    "multi-spline-export",
    "text-object-export",
    "export-style-defaults",
    "curve-camera-export",
    "text-extrude-camera-export",
    "text-bevel-camera-export",
    "intelligent-split",
    "export-selection-persistence",
    "camera-mesh-export",
    "camera-mesh-ordering",
    "sample-camera-roundtrip",
)

SUPPORTED_SVG_TAGS = {"rect", "circle", "ellipse", "line", "path", "polygon", "polyline"}
NUMBER_PATTERN = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)")


def _clear_selection() -> None:
    bpy.ops.object.select_all(action="DESELECT")


def _select_object(name: str):
    obj = bpy.data.objects.get(name)
    if obj is None:
        return None
    _clear_selection()
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    return obj


def _write_svg(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _assert_rgba_close(actual, expected: tuple[float, float, float, float], message: str) -> None:
    rounded_actual = tuple(round(float(component), 3) for component in actual)
    rounded_expected = tuple(round(component, 3) for component in expected)
    _assert(rounded_actual == rounded_expected, f"{message}: expected {rounded_expected}, got {rounded_actual}")


def _assert_has_node_tree(material, message: str) -> None:
    node_tree = getattr(material, "node_tree", None)
    _assert(node_tree is not None and len(node_tree.nodes) > 0, message)


def _import_svg(input_path: Path) -> list[str]:
    return list(bpy.ops.specio.import_svg(filepath=str(input_path)))


def _export_selected(output_path: Path, *object_names: str) -> tuple[list[str], str]:
    _clear_selection()
    active_object = None
    for object_name in object_names:
        obj = bpy.data.objects.get(object_name)
        _assert(obj is not None, f"Expected imported object '{object_name}'")
        if active_object is None:
            active_object = obj
        obj.select_set(True)

    _assert(active_object is not None, "Expected at least one object to export")
    bpy.context.view_layer.objects.active = active_object
    result = list(bpy.ops.specio.export_svg(filepath=str(output_path)))
    return result, output_path.read_text(encoding="utf-8")


def _export_selected_with_exporter(output_path: Path, *object_names: str, project_through_camera: bool = False) -> tuple[list[str], str]:
    _clear_selection()
    objects = []
    for object_name in object_names:
        obj = bpy.data.objects.get(object_name)
        _assert(obj is not None, f"Expected imported object '{object_name}'")
        obj.select_set(True)
        objects.append(obj)

    exporter = SVGExporter(
        scale=bpy.context.scene.specio.export_scale,
        precision=bpy.context.scene.specio.export_precision,
        image_mode=bpy.context.scene.specio.image_export_mode,
        default_fill_color=bpy.context.scene.specio.export_default_fill_color,
        default_stroke_color=bpy.context.scene.specio.export_default_stroke_color,
        apply_stroke=bpy.context.scene.specio.export_apply_stroke,
        stroke_width=bpy.context.scene.specio.export_stroke_width,
        project_through_camera=project_through_camera,
    )
    result = list(exporter.export_objects(str(output_path), objects, bpy.context.scene))
    return result, output_path.read_text(encoding="utf-8")


def _parse_exported_svg(output_text: str):
    namespace = {"svg": "http://www.w3.org/2000/svg"}
    return ET.fromstring(output_text), namespace


def _path_bounds(path_data: str) -> tuple[float, float, float, float]:
    values = [float(value) for value in NUMBER_PATTERN.findall(path_data or "")]
    _assert(len(values) >= 2 and len(values) % 2 == 0, f"Expected paired SVG coordinates in path data: {path_data}")
    xs = values[0::2]
    ys = values[1::2]
    return (min(xs), min(ys), max(xs), max(ys))


def _strip_namespace(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def _supported_svg_elements(root: ET.Element) -> list[ET.Element]:
    return [element for element in root.iter() if _strip_namespace(element.tag) in SUPPORTED_SVG_TAGS]


def _import_root_collection_name(input_path: Path) -> str:
    return f"{input_path.stem}_SVG"


def _collection_object_names(collection_name: str) -> list[str]:
    collection = bpy.data.collections.get(collection_name)
    _assert(collection is not None, f"Expected collection '{collection_name}'")
    names: list[str] = []

    def visit(current) -> None:
        for obj in current.objects:
            if obj.name not in names:
                names.append(obj.name)
        for child in current.children:
            visit(child)

    visit(collection)
    return names


def _object_bounds_2d(object_name: str) -> tuple[float, float, float, float]:
    obj = bpy.data.objects.get(object_name)
    _assert(obj is not None, f"Expected object '{object_name}'")
    vertices = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    xs = [vertex.x for vertex in vertices]
    ys = [vertex.y for vertex in vertices]
    return (min(xs), min(ys), max(xs), max(ys))


def _assert_bounds_close(
    actual: tuple[float, float, float, float],
    expected: tuple[float, float, float, float],
    tolerance: float,
    message: str,
) -> None:
    deltas = [abs(float(actual[index]) - float(expected[index])) for index in range(4)]
    _assert(max(deltas) <= tolerance, f"{message}: expected {expected}, got {actual}")


def _remove_collection_tree(collection_name: str) -> None:
    collection = bpy.data.collections.get(collection_name)
    if collection is None:
        return

    child_names = [child.name for child in collection.children]
    object_names = [obj.name for obj in collection.objects]

    for child_name in child_names:
        _remove_collection_tree(child_name)

    for object_name in object_names:
        obj = bpy.data.objects.get(object_name)
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)

    for scene in bpy.data.scenes:
        if collection.name in scene.collection.children:
            scene.collection.children.unlink(collection)

    for parent in bpy.data.collections:
        if collection.name in parent.children:
            parent.children.unlink(collection)

    if collection.name in bpy.data.collections:
        bpy.data.collections.remove(collection)


def _direct_child_ids(parent: ET.Element) -> list[str]:
    return [child.get("id") for child in parent if child.get("id")]


def _style_snapshot(object_name: str) -> dict[str, str | None]:
    obj = bpy.data.objects.get(object_name)
    _assert(obj is not None, f"Expected object '{object_name}'")
    return {
        "fill": obj.get("specio_svg_fill"),
        "stroke": obj.get("specio_svg_stroke"),
        "stroke-width": obj.get("specio_svg_stroke_width"),
        "stroke-linecap": obj.get("specio_svg_stroke_linecap"),
        "stroke-linejoin": obj.get("specio_svg_stroke_linejoin"),
    }


def _gradient_snapshot(object_name: str) -> dict[str, str | None]:
    obj = bpy.data.objects.get(object_name)
    _assert(obj is not None, f"Expected object '{object_name}'")
    material = obj.data.materials[0] if obj.data and obj.data.materials else None
    return {
        "gradient_id": material.get("specio_gradient_id") if material else None,
        "gradient_kind": material.get("specio_gradient_kind") if material else None,
    }


def _is_stroke_helper_object_name(object_name: str) -> bool:
    obj = bpy.data.objects.get(object_name)
    return bool(obj and obj.get("specio_svg_stroke_helper"))


def run_path_rich_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "path_rich_in.svg"
    output_path = work_dir / "path_rich_out.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="200" height="120">
  <g id="paths">
    <path id="relative1" d="m 10 10 h 30 v 15 l -10 10 z" />
    <path id="cubic1" d="M 60 20 C 80 20 80 50 100 50 c 10 0 10 20 20 20" />
  </g>
</svg>
""",
    )

    result = _import_svg(input_path)
    relative_obj = bpy.data.objects.get("relative1")
    cubic_obj = bpy.data.objects.get("cubic1")

    _assert(result == ["FINISHED"], "Path-rich SVG import did not finish successfully")
    _assert(relative_obj is not None, "Expected imported object 'relative1'")
    _assert(cubic_obj is not None, "Expected imported object 'cubic1'")

    export_result, output_text = _export_selected(output_path, "relative1", "cubic1")

    _assert(export_result == ["FINISHED"], "Path-rich SVG export did not finish successfully")
    _assert('id="relative1"' in output_text, "Exported SVG is missing relative1 path id")
    _assert('id="cubic1"' in output_text, "Exported SVG is missing cubic1 path id")
    _assert(" C " in output_text, "Exported SVG is missing cubic path commands")

    return {
        "scenario": "path-rich",
        "import_result": result,
        "export_result": export_result,
        "spline_types": {
            "relative1": [spline.type for spline in relative_obj.data.splines],
            "cubic1": [spline.type for spline in cubic_obj.data.splines],
        },
    }


def run_rotated_arc_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "rotated_arc_in.svg"
    output_path = work_dir / "rotated_arc_out.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">
  <path id="rotArc" d="M 10 20 A 30 15 45 0 1 80 70" />
</svg>
""",
    )

    result = _import_svg(input_path)
    imported = bpy.data.objects.get("rotArc")

    _assert(result == ["FINISHED"], "Rotated-arc SVG import did not finish successfully")
    _assert(imported is not None, "Expected imported object 'rotArc'")
    _assert([spline.type for spline in imported.data.splines] == ["BEZIER"], "Rotated arc should import as a BEZIER spline")

    export_result, output_text = _export_selected(output_path, "rotArc")

    _assert(export_result == ["FINISHED"], "Rotated-arc SVG export did not finish successfully")
    _assert('id="rotArc"' in output_text, "Exported rotated arc is missing its path id")
    _assert(" C " in output_text, "Exported rotated arc is missing cubic path commands")

    return {
        "scenario": "rotated-arc",
        "import_result": result,
        "export_result": export_result,
        "spline_types": [spline.type for spline in imported.data.splines],
    }


def run_large_arc_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "large_arc_in.svg"
    output_path = work_dir / "large_arc_out.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">
  <path id="largeArc" d="M 10 10 A 30 20 0 1 1 50 20" />
</svg>
""",
    )

    result = _import_svg(input_path)
    imported = bpy.data.objects.get("largeArc")

    _assert(result == ["FINISHED"], "Large-arc SVG import did not finish successfully")
    _assert(imported is not None, "Expected imported object 'largeArc'")
    _assert([spline.type for spline in imported.data.splines] == ["BEZIER"], "Large arc should import as a BEZIER spline")

    export_result, output_text = _export_selected(output_path, "largeArc")

    _assert(export_result == ["FINISHED"], "Large-arc SVG export did not finish successfully")
    _assert('id="largeArc"' in output_text, "Exported large arc is missing its path id")
    _assert(output_text.count(" C ") >= 3, "Exported large arc should produce at least three cubic commands")

    return {
        "scenario": "large-arc",
        "import_result": result,
        "export_result": export_result,
        "spline_types": [spline.type for spline in imported.data.splines],
        "cubic_command_count": output_text.count(" C "),
    }


def run_collection_hierarchy_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "collection_hierarchy_in.svg"
    output_path = work_dir / "collection_hierarchy_out.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80" viewBox="0 0 120 80">
    <g id="Layer_A">
        <g id="Detail">
            <path id="leafA" d="M 10 10 L 30 10 L 30 30 Z" />
        </g>
    </g>
    <g id="Layer_B">
        <path id="leafB" d="M 60 20 L 80 20 L 80 40 Z" />
    </g>
</svg>
""",
    )

    result = _import_svg(input_path)
    leaf_a = bpy.data.objects.get("leafA")
    leaf_b = bpy.data.objects.get("leafB")

    _assert(result == ["FINISHED"], "Collection-hierarchy SVG import did not finish successfully")
    _assert(leaf_a is not None, "Expected imported object 'leafA'")
    _assert(leaf_b is not None, "Expected imported object 'leafB'")

    export_result, output_text = _export_selected(output_path, "leafA", "leafB")
    _assert(export_result == ["FINISHED"], "Collection-hierarchy SVG export did not finish successfully")

    svg, namespace = _parse_exported_svg(output_text)
    layer_a = svg.find("svg:g[@id='Layer_A']", namespace)
    layer_b = svg.find("svg:g[@id='Layer_B']", namespace)
    _assert(layer_a is not None, "Expected Layer_A export group")
    _assert(layer_b is not None, "Expected Layer_B export group")

    detail_group = layer_a.find("svg:g[@id='Detail']", namespace)
    _assert(detail_group is not None, "Expected nested detail group under Layer_A")
    _assert(detail_group.find("svg:path[@id='leafA']", namespace) is not None, "Expected leafA path inside nested detail group")
    _assert(layer_b.find("svg:path[@id='leafB']", namespace) is not None, "Expected leafB path inside Layer_B group")

    return {
        "scenario": "collection-hierarchy",
        "import_result": result,
        "export_result": export_result,
        "group_ids": [
            layer_a.get("id"),
            detail_group.get("id"),
            layer_b.get("id"),
        ],
    }


def run_malformed_input_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "malformed_input_in.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80">
  <g id="broken">
    <path id="badPath" d="M 0 0 L 10 10"
</svg>
""",
    )

    existing_objects = {obj.name for obj in bpy.data.objects}
    existing_collections = {collection.name for collection in bpy.data.collections}

    error_message = None
    try:
        result = _import_svg(input_path)
    except RuntimeError as exc:
        result = ["CANCELLED"]
        error_message = str(exc)

    _assert(result == ["CANCELLED"], "Malformed SVG import should return CANCELLED")
    _assert(error_message is not None and "Failed to parse SVG file" in error_message, "Malformed SVG import should report a parse failure")
    _assert({obj.name for obj in bpy.data.objects} == existing_objects, "Malformed SVG import should not create objects")
    _assert(
        {collection.name for collection in bpy.data.collections} == existing_collections,
        "Malformed SVG import should not create collections",
    )
    _assert("malformed_input_in_SVG" not in bpy.data.collections, "Malformed SVG import should not create the root import collection")

    return {
        "scenario": "malformed-input",
        "import_result": result,
        "error_contains_parse_failure": error_message is not None and "Failed to parse SVG file" in error_message,
        "object_count": len(existing_objects),
        "collection_count": len(existing_collections),
    }


def run_style_roundtrip_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "style_roundtrip_in.svg"
    output_path = work_dir / "style_roundtrip_out.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80" viewBox="0 0 120 80">
    <g id="styleRoot" stroke="orange" stroke-linecap="round" stroke-linejoin="bevel">
        <path id="styledVisible" d="M 10 10 L 40 10 L 40 30 Z" fill="red" style="stroke-width: 2.5" />
        <path id="styledVisibleTwin" d="M 85 10 L 115 10 L 115 30 Z" fill="red" style="stroke-width: 2.5" />
        <path id="defaultFill" d="M 50 10 L 80 10 L 80 30 Z" />
        <path id="openSquareCap" d="M 10 45 L 40 45" fill="none" stroke="#2244aa" stroke-width="4" stroke-linecap="square" />
        <path id="unstyledNone" d="M 50 45 L 80 45 L 80 70 Z" fill="none" stroke="none" />
        <path id="hiddenShape" d="M 60 10 L 90 10 L 90 30 Z" display="none" />
        <g id="hiddenGroup" visibility="hidden">
            <path id="hiddenNested" d="M 10 50 L 40 50 L 40 70 Z" />
        </g>
    </g>
</svg>
""",
    )

    result = _import_svg(input_path)
    visible = bpy.data.objects.get("styledVisible")
    visible_stroke = bpy.data.objects.get("styledVisible__stroke")
    visible_twin = bpy.data.objects.get("styledVisibleTwin")
    visible_twin_stroke = bpy.data.objects.get("styledVisibleTwin__stroke")
    default_fill = bpy.data.objects.get("defaultFill")
    default_fill_stroke = bpy.data.objects.get("defaultFill__stroke")
    open_square_cap = bpy.data.objects.get("openSquareCap")
    unstyled_none = bpy.data.objects.get("unstyledNone")
    hidden_shape = bpy.data.objects.get("hiddenShape")
    hidden_nested = bpy.data.objects.get("hiddenNested")

    _assert(result == ["FINISHED"], "Style-roundtrip SVG import did not finish successfully")
    _assert(visible is not None, "Expected imported object 'styledVisible'")
    _assert(visible_stroke is not None, "Expected imported helper object 'styledVisible__stroke'")
    _assert(visible_twin is not None, "Expected imported object 'styledVisibleTwin'")
    _assert(visible_twin_stroke is not None, "Expected imported helper object 'styledVisibleTwin__stroke'")
    _assert(default_fill is not None, "Expected imported object 'defaultFill'")
    _assert(default_fill_stroke is not None, "Expected imported helper object 'defaultFill__stroke'")
    _assert(open_square_cap is not None, "Expected imported object 'openSquareCap'")
    _assert(unstyled_none is not None, "Expected imported object 'unstyledNone'")
    _assert(hidden_shape is None, "Hidden element should not be imported")
    _assert(hidden_nested is None, "Hidden group contents should not be imported")
    visible_material = visible.data.materials[0] if visible.data.materials else None
    visible_stroke_material = visible_stroke.data.materials[0] if visible_stroke.data.materials else None
    visible_twin_material = visible_twin.data.materials[0] if visible_twin.data.materials else None
    visible_twin_stroke_material = visible_twin_stroke.data.materials[0] if visible_twin_stroke.data.materials else None
    default_fill_material = default_fill.data.materials[0] if default_fill.data.materials else None
    default_fill_stroke_material = default_fill_stroke.data.materials[0] if default_fill_stroke.data.materials else None
    open_square_cap_material = open_square_cap.data.materials[0] if open_square_cap.data.materials else None
    _assert(visible.get("specio_svg_fill") == "red", "Expected imported fill style metadata")
    _assert(visible.get("specio_svg_stroke") == "orange", "Expected inherited stroke style metadata")
    _assert(visible.get("specio_svg_stroke_width") == "2.5", "Expected imported stroke-width style metadata")
    _assert(visible.get("specio_svg_stroke_linecap") == "round", "Expected inherited stroke-linecap style metadata")
    _assert(visible.get("specio_svg_stroke_linejoin") == "bevel", "Expected inherited stroke-linejoin style metadata")
    _assert(round(visible.data.bevel_depth, 3) == 0.0, "Expected fill object to avoid stroke bevel geometry")
    _assert(visible.data.dimensions == "2D", "Expected filled curve to remain 2D")
    _assert(visible.data.fill_mode == "BOTH", "Expected filled curve to use BOTH fill mode")
    _assert(len(visible.data.materials) == 1, "Expected imported styled curve to receive a display material")
    _assert_has_node_tree(visible_material, "Expected styledVisible to receive a node-based material")
    _assert_rgba_close(visible_material.diffuse_color, (1.0, 0.0, 0.0, 1.0), "Expected filled curve material to use fill color")
    _assert_rgba_close(visible.color, (1.0, 0.0, 0.0, 1.0), "Expected fill object display color to prioritize fill color")
    _assert(bool(visible_stroke.get("specio_svg_stroke_helper")), "Expected stroke helper flag on styledVisible__stroke")
    _assert(visible_stroke.get("specio_svg_stroke_source") == "styledVisible", "Expected styledVisible__stroke to record its source object")
    _assert(visible_stroke.data.dimensions == "3D", "Expected stroke helper to use 3D stroke display")
    _assert(round(visible_stroke.location.z - visible.location.z, 4) == 0.12, "Expected stroke helper overlay offset scaled to document size above fill object")
    _assert(round(visible_stroke.data.bevel_depth, 3) == 1.25, "Expected stroke helper bevel depth from stroke-width")
    _assert(len(visible_stroke.data.materials) == 1, "Expected styledVisible__stroke to receive a material")
    _assert_has_node_tree(visible_stroke_material, "Expected styledVisible__stroke to receive a node-based material")
    _assert_rgba_close(visible_stroke_material.diffuse_color, (1.0, 0.647, 0.0, 1.0), "Expected stroke helper material to use stroke color")
    _assert_rgba_close(visible_stroke.color, (1.0, 0.647, 0.0, 1.0), "Expected stroke helper display color to use stroke color")
    _assert(len(visible_twin.data.materials) == 1, "Expected same-color sibling curve to receive a material")
    _assert_has_node_tree(visible_twin_material, "Expected styledVisibleTwin to receive a node-based material")
    _assert_rgba_close(visible_twin_material.diffuse_color, (1.0, 0.0, 0.0, 1.0), "Expected same-color sibling material to use fill color")
    _assert(visible_material is visible_twin_material, "Expected same-color fill objects to share one material datablock")
    _assert(visible_stroke_material is visible_twin_stroke_material, "Expected same-color stroke helpers to share one material datablock")
    _assert(len(default_fill.data.materials) == 1, "Expected default-filled curve to receive a material")
    _assert_has_node_tree(default_fill_material, "Expected defaultFill to receive a node-based material")
    _assert_rgba_close(default_fill_material.diffuse_color, (0.0, 0.0, 0.0, 1.0), "Expected default-filled curve to receive a black material")
    _assert(round(default_fill.data.bevel_depth, 3) == 0.0, "Expected default fill object to avoid stroke bevel geometry")
    _assert(len(default_fill_stroke.data.materials) == 1, "Expected defaultFill__stroke to receive a material")
    _assert_has_node_tree(default_fill_stroke_material, "Expected defaultFill__stroke to receive a node-based material")
    _assert(round(default_fill_stroke.location.z - default_fill.location.z, 4) == 0.12, "Expected inherited stroke helper overlay offset scaled to document size above fill object")
    _assert(round(default_fill_stroke.data.bevel_depth, 3) == 0.5, "Expected inherited default stroke width to create helper bevel depth 0.5")
    _assert_rgba_close(default_fill_stroke_material.diffuse_color, (1.0, 0.647, 0.0, 1.0), "Expected inherited stroke helper material to use stroke color")
    _assert(open_square_cap.data.dimensions == "3D", "Expected fill none curve to switch to 3D display mode")
    _assert(round(open_square_cap.data.bevel_depth, 3) == 2.0, "Expected open square-cap stroke width to map to bevel depth")
    _assert(open_square_cap.data.use_fill_caps, "Expected square linecap to enable fill caps")
    _assert(len(open_square_cap.data.materials) == 1, "Expected open stroke-only curve to receive a material")
    _assert_has_node_tree(open_square_cap_material, "Expected openSquareCap to receive a node-based material")
    _assert_rgba_close(open_square_cap_material.diffuse_color, (0.133, 0.267, 0.667, 1.0), "Expected stroke-only curve material to use stroke color")
    _assert_rgba_close(open_square_cap.color, (0.133, 0.267, 0.667, 1.0), "Expected explicit stroke color to drive open path display")
    _assert(bpy.data.objects.get("openSquareCap__stroke") is None, "Expected no helper duplicate for stroke-only path")
    _assert(unstyled_none.get("specio_svg_fill") == "none", "Expected explicit fill none metadata")
    _assert(unstyled_none.get("specio_svg_stroke") == "none", "Expected explicit stroke none metadata")

    export_result, output_text = _export_selected(output_path, "styledVisible", "styledVisible__stroke", "unstyledNone")
    svg, namespace = _parse_exported_svg(output_text)
    path = svg.find(".//svg:path[@id='styledVisible']", namespace)
    none_path = svg.find(".//svg:path[@id='unstyledNone']", namespace)
    helper_path = svg.find(".//svg:path[@id='styledVisible__stroke']", namespace)

    _assert(export_result == ["FINISHED"], "Style-roundtrip SVG export did not finish successfully")
    _assert(path is not None, "Expected styledVisible path in exported SVG")
    _assert(none_path is not None, "Expected unstyledNone path in exported SVG")
    _assert(path.get("fill") == "red", "Expected exported fill style")
    _assert(path.get("stroke") == "orange", "Expected exported stroke style")
    _assert(path.get("stroke-width") == "2.5", "Expected exported stroke-width style")
    _assert(path.get("stroke-linecap") == "round", "Expected exported stroke-linecap style")
    _assert(path.get("stroke-linejoin") == "bevel", "Expected exported stroke-linejoin style")
    _assert(none_path.get("fill") == "none", "Expected exported fill none style")
    _assert(none_path.get("stroke") == "none", "Expected exported stroke none style")
    _assert(helper_path is None, "Expected synthetic stroke helper object to be skipped during export")
    _assert("hiddenShape" not in output_text, "Hidden element should not appear in exported SVG")
    _assert("hiddenNested" not in output_text, "Hidden nested element should not appear in exported SVG")

    return {
        "scenario": "style-roundtrip",
        "import_result": result,
        "export_result": export_result,
        "style": {
            "fill": path.get("fill"),
            "stroke": path.get("stroke"),
            "stroke-width": path.get("stroke-width"),
            "stroke-linecap": path.get("stroke-linecap"),
            "stroke-linejoin": path.get("stroke-linejoin"),
        },
        "none_style": {
            "fill": none_path.get("fill"),
            "stroke": none_path.get("stroke"),
        },
    }


def run_gradient_material_scenario(work_dir: Path) -> dict[str, object]:
        input_path = work_dir / "gradient_material_in.svg"
        _write_svg(
                input_path,
                """<svg xmlns="http://www.w3.org/2000/svg" width="100" height="60" viewBox="0 0 100 60">
    <defs>
        <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#ff0000" />
            <stop offset="100%" stop-color="#0000ff" />
        </linearGradient>
        <radialGradient id="lensGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#ffffff" />
            <stop offset="100%" stop-color="#000000" />
        </radialGradient>
    </defs>
    <rect id="gradientRect" x="10" y="10" width="30" height="20" fill="url(#bodyGradient)" />
    <circle id="gradientCircle" cx="70" cy="20" r="10" fill="url(#lensGradient)" />
</svg>
""",
        )

        result = _import_svg(input_path)
        gradient_rect = bpy.data.objects.get("gradientRect")
        gradient_circle = bpy.data.objects.get("gradientCircle")

        _assert(result == ["FINISHED"], "Gradient-material SVG import did not finish successfully")
        _assert(gradient_rect is not None, "Expected imported object 'gradientRect'")
        _assert(gradient_circle is not None, "Expected imported object 'gradientCircle'")
        _assert(len(gradient_rect.data.materials) == 1, "Expected a generated gradient material on gradientRect")
        _assert(len(gradient_circle.data.materials) == 1, "Expected a generated gradient material on gradientCircle")

        rect_material = gradient_rect.data.materials[0]
        circle_material = gradient_circle.data.materials[0]
        _assert_has_node_tree(rect_material, "Expected gradientRect material to have a node tree")
        _assert_has_node_tree(circle_material, "Expected gradientCircle material to have a node tree")
        _assert(rect_material.get("specio_gradient_id") == "bodyGradient", "Expected linear gradient id metadata")
        _assert(circle_material.get("specio_gradient_id") == "lensGradient", "Expected radial gradient id metadata")
        _assert(rect_material.get("specio_gradient_kind") == "linear", "Expected linear gradient kind metadata")
        _assert(circle_material.get("specio_gradient_kind") == "radial", "Expected radial gradient kind metadata")

        rect_node_types = sorted(node.bl_idname for node in rect_material.node_tree.nodes)
        circle_node_types = sorted(node.bl_idname for node in circle_material.node_tree.nodes)
        _assert("ShaderNodeValToRGB" in rect_node_types, "Expected a color ramp in linear gradient material")
        _assert("ShaderNodeValToRGB" in circle_node_types, "Expected a color ramp in radial gradient material")

        return {
                "scenario": "gradient-material",
                "import_result": result,
                "rect_material": {
                        "name": rect_material.name,
                        "gradient_id": rect_material.get("specio_gradient_id"),
                        "gradient_kind": rect_material.get("specio_gradient_kind"),
                },
                "circle_material": {
                        "name": circle_material.name,
                        "gradient_id": circle_material.get("specio_gradient_id"),
                        "gradient_kind": circle_material.get("specio_gradient_kind"),
                },
        }


def run_managed_gradient_export_scenario(work_dir: Path) -> dict[str, object]:
    output_path = work_dir / "managed_gradient_out.svg"

    bpy.ops.curve.primitive_bezier_circle_add(radius=1.0, location=(0.0, 0.0, 0.0))
    linear_obj = bpy.context.active_object
    linear_obj.name = "managedLinear"

    bpy.ops.curve.primitive_bezier_circle_add(radius=0.75, location=(3.0, 0.0, 0.0))
    radial_obj = bpy.context.active_object
    radial_obj.name = "managedRadial"

    _clear_selection()
    linear_obj.select_set(True)
    radial_obj.select_set(True)
    bpy.context.view_layer.objects.active = linear_obj
    assign_result = list(bpy.ops.specio.assign_gradient_material())
    _assert(assign_result == ["FINISHED"], "Managed gradient assignment operator did not finish successfully")

    linear_material = linear_obj.data.materials[0]
    linear_props = linear_material.specio_gradient
    linear_props.gradient_type = "LINEAR"
    linear_props.paint_target = "FILL"
    linear_props.gradient_id = "previewLinear"
    linear_props.start_color = (1.0, 0.0, 0.0)
    linear_props.start_alpha = 1.0
    linear_props.end_color = (0.0, 0.0, 1.0)
    linear_props.end_alpha = 1.0
    linear_props.linear_x1 = 0.0
    linear_props.linear_y1 = 0.0
    linear_props.linear_x2 = 1.0
    linear_props.linear_y2 = 0.0

    radial_material = radial_obj.data.materials[0]
    radial_props = radial_material.specio_gradient
    radial_props.gradient_type = "RADIAL"
    radial_props.paint_target = "FILL"
    radial_props.gradient_id = "previewRadial"
    radial_props.start_color = (1.0, 1.0, 1.0)
    radial_props.start_alpha = 1.0
    radial_props.end_color = (0.0, 0.0, 0.0)
    radial_props.end_alpha = 0.5
    radial_props.radial_cx = 0.5
    radial_props.radial_cy = 0.5
    radial_props.radial_r = 0.5
    radial_props.radial_fx = 0.5
    radial_props.radial_fy = 0.5

    export_result, output_text = _export_selected(output_path, "managedLinear", "managedRadial")
    svg, namespace = _parse_exported_svg(output_text)
    defs = svg.find("svg:defs", namespace)
    linear_gradient = svg.find("svg:defs/svg:linearGradient[@id='previewLinear']", namespace)
    radial_gradient = svg.find("svg:defs/svg:radialGradient[@id='previewRadial']", namespace)
    linear_path = svg.find(".//svg:path[@id='managedLinear']", namespace)
    radial_path = svg.find(".//svg:path[@id='managedRadial']", namespace)

    _assert(export_result == ["FINISHED"], "Managed gradient SVG export did not finish successfully")
    _assert(defs is not None, "Expected SVG defs in managed gradient export")
    _assert(linear_gradient is not None, "Expected exported linearGradient definition")
    _assert(radial_gradient is not None, "Expected exported radialGradient definition")
    _assert(linear_path is not None and linear_path.get("fill") == "url(#previewLinear)", "Expected managedLinear to reference exported linear gradient")
    _assert(radial_path is not None and radial_path.get("fill") == "url(#previewRadial)", "Expected managedRadial to reference exported radial gradient")
    _assert(len(linear_gradient.findall("svg:stop", namespace)) == 2, "Expected two linear gradient stops")
    _assert(len(radial_gradient.findall("svg:stop", namespace)) == 2, "Expected two radial gradient stops")

    return {
        "scenario": "managed-gradient-export",
        "assign_result": assign_result,
        "export_result": export_result,
        "gradient_ids": [linear_gradient.get("id"), radial_gradient.get("id")],
        "path_fills": [linear_path.get("fill"), radial_path.get("fill")],
    }


def run_multi_spline_export_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "multi_spline_in.svg"
    output_path = work_dir / "multi_spline_out.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="60" viewBox="0 0 120 60">
  <path id="multiShape" d="M 0 0 L 20 0 L 20 20 Z M 40 0 L 60 0 L 60 20 Z" />
</svg>
""",
    )

    result = _import_svg(input_path)
    multi_shape = bpy.data.objects.get("multiShape")

    _assert(result == ["FINISHED"], "Multi-spline SVG import did not finish successfully")
    _assert(multi_shape is not None, "Expected imported object 'multiShape'")
    _assert(len(multi_shape.data.splines) == 2, "Expected imported object to contain two splines")

    export_result, output_text = _export_selected(output_path, "multiShape")
    svg, namespace = _parse_exported_svg(output_text)
    paths = svg.findall(".//svg:path", namespace)
    path_ids = [path.get("id") for path in paths]

    _assert(export_result == ["FINISHED"], "Multi-spline SVG export did not finish successfully")
    _assert(path_ids == ["multiShape_001", "multiShape_002"], "Expected deterministic multi-spline export path ids")

    return {
        "scenario": "multi-spline-export",
        "import_result": result,
        "export_result": export_result,
        "path_ids": path_ids,
    }


def run_text_object_export_scenario(work_dir: Path) -> dict[str, object]:
    output_path = work_dir / "text_object_export_out.svg"

    bpy.ops.object.text_add(location=(0.0, 0.0, 0.0))
    text_obj = bpy.context.active_object
    _assert(text_obj is not None and text_obj.type == "FONT", "Expected active FONT object after text_add")
    text_obj.name = "textGlyph"
    text_obj.data.body = "O"

    export_result, output_text = _export_selected(output_path, "textGlyph")
    svg, namespace = _parse_exported_svg(output_text)
    exported_paths = svg.findall(".//svg:path", namespace)
    exported_path_ids = [path.get("id") for path in exported_paths if path.get("id")]

    _assert(export_result == ["FINISHED"], "Text-object SVG export did not finish successfully")
    _assert(len(exported_paths) >= 2, f"Expected text export to create multiple outline paths for 'O', got {len(exported_paths)}")
    _assert(
        all(path_id.startswith("textGlyph_") for path_id in exported_path_ids),
        f"Expected text export path ids to be derived from the source object name, got {exported_path_ids}",
    )
    _assert(all(path.get("d") for path in exported_paths), "Expected exported text outline paths to include path data")
    _assert(svg.find(".//svg:text", namespace) is None, "Expected text objects to export as paths, not SVG text nodes")

    return {
        "scenario": "text-object-export",
        "export_result": export_result,
        "path_count": len(exported_paths),
        "path_ids": exported_path_ids,
    }


def run_curve_camera_export_scenario(work_dir: Path) -> dict[str, object]:
    output_path = work_dir / "curve_camera_export_out.svg"

    camera_data = bpy.data.cameras.new("SpecIOCurveCamera")
    camera_data.type = "PERSP"
    camera = bpy.data.objects.new("SpecIOCurveCamera", camera_data)
    bpy.context.scene.collection.objects.link(camera)
    camera.location = (0.0, -6.0, 3.0)
    camera.rotation_euler = (1.15, 0.0, 0.0)
    bpy.context.scene.camera = camera

    bpy.ops.curve.primitive_bezier_curve_add(location=(0.0, 0.0, 0.0), rotation=(0.4, 0.0, 0.2))
    curve_obj = bpy.context.active_object
    _assert(curve_obj is not None and curve_obj.type == "CURVE", "Expected active CURVE object after primitive_bezier_curve_add")
    curve_obj.name = "cameraCurve"

    export_result, output_text = _export_selected_with_exporter(output_path, "cameraCurve", project_through_camera=True)
    svg, namespace = _parse_exported_svg(output_text)
    exported_paths = svg.findall(".//svg:path", namespace)
    path = svg.find(".//svg:path[@id='cameraCurve']", namespace)

    _assert(export_result == ["FINISHED"], "Camera-projected curve SVG export did not finish successfully")
    _assert(path is not None, "Expected cameraCurve path in exported SVG")
    _assert(" C " in (path.get("d") or ""), "Expected camera-projected bezier curve export to retain cubic path commands")
    _assert(len(exported_paths) == 1, f"Expected one exported camera-projected curve path, got {len(exported_paths)}")

    bounds = _path_bounds(path.get("d", ""))
    _assert(bounds[2] > bounds[0] and bounds[3] > bounds[1], f"Expected non-degenerate projected curve bounds, got {bounds}")

    return {
        "scenario": "curve-camera-export",
        "export_result": export_result,
        "path_id": path.get("id"),
        "bounds": [round(value, 3) for value in bounds],
    }


def run_text_extrude_camera_export_scenario(work_dir: Path) -> dict[str, object]:
    output_path = work_dir / "text_extrude_camera_export_out.svg"

    camera_data = bpy.data.cameras.new("SpecIOTextExtrudeCamera")
    camera_data.type = "ORTHO"
    camera_data.ortho_scale = 8.0
    camera = bpy.data.objects.new("SpecIOTextExtrudeCamera", camera_data)
    bpy.context.scene.collection.objects.link(camera)
    camera.location = (0.0, -6.0, 4.0)
    camera.rotation_euler = (1.1, 0.0, 0.0)
    bpy.context.scene.camera = camera

    bpy.ops.object.text_add(location=(-0.5, 0.0, 0.0), rotation=(1.1, 0.0, 0.0))
    text_obj = bpy.context.active_object
    _assert(text_obj is not None and text_obj.type == "FONT", "Expected active FONT object after text_add")
    text_obj.name = "textExtrude"
    text_obj.data.body = "O"
    text_obj.data.extrude = 0.25

    export_result, output_text = _export_selected_with_exporter(output_path, "textExtrude", project_through_camera=True)
    svg, namespace = _parse_exported_svg(output_text)
    exported_paths = svg.findall(".//svg:path", namespace)
    exported_path_ids = [path.get("id") for path in exported_paths if path.get("id")]
    fill_rule_hints = {path.get("data-specio-import-fill-rule") for path in exported_paths}
    bounds = [_path_bounds(path.get("d", "")) for path in exported_paths]

    _assert(export_result == ["FINISHED"], "Extruded text SVG export did not finish successfully")
    _assert(exported_paths, "Expected projected SVG paths for extruded text export")
    _assert(
        all(path_id.startswith("textExtrude") for path_id in exported_path_ids),
        f"Expected extruded text export path ids to be derived from the source object name, got {exported_path_ids}",
    )
    _assert(" C " not in output_text, "Expected extruded text camera export to use projected polygon paths instead of bezier curve commands")
    _assert(
        "evenodd" in fill_rule_hints,
        f"Expected extruded text export to carry the mesh roundtrip fill-rule hint, got {fill_rule_hints}",
    )
    _assert(any(bound[2] > bound[0] and bound[3] > bound[1] for bound in bounds), "Expected non-degenerate projected bounds for extruded text export")

    return {
        "scenario": "text-extrude-camera-export",
        "export_result": export_result,
        "path_count": len(exported_paths),
        "path_ids": exported_path_ids,
        "fill_rule_hints": sorted(hint for hint in fill_rule_hints if hint is not None),
    }


def run_text_bevel_camera_export_scenario(work_dir: Path) -> dict[str, object]:
    output_path = work_dir / "text_bevel_camera_export_out.svg"

    camera_data = bpy.data.cameras.new("SpecIOTextBevelCamera")
    camera_data.type = "ORTHO"
    camera_data.ortho_scale = 8.0
    camera = bpy.data.objects.new("SpecIOTextBevelCamera", camera_data)
    bpy.context.scene.collection.objects.link(camera)
    camera.location = (0.0, -6.0, 4.0)
    camera.rotation_euler = (1.1, 0.0, 0.0)
    bpy.context.scene.camera = camera

    bpy.ops.object.text_add(location=(-0.5, 0.0, 0.0), rotation=(1.1, 0.0, 0.0))
    text_obj = bpy.context.active_object
    _assert(text_obj is not None and text_obj.type == "FONT", "Expected active FONT object after text_add")
    text_obj.name = "textBevel"
    text_obj.data.body = "O"
    text_obj.data.bevel_depth = 0.08

    export_result, output_text = _export_selected_with_exporter(output_path, "textBevel", project_through_camera=True)
    svg, namespace = _parse_exported_svg(output_text)
    exported_paths = svg.findall(".//svg:path", namespace)
    exported_path_ids = [path.get("id") for path in exported_paths if path.get("id")]
    fill_rule_hints = {path.get("data-specio-import-fill-rule") for path in exported_paths}
    bounds = [_path_bounds(path.get("d", "")) for path in exported_paths]

    _assert(export_result == ["FINISHED"], "Beveled text SVG export did not finish successfully")
    _assert(exported_paths, "Expected projected SVG paths for beveled text export")
    _assert(
        all(path_id.startswith("textBevel") for path_id in exported_path_ids),
        f"Expected beveled text export path ids to be derived from the source object name, got {exported_path_ids}",
    )
    _assert(" C " not in output_text, "Expected beveled text camera export to use projected polygon paths instead of bezier curve commands")
    _assert(
        "evenodd" in fill_rule_hints,
        f"Expected beveled text export to carry the mesh roundtrip fill-rule hint, got {fill_rule_hints}",
    )
    _assert(any(bound[2] > bound[0] and bound[3] > bound[1] for bound in bounds), "Expected non-degenerate projected bounds for beveled text export")

    return {
        "scenario": "text-bevel-camera-export",
        "export_result": export_result,
        "path_count": len(exported_paths),
        "path_ids": exported_path_ids,
        "fill_rule_hints": sorted(hint for hint in fill_rule_hints if hint is not None),
    }


def run_intelligent_split_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "intelligent_split_in.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="140" height="40" viewBox="0 0 140 40">
  <path id="splitMe" fill="black" fill-rule="evenodd" d="M 0 0 L 20 0 L 20 20 L 0 20 Z M 40 0 L 60 0 L 60 20 L 40 20 Z M 80 0 L 100 0 L 100 20 L 80 20 Z" />
</svg>
""",
    )

    bpy.context.scene.specio.import_intelligent_split_paths = False
    import_result = _import_svg(input_path)
    split_me = bpy.data.objects.get("splitMe")

    _assert(import_result == ["FINISHED"], "Intelligent-split SVG import did not finish successfully")
    _assert(split_me is not None, "Expected imported object 'splitMe'")
    _assert(len(split_me.data.splines) == 3, "Expected splitMe to import as a three-spline curve when intelligent split is disabled")
    _assert(bpy.data.collections.get("splitMe__split") is None, "Did not expect a split collection when intelligent split is disabled")

    split_me.select_set(True)
    bpy.context.view_layer.objects.active = split_me
    manual_split_result = list(bpy.ops.specio.split_selected_path())
    split_collection = bpy.data.collections.get("splitMe__split")
    split_object_names = sorted(obj.name for obj in split_collection.objects) if split_collection is not None else []

    _assert(manual_split_result == ["FINISHED"], "Split selected path operator did not finish successfully")
    _assert(split_collection is not None, "Expected splitMe__split collection after manual path split")
    _assert(split_object_names == ["splitMe", "splitMe__part_002", "splitMe__part_003"], f"Expected deterministic split object names, got {split_object_names}")

    bpy.context.scene.specio.import_intelligent_split_paths = True

    return {
        "scenario": "intelligent-split",
        "import_result": import_result,
        "manual_split_result": manual_split_result,
        "split_collection": split_collection.name if split_collection is not None else None,
        "split_object_names": split_object_names,
    }


def run_export_selection_persistence_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "selection_persistence_in.svg"
    output_path = work_dir / "selection_persistence_out.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80" viewBox="0 0 120 80">
  <path id="persistA" d="M 10 10 L 40 10 L 40 40 Z" />
  <path id="persistB" d="M 60 20 L 90 20 L 90 50 Z" />
</svg>
""",
    )

    import_result = _import_svg(input_path)
    _assert(import_result == ["FINISHED"], "Selection-persistence SVG import did not finish successfully")

    _clear_selection()
    export_result = list(
        bpy.ops.specio.export_svg(
            filepath=str(output_path),
            selected_object_names=json.dumps(["persistA", "persistB"]),
        )
    )
    output_text = output_path.read_text(encoding="utf-8")

    _assert(export_result == ["FINISHED"], "Export should succeed when execute() resolves cached selection names")
    _assert('id="persistA"' in output_text, "Expected cached-selection export to include persistA")
    _assert('id="persistB"' in output_text, "Expected cached-selection export to include persistB")

    return {
        "scenario": "export-selection-persistence",
        "import_result": import_result,
        "export_result": export_result,
    }


def run_camera_mesh_export_scenario(work_dir: Path) -> dict[str, object]:
    output_path = work_dir / "camera_mesh_export_out.svg"

    mesh_names = []
    for index, location in enumerate(((-1.5, 0.0, 0.0), (1.5, 0.0, 0.0)), start=1):
        bpy.ops.mesh.primitive_cube_add(location=location)
        obj = bpy.context.active_object
        obj.name = f"CameraMesh{index}"
        material = bpy.data.materials.new(name=f"CameraMeshMaterial{index}")
        rgba = (1.0, 0.0 if index == 1 else 0.5, 0.0 if index == 1 else 1.0, 1.0)
        material.diffuse_color = rgba
        material.use_nodes = True
        principled = next((node for node in material.node_tree.nodes if node.type == "BSDF_PRINCIPLED"), None)
        if principled is not None:
            principled.inputs["Base Color"].default_value = rgba
            if "Alpha" in principled.inputs:
                principled.inputs["Alpha"].default_value = rgba[3]
        obj.data.materials.clear()
        obj.data.materials.append(material)
        mesh_names.append(obj.name)

    camera_data = bpy.data.cameras.new("SpecIOMeshExportCamera")
    camera_data.type = "ORTHO"
    camera_data.ortho_scale = 8.0
    camera = bpy.data.objects.new("SpecIOMeshExportCamera", camera_data)
    bpy.context.scene.collection.objects.link(camera)
    camera.location = (0.0, 0.0, 10.0)
    camera.rotation_euler = (0.0, 0.0, 0.0)
    bpy.context.scene.camera = camera

    export_result, output_text = _export_selected(output_path, *mesh_names)
    svg, namespace = _parse_exported_svg(output_text)
    exported_paths = svg.findall(".//svg:path", namespace)
    exported_path_ids = sorted(path.get("id") for path in exported_paths if path.get("id"))
    fills = {path.get("fill") for path in exported_paths}
    import_fill_rules = {path.get("data-specio-import-fill-rule") for path in exported_paths}
    visible_fill_rules = {path.get("fill-rule") for path in exported_paths}

    _assert(export_result == ["FINISHED"], "Camera-mesh SVG export did not finish successfully")
    _assert(len(exported_paths) == 2, f"Expected one projected face per test cube, got {len(exported_paths)}")
    _assert(exported_path_ids == mesh_names, f"Expected projected mesh export path ids {mesh_names}, got {exported_path_ids}")
    _assert(fills == {"#ff0000", "#ff80ff"}, f"Expected material-derived fills, got {fills}")
    _assert(import_fill_rules == {"evenodd"}, f"Expected compound mesh paths to export with SpecIO evenodd import hints, got {import_fill_rules}")
    _assert(visible_fill_rules == {None}, f"Expected compound mesh paths to keep the default visible fill rule, got {visible_fill_rules}")

    return {
        "scenario": "camera-mesh-export",
        "export_result": export_result,
        "exported_path_ids": exported_path_ids,
        "fills": sorted(fills),
        "import_fill_rules": sorted(import_fill_rules),
    }


def run_camera_mesh_ordering_scenario(work_dir: Path) -> dict[str, object]:
    output_path = work_dir / "camera_mesh_ordering_out.svg"

    bpy.ops.mesh.primitive_cube_add(location=(0.0, 0.0, 0.0))
    near_obj = bpy.context.active_object
    near_obj.name = "AFront"

    bpy.ops.mesh.primitive_cube_add(location=(0.0, 0.0, -2.0))
    far_obj = bpy.context.active_object
    far_obj.name = "ZBack"

    near_material = bpy.data.materials.new(name="CameraMeshOrderNear")
    near_material.diffuse_color = (1.0, 0.2, 0.2, 1.0)
    far_material = bpy.data.materials.new(name="CameraMeshOrderFar")
    far_material.diffuse_color = (0.2, 0.2, 1.0, 1.0)
    near_obj.data.materials.clear()
    near_obj.data.materials.append(near_material)
    far_obj.data.materials.clear()
    far_obj.data.materials.append(far_material)

    camera_data = bpy.data.cameras.new("SpecIOMeshOrderCamera")
    camera_data.type = "ORTHO"
    camera_data.ortho_scale = 6.0
    camera = bpy.data.objects.new("SpecIOMeshOrderCamera", camera_data)
    bpy.context.scene.collection.objects.link(camera)
    camera.location = (0.0, 0.0, 10.0)
    camera.rotation_euler = (0.0, 0.0, 0.0)
    bpy.context.scene.camera = camera

    export_result, output_text = _export_selected(output_path, near_obj.name, far_obj.name)
    svg, namespace = _parse_exported_svg(output_text)
    exported_path_ids = [path.get("id") for path in svg.findall(".//svg:path", namespace) if path.get("id")]

    _assert(export_result == ["FINISHED"], "Camera-mesh ordering SVG export did not finish successfully")
    _assert(exported_path_ids == ["ZBack", "AFront"], f"Expected farther projected mesh to export before nearer one, got {exported_path_ids}")

    return {
        "scenario": "camera-mesh-ordering",
        "export_result": export_result,
        "exported_path_ids": exported_path_ids,
    }


def run_compound_fill_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "compound_fill_in.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">
  <path id="implicitDonut" d="M 10 10 L 110 10 L 110 110 L 10 110 L 10 10 M 40 40 L 40 80 L 80 80 L 80 40 L 40 40" fill="black" />
</svg>
""",
    )

    result = _import_svg(input_path)
    donut = bpy.data.objects.get("implicitDonut")

    _assert(result == ["FINISHED"], "Compound-fill SVG import did not finish successfully")
    _assert(donut is not None, "Expected imported object 'implicitDonut'")
    _assert(len(donut.data.splines) == 2, "Expected implicitDonut to contain two splines")
    _assert(all(spline.use_cyclic_u for spline in donut.data.splines), "Expected implicitly closed filled subpaths to become cyclic splines")

    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = donut.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        area = round(sum(polygon.area for polygon in mesh.polygons), 3)
    finally:
        evaluated.to_mesh_clear()

    _assert(area == 8400.0, f"Expected compound filled shape area 8400.0, got {area}")

    return {
        "scenario": "compound-fill",
        "import_result": result,
        "area": area,
        "spline_count": len(donut.data.splines),
    }


def run_height_offsets_scenario(work_dir: Path) -> dict[str, object]:
        svg_content = """<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"160\" height=\"100\" viewBox=\"0 0 160 100\">
    <g id=\"LayerA\">
        <rect id=\"layerAOne\" x=\"10\" y=\"10\" width=\"20\" height=\"20\" fill=\"#ff0000\" />
        <rect id=\"layerATwo\" x=\"40\" y=\"10\" width=\"20\" height=\"20\" fill=\"#00ff00\" />
    </g>
    <g id=\"LayerB\">
        <rect id=\"layerBOne\" x=\"10\" y=\"50\" width=\"20\" height=\"20\" fill=\"#0000ff\" />
    </g>
</svg>
"""

        def import_case(stem: str, mode: str, step: float) -> dict[str, float]:
                input_path = work_dir / f"{stem}.svg"
                _write_svg(input_path, svg_content)
                bpy.context.scene.specio.import_height_mode = mode
                bpy.context.scene.specio.import_height_step = step
                result = _import_svg(input_path)
                _assert(result == ["FINISHED"], f"Height-offset SVG import failed for mode {mode}")
                zs = {
                        "layerAOne": round(float(bpy.data.objects["layerAOne"].location.z), 4),
                        "layerATwo": round(float(bpy.data.objects["layerATwo"].location.z), 4),
                        "layerBOne": round(float(bpy.data.objects["layerBOne"].location.z), 4),
                }
                _remove_collection_tree(_import_root_collection_name(input_path))
                return zs

        flat = import_case("height_offsets_flat", "FLAT", 0.25)
        per_object = import_case("height_offsets_per_object", "PER_OBJECT", 0.01)
        per_layer = import_case("height_offsets_per_layer", "PER_LAYER", 0.01)
        _assert(flat == {"layerAOne": 0.0, "layerATwo": 0.0, "layerBOne": 0.0}, f"Expected flat import heights to stay at zero, got {flat}")
        _assert(per_object == {"layerAOne": 0.0, "layerATwo": 1.6, "layerBOne": 3.2}, f"Expected per-object height offsets scaled to document size, got {per_object}")
        _assert(per_layer == {"layerAOne": 0.0, "layerATwo": 0.0, "layerBOne": 1.6}, f"Expected per-layer height offsets scaled to document size, got {per_layer}")

        bpy.context.scene.specio.import_height_mode = "PER_OBJECT"
        bpy.context.scene.specio.import_height_step = 0.01

        return {
                "scenario": "height-offsets",
                "flat": flat,
                "per_object": per_object,
                "per_layer": per_layer,
        }


def run_export_style_defaults_scenario(work_dir: Path) -> dict[str, object]:
    default_output_path = work_dir / "export_style_defaults_default_out.svg"
    stroke_output_path = work_dir / "export_style_defaults_stroke_out.svg"
    settings = bpy.context.scene.specio
    original_settings = {
        "export_default_fill_color": tuple(float(component) for component in settings.export_default_fill_color),
        "export_default_stroke_color": tuple(float(component) for component in settings.export_default_stroke_color),
        "export_apply_stroke": bool(settings.export_apply_stroke),
        "export_stroke_width": float(settings.export_stroke_width),
    }

    bpy.ops.curve.primitive_bezier_circle_add(radius=1.0, location=(0.0, 0.0, 0.0))
    default_obj = bpy.context.active_object
    _assert(default_obj is not None and default_obj.type == "CURVE", "Expected active curve object for export style defaults")
    default_obj.name = "unstyledDefault"

    bpy.ops.curve.primitive_bezier_circle_add(radius=0.75, location=(3.0, 0.0, 0.0))
    material_obj = bpy.context.active_object
    _assert(material_obj is not None and material_obj.type == "CURVE", "Expected second active curve object for export style defaults")
    material_obj.name = "materialColorCurve"
    material = bpy.data.materials.new(name="ExportStyleDefaultsMaterial")
    material.use_nodes = True
    principled = next((node for node in material.node_tree.nodes if node.type == "BSDF_PRINCIPLED"), None)
    _assert(principled is not None, "Expected Principled BSDF node on generated test material")
    principled.inputs["Base Color"].default_value = (0.2, 0.4, 0.6, 1.0)
    principled.inputs["Alpha"].default_value = 1.0
    material_obj.data.materials.append(material)

    try:
        settings.export_default_fill_color = (0.5, 0.5, 0.5)
        settings.export_default_stroke_color = (0.0, 0.0, 0.0)
        settings.export_apply_stroke = False
        settings.export_stroke_width = 1.0

        default_export_result, default_output_text = _export_selected(default_output_path, "unstyledDefault", "materialColorCurve")
        default_svg, namespace = _parse_exported_svg(default_output_text)
        default_path = default_svg.find(".//svg:path[@id='unstyledDefault']", namespace)
        material_path = default_svg.find(".//svg:path[@id='materialColorCurve']", namespace)

        _assert(default_export_result == ["FINISHED"], "Default export style scenario did not finish successfully")
        _assert(default_path is not None, "Expected unstyledDefault path in exported SVG")
        _assert(material_path is not None, "Expected materialColorCurve path in exported SVG")
        _assert(default_path.get("fill") == "#808080", "Expected fallback fill color to default to middle gray")
        _assert(default_path.get("stroke") == "none", "Expected stroke to remain disabled by default")
        _assert(default_path.get("stroke-width") is None, "Expected no default stroke width when stroke export is disabled")
        _assert(material_path.get("fill") == "#336699", "Expected Blender material color to export before fallback fill")
        _assert(material_path.get("stroke") == "none", "Expected material-backed export to keep stroke disabled by default")

        settings.export_default_fill_color = (0.25, 0.5, 0.75)
        settings.export_default_stroke_color = (0.9, 0.2, 0.1)
        settings.export_apply_stroke = True
        settings.export_stroke_width = 2.25

        stroke_export_result, stroke_output_text = _export_selected(stroke_output_path, "unstyledDefault")
        stroke_svg, _ = _parse_exported_svg(stroke_output_text)
        stroke_path = stroke_svg.find(".//svg:path[@id='unstyledDefault']", namespace)

        _assert(stroke_export_result == ["FINISHED"], "Stroke-enabled export style scenario did not finish successfully")
        _assert(stroke_path is not None, "Expected unstyledDefault path in stroke-enabled export")
        _assert(stroke_path.get("fill") == "#4080bf", "Expected configured export fill color to apply to unstyled objects")
        _assert(stroke_path.get("stroke") == "#e5331a", "Expected configured export stroke color to apply when enabled")
        _assert(stroke_path.get("stroke-width") == "2.25", "Expected configured export stroke width to be serialized")
    finally:
        settings.export_default_fill_color = original_settings["export_default_fill_color"]
        settings.export_default_stroke_color = original_settings["export_default_stroke_color"]
        settings.export_apply_stroke = original_settings["export_apply_stroke"]
        settings.export_stroke_width = original_settings["export_stroke_width"]

    return {
        "scenario": "export-style-defaults",
        "default_fill": default_path.get("fill"),
        "default_stroke": default_path.get("stroke"),
        "material_fill": material_path.get("fill"),
        "configured_fill": stroke_path.get("fill"),
        "configured_stroke": stroke_path.get("stroke"),
        "configured_stroke_width": stroke_path.get("stroke-width"),
    }


def run_scene_defaults_reset_scenario(work_dir: Path) -> dict[str, object]:
    del work_dir
    scene = bpy.context.scene
    settings = scene.specio
    addon = bpy.context.preferences.addons.get("SpecIO") if bpy.context.preferences else None
    prefs = addon.preferences if addon else None
    original_preferences = None

    if prefs is not None:
        original_preferences = {
            "default_import_scale": prefs.default_import_scale,
            "default_resolution": prefs.default_resolution,
            "default_import_height_mode": prefs.default_import_height_mode,
            "default_import_height_step": prefs.default_import_height_step,
            "default_import_stroke_overlay_offset": prefs.default_import_stroke_overlay_offset,
            "default_import_intelligent_split_paths": prefs.default_import_intelligent_split_paths,
            "default_export_scale": prefs.default_export_scale,
            "precision": prefs.precision,
            "default_export_fill_color": tuple(float(component) for component in prefs.default_export_fill_color),
            "default_export_stroke_color": tuple(float(component) for component in prefs.default_export_stroke_color),
            "default_export_apply_stroke": bool(prefs.default_export_apply_stroke),
            "default_export_stroke_width": float(prefs.default_export_stroke_width),
        }
        prefs.default_import_scale = 2.5
        prefs.default_resolution = 96
        prefs.default_import_height_mode = "PER_LAYER"
        prefs.default_import_height_step = 0.125
        prefs.default_import_stroke_overlay_offset = 0.02
        prefs.default_import_intelligent_split_paths = False
        prefs.default_export_scale = 3.0
        prefs.precision = 5
        prefs.default_export_fill_color = (0.25, 0.5, 0.75)
        prefs.default_export_stroke_color = (0.9, 0.2, 0.1)
        prefs.default_export_apply_stroke = True
        prefs.default_export_stroke_width = 2.25

    settings.import_scale = 9.0
    settings.import_resolution = 12
    settings.import_height_mode = "PER_OBJECT"
    settings.import_height_step = 9.0
    settings.import_stroke_overlay_offset = 9.0
    settings.import_intelligent_split_paths = True
    settings.export_scale = 9.0
    settings.export_precision = 1
    settings.export_default_fill_color = (0.1, 0.1, 0.1)
    settings.export_default_stroke_color = (0.1, 0.1, 0.1)
    settings.export_apply_stroke = False
    settings.export_stroke_width = 9.0

    result = list(bpy.ops.specio.reset_scene_defaults())
    _assert(result == ["FINISHED"], "Reset scene defaults operator did not finish successfully")

    expected = {
        "import_scale": 2.5 if prefs is not None else 1.0,
        "import_resolution": 96 if prefs is not None else 64,
        "import_height_mode": "PER_LAYER" if prefs is not None else "PER_OBJECT",
        "import_height_step": 0.125 if prefs is not None else 0.01,
        "import_stroke_overlay_offset": 0.02 if prefs is not None else 0.001,
        "import_intelligent_split_paths": False if prefs is not None else True,
        "export_scale": 3.0 if prefs is not None else 1.0,
        "export_precision": 5 if prefs is not None else 3,
        "export_default_fill_color": (0.25, 0.5, 0.75) if prefs is not None else (0.5, 0.5, 0.5),
        "export_default_stroke_color": (0.9, 0.2, 0.1) if prefs is not None else (0.0, 0.0, 0.0),
        "export_apply_stroke": True if prefs is not None else False,
        "export_stroke_width": 2.25 if prefs is not None else 1.0,
    }
    actual = {
        "import_scale": round(float(settings.import_scale), 4),
        "import_resolution": int(settings.import_resolution),
        "import_height_mode": settings.import_height_mode,
        "import_height_step": round(float(settings.import_height_step), 4),
        "import_stroke_overlay_offset": round(float(settings.import_stroke_overlay_offset), 4),
        "import_intelligent_split_paths": bool(settings.import_intelligent_split_paths),
        "export_scale": round(float(settings.export_scale), 4),
        "export_precision": int(settings.export_precision),
        "export_default_fill_color": tuple(round(float(component), 4) for component in settings.export_default_fill_color),
        "export_default_stroke_color": tuple(round(float(component), 4) for component in settings.export_default_stroke_color),
        "export_apply_stroke": bool(settings.export_apply_stroke),
        "export_stroke_width": round(float(settings.export_stroke_width), 4),
    }
    _assert(actual == expected, f"Expected reset scene defaults to restore {expected}, got {actual}")

    if prefs is not None and original_preferences is not None:
        prefs.default_import_scale = original_preferences["default_import_scale"]
        prefs.default_resolution = original_preferences["default_resolution"]
        prefs.default_import_height_mode = original_preferences["default_import_height_mode"]
        prefs.default_import_height_step = original_preferences["default_import_height_step"]
        prefs.default_import_stroke_overlay_offset = original_preferences["default_import_stroke_overlay_offset"]
        prefs.default_import_intelligent_split_paths = original_preferences["default_import_intelligent_split_paths"]
        prefs.default_export_scale = original_preferences["default_export_scale"]
        prefs.precision = original_preferences["precision"]
        prefs.default_export_fill_color = original_preferences["default_export_fill_color"]
        prefs.default_export_stroke_color = original_preferences["default_export_stroke_color"]
        prefs.default_export_apply_stroke = original_preferences["default_export_apply_stroke"]
        prefs.default_export_stroke_width = original_preferences["default_export_stroke_width"]
        bpy.ops.specio.reset_scene_defaults()

    return {
        "scenario": "scene-defaults-reset",
        "operator_result": result,
        "actual": actual,
        "used_addon_preferences": prefs is not None,
    }


def run_hierarchy_order_roundtrip_scenario(work_dir: Path) -> dict[str, object]:
    input_path = work_dir / "hierarchy_order_roundtrip_in.svg"
    output_path = work_dir / "hierarchy_order_roundtrip_out.svg"
    output_path_2 = work_dir / "hierarchy_order_roundtrip_out_2.svg"
    _write_svg(
        input_path,
        """<svg xmlns="http://www.w3.org/2000/svg" width="180" height="120" viewBox="0 0 180 120">
  <g id="Layer_20">
    <path id="zeta" d="M 10 10 L 40 10 L 40 35 Z" fill="#cc3300" />
    <g id="Detail">
      <rect id="detailRect" x="55" y="12" width="22" height="18" fill="#00aa44" />
    </g>
    <path id="alpha" d="M 85 10 L 115 10 L 115 35 Z" fill="none" stroke="#2255aa" stroke-width="2" />
  </g>
  <g id="Layer_05">
    <rect id="middleRect" x="15" y="55" width="28" height="20" fill="#ffaa00" />
  </g>
  <g id="Layer_10">
    <path id="omega" d="M 90 55 L 130 55 L 130 80 Z" fill="#663399" />
  </g>
</svg>
""",
    )

    result = _import_svg(input_path)
    object_names = ["zeta", "detailRect", "alpha", "middleRect", "omega"]
    _assert(result == ["FINISHED"], "Hierarchy-order SVG import did not finish successfully")
    for object_name in object_names:
        _assert(bpy.data.objects.get(object_name) is not None, f"Expected imported object '{object_name}'")

    export_result, output_text = _export_selected(output_path, *object_names)
    _assert(export_result == ["FINISHED"], "Hierarchy-order SVG export did not finish successfully")

    svg, namespace = _parse_exported_svg(output_text)
    layer_ids = [child.get("id") for child in svg if _strip_namespace(child.tag) == "g"]
    _assert(layer_ids == ["Layer_20", "Layer_05", "Layer_10"], "Expected top-level group order to match the imported SVG")

    layer_20 = svg.find("svg:g[@id='Layer_20']", namespace)
    _assert(layer_20 is not None, "Expected Layer_20 group in hierarchy-order export")
    _assert(
        _direct_child_ids(layer_20) == ["zeta", "Detail", "alpha"],
        "Expected mixed direct and nested child order to match the imported SVG",
    )

    _remove_collection_tree(_import_root_collection_name(input_path))

    reimport_result = _import_svg(output_path)
    _assert(reimport_result == ["FINISHED"], "Hierarchy-order roundtrip reimport did not finish successfully")
    for object_name in object_names:
        _assert(bpy.data.objects.get(object_name) is not None, f"Expected reimported object '{object_name}'")

    export_result_2, output_text_2 = _export_selected(output_path_2, *object_names)
    _assert(export_result_2 == ["FINISHED"], "Hierarchy-order second SVG export did not finish successfully")

    svg_2, namespace_2 = _parse_exported_svg(output_text_2)
    layer_ids_2 = [child.get("id") for child in svg_2 if _strip_namespace(child.tag) == "g"]
    _assert(layer_ids_2 == ["Layer_20", "Layer_05", "Layer_10"], "Expected top-level group order to survive the roundtrip loop")

    layer_20_roundtrip = svg_2.find("svg:g[@id='Layer_20']", namespace_2)
    _assert(layer_20_roundtrip is not None, "Expected Layer_20 group in second hierarchy-order export")
    _assert(
        _direct_child_ids(layer_20_roundtrip) == ["zeta", "Detail", "alpha"],
        "Expected nested group ids and sibling order to survive the roundtrip loop",
    )

    return {
        "scenario": "hierarchy-order-roundtrip",
        "import_result": result,
        "export_result": export_result,
        "reimport_result": reimport_result,
        "second_export_result": export_result_2,
        "top_level_group_order": layer_ids_2,
        "layer_20_child_order": _direct_child_ids(layer_20_roundtrip),
    }


def run_sample_camera_roundtrip_scenario(work_dir: Path) -> dict[str, object]:
    input_path = REPO_ROOT / "sample_svgs" / "AJ_Digital_Camera.svg"
    output_path = work_dir / "sample_camera_roundtrip_out.svg"
    source_root = ET.parse(input_path).getroot()
    source_elements = _supported_svg_elements(source_root)

    result = _import_svg(input_path)
    _assert(result == ["FINISHED"], "Sample camera SVG import did not finish successfully")

    root_collection_name = _import_root_collection_name(input_path)
    imported_object_names = _collection_object_names(root_collection_name)
    primary_imported_object_names = [name for name in imported_object_names if not _is_stroke_helper_object_name(name)]
    helper_object_names = [name for name in imported_object_names if _is_stroke_helper_object_name(name)]
    imported_object_set = set(primary_imported_object_names)
    source_ids = {element.get("id") for element in source_elements if element.get("id")}

    _assert(len(primary_imported_object_names) == len(source_elements), "Expected one primary imported object per supported SVG element in the sample file")
    _assert(source_ids.issubset(imported_object_set), "Expected imported object names to preserve sample SVG element ids")

    for helper_name in helper_object_names:
        helper_object = bpy.data.objects.get(helper_name)
        _assert(helper_object is not None, f"Expected helper object '{helper_name}'")
        _assert(bool(helper_object.get("specio_svg_stroke_helper")), f"Expected stroke helper flag on '{helper_name}'")

    initial_bounds = {object_name: _object_bounds_2d(object_name) for object_name in primary_imported_object_names}
    representative_styles = {
        "path2157": _style_snapshot("path2157"),
    }
    representative_gradients = {
        "rect2052": _gradient_snapshot("rect2052"),
        "path2058": _gradient_snapshot("path2058"),
    }

    export_result, output_text = _export_selected(output_path, *imported_object_names)
    _assert(export_result == ["FINISHED"], "Sample camera SVG export did not finish successfully")

    svg, namespace = _parse_exported_svg(output_text)
    exported_paths = svg.findall(".//svg:path", namespace)
    exported_path_ids = [path.get("id") for path in exported_paths if path.get("id")]
    expected_path_count = sum(len(bpy.data.objects[object_name].data.splines) for object_name in primary_imported_object_names)

    _assert(len(exported_paths) == expected_path_count, "Expected one exported SVG path per imported Blender spline")
    _assert("rect2052" in exported_path_ids, "Expected exported sample SVG to preserve rect2052 id")
    _assert("path2058" in exported_path_ids, "Expected exported sample SVG to preserve path2058 id")
    _assert(svg.find("svg:defs/svg:linearGradient[@id='linearGradient3097']", namespace) is not None, "Expected exported sample SVG to preserve representative linear gradient definitions")
    _assert(svg.find("svg:defs/svg:radialGradient[@id='radialGradient3100']", namespace) is not None, "Expected exported sample SVG to preserve representative radial gradient definitions")

    _remove_collection_tree(root_collection_name)

    reimport_result = _import_svg(output_path)
    _assert(reimport_result == ["FINISHED"], "Sample camera roundtrip reimport did not finish successfully")

    reimport_root_name = _import_root_collection_name(output_path)
    reimported_object_names = _collection_object_names(reimport_root_name)
    reimported_object_set = {name for name in reimported_object_names if not _is_stroke_helper_object_name(name)}

    _assert(reimported_object_set == set(exported_path_ids), "Expected roundtrip reimported object ids to match exported path ids")
    _assert(len(reimported_object_set) == len(exported_path_ids), "Expected roundtrip reimported primary object count to match exported path count")

    for object_name in sorted(imported_object_set & reimported_object_set):
        _assert_bounds_close(
            _object_bounds_2d(object_name),
            initial_bounds[object_name],
            tolerance=0.5,
            message=f"Expected roundtrip bounds for {object_name} to stay stable",
        )

    _assert(_style_snapshot("path2157") == representative_styles["path2157"], "Expected representative solid paint style metadata to survive the roundtrip loop")
    _assert(_gradient_snapshot("rect2052") == representative_gradients["rect2052"], "Expected representative linear gradient metadata to survive the roundtrip loop")
    _assert(_gradient_snapshot("path2058") == representative_gradients["path2058"], "Expected representative radial gradient metadata to survive the roundtrip loop")

    return {
        "scenario": "sample-camera-roundtrip",
        "import_result": result,
        "export_result": export_result,
        "reimport_result": reimport_result,
        "source_supported_element_count": len(source_elements),
        "imported_object_count": len(primary_imported_object_names),
        "helper_object_count": len(helper_object_names),
        "exported_path_count": len(exported_paths),
        "reimported_object_count": len(reimported_object_set),
        "representative_gradients": representative_gradients,
    }


def run_transform_stack_roundtrip_scenario(work_dir: Path) -> dict[str, object]:
    input_path = REPO_ROOT / "sample_svgs" / "units_transform_torture.svg"
    output_path = work_dir / "transform_stack_roundtrip_out.svg"
    bounds_tolerance = 1.25
    source_root = ET.parse(input_path).getroot()
    source_elements = _supported_svg_elements(source_root)

    result = _import_svg(input_path)
    _assert(result == ["FINISHED"], "Transform-stack SVG import did not finish successfully")

    root_collection_name = _import_root_collection_name(input_path)
    imported_object_names = _collection_object_names(root_collection_name)
    primary_imported_object_names = [name for name in imported_object_names if not _is_stroke_helper_object_name(name)]
    helper_object_names = [name for name in imported_object_names if _is_stroke_helper_object_name(name)]
    imported_object_set = set(primary_imported_object_names)
    source_ids = {element.get("id") for element in source_elements if element.get("id")}

    _assert(len(primary_imported_object_names) == len(source_elements), "Expected one primary imported object per supported transform fixture element")
    _assert(source_ids == imported_object_set, "Expected transform fixture object ids to be preserved on import")
    for helper_name in helper_object_names:
        helper_object = bpy.data.objects.get(helper_name)
        _assert(helper_object is not None, f"Expected helper object '{helper_name}'")
        _assert(bool(helper_object.get("specio_svg_stroke_helper")), f"Expected stroke helper flag on '{helper_name}'")
        _assert(helper_object.get("specio_svg_stroke_source") in source_ids, f"Expected helper '{helper_name}' to point at a source SVG object")

    initial_bounds = {object_name: _object_bounds_2d(object_name) for object_name in primary_imported_object_names}

    export_result, output_text = _export_selected(output_path, *imported_object_names)
    _assert(export_result == ["FINISHED"], "Transform-stack SVG export did not finish successfully")

    svg, namespace = _parse_exported_svg(output_text)
    top_level_group_ids = [child.get("id") for child in svg if _strip_namespace(child.tag) == "g"]
    _assert(top_level_group_ids == ["TransformRoot", "MatrixRoot", "MirrorRoot"], "Expected top-level transform groups to be preserved on export")
    _assert(svg.find("svg:g[@id='TransformRoot']/svg:g[@id='SkewCluster']", namespace) is not None, "Expected nested skew group to survive export")

    _remove_collection_tree(root_collection_name)

    reimport_result = _import_svg(output_path)
    _assert(reimport_result == ["FINISHED"], "Transform-stack roundtrip reimport did not finish successfully")

    reimport_root_name = _import_root_collection_name(output_path)
    reimported_object_names = _collection_object_names(reimport_root_name)
    reimported_object_set = {name for name in reimported_object_names if not _is_stroke_helper_object_name(name)}

    _assert(reimported_object_set == imported_object_set, "Expected transform fixture object ids to survive the roundtrip loop")
    for object_name in sorted(imported_object_set):
        _assert_bounds_close(
            _object_bounds_2d(object_name),
            initial_bounds[object_name],
            tolerance=bounds_tolerance,
            message=f"Expected transform-stack bounds for {object_name} to stay stable",
        )

    return {
        "scenario": "transform-stack-roundtrip",
        "import_result": result,
        "export_result": export_result,
        "reimport_result": reimport_result,
        "object_count": len(primary_imported_object_names),
        "helper_object_count": len(helper_object_names),
        "bounds_tolerance": bounds_tolerance,
        "top_level_group_ids": top_level_group_ids,
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run headless Blender smoke tests for SpecIO")
    parser.add_argument(
        "--scenario",
        choices=["all", *SCENARIO_NAMES],
        default="all",
        help="Choose which smoke scenario to run",
    )
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    bpy.context.scene.specio.import_scale = 1.0
    bpy.context.scene.specio.import_height_mode = "PER_OBJECT"
    bpy.context.scene.specio.import_height_step = 0.01
    bpy.context.scene.specio.import_stroke_overlay_offset = 0.001
    bpy.context.scene.specio.import_intelligent_split_paths = True
    bpy.context.scene.specio.export_scale = 1.0
    bpy.context.scene.specio.export_precision = 3
    bpy.context.scene.specio.export_default_fill_color = (0.5, 0.5, 0.5)
    bpy.context.scene.specio.export_default_stroke_color = (0.0, 0.0, 0.0)
    bpy.context.scene.specio.export_apply_stroke = False
    bpy.context.scene.specio.export_stroke_width = 1.0

    results: list[dict[str, object]] = []

    with tempfile.TemporaryDirectory(prefix="specio-smoke-") as temp_dir:
        work_dir = Path(temp_dir)

        scenario_handlers = {
            "path-rich": run_path_rich_scenario,
            "rotated-arc": run_rotated_arc_scenario,
            "large-arc": run_large_arc_scenario,
            "compound-fill": run_compound_fill_scenario,
            "height-offsets": run_height_offsets_scenario,
            "scene-defaults-reset": run_scene_defaults_reset_scenario,
            "transform-stack-roundtrip": run_transform_stack_roundtrip_scenario,
            "collection-hierarchy": run_collection_hierarchy_scenario,
            "hierarchy-order-roundtrip": run_hierarchy_order_roundtrip_scenario,
            "malformed-input": run_malformed_input_scenario,
            "style-roundtrip": run_style_roundtrip_scenario,
            "gradient-material": run_gradient_material_scenario,
            "managed-gradient-export": run_managed_gradient_export_scenario,
            "multi-spline-export": run_multi_spline_export_scenario,
            "text-object-export": run_text_object_export_scenario,
            "export-style-defaults": run_export_style_defaults_scenario,
            "curve-camera-export": run_curve_camera_export_scenario,
            "text-extrude-camera-export": run_text_extrude_camera_export_scenario,
            "text-bevel-camera-export": run_text_bevel_camera_export_scenario,
            "intelligent-split": run_intelligent_split_scenario,
            "export-selection-persistence": run_export_selection_persistence_scenario,
            "camera-mesh-export": run_camera_mesh_export_scenario,
            "camera-mesh-ordering": run_camera_mesh_ordering_scenario,
            "sample-camera-roundtrip": run_sample_camera_roundtrip_scenario,
        }
        selected_scenarios = SCENARIO_NAMES if args.scenario == "all" else (args.scenario,)
        for scenario_name in selected_scenarios:
            results.append(scenario_handlers[scenario_name](work_dir))

    print(json.dumps({"ok": True, "results": results}, indent=2))
    return 0


if __name__ == "__main__":
    SpecIO.register()
    try:
        sys.exit(main(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []))
    finally:
        SpecIO.unregister()
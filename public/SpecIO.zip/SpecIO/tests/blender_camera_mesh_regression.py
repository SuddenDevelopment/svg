"""Numeric regression for camera-projected mesh export against exported SVG loops.

Run with Blender from the repository root, for example:

    blender -b --factory-startup --python tests/blender_camera_mesh_regression.py -- --blend ../cyberdash/assets/logo_cube_2.blend
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sys
import tempfile
import xml.etree.ElementTree as ET

import bpy


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BLEND = REPO_ROOT.parent / "cyberdash" / "assets" / "logo_cube_2.blend"
DEFAULT_OBJECTS = ("Cube.004", "Cube.005")
PATH_TOKEN_PATTERN = re.compile(r"[MLZmlz]|[-+]?(?:\d+\.?\d*|\.\d+)")


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare projected Blender mesh loops against exported SVG loops")
    parser.add_argument(
        "--blend",
        default=str(DEFAULT_BLEND),
        help="Blend file to open for the regression case.",
    )
    parser.add_argument(
        "--objects",
        nargs="+",
        default=list(DEFAULT_OBJECTS),
        help="Object names to compare numerically.",
    )
    parser.add_argument(
        "--precision",
        type=int,
        default=3,
        help="Expected exported SVG numeric precision.",
    )
    return parser.parse_args(argv)


def _parse_svg_path_loops(path_data: str) -> list[list[tuple[float, float]]]:
    tokens = PATH_TOKEN_PATTERN.findall(path_data or "")
    loops: list[list[tuple[float, float]]] = []
    current: list[tuple[float, float]] = []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        index += 1
        upper = token.upper()
        if upper in {"M", "L"}:
            _assert(index + 1 < len(tokens), f"Malformed SVG path data: {path_data}")
            point = (float(tokens[index]), float(tokens[index + 1]))
            index += 2
            if upper == "M":
                if current:
                    loops.append(current)
                current = [point]
            else:
                current.append(point)
        elif upper == "Z":
            if current:
                loops.append(current)
                current = []
        else:
            raise AssertionError(f"Unsupported SVG command in regression script: {token}")

    if current:
        loops.append(current)
    return loops


def _signed_area(points: list[tuple[float, float]]) -> float:
    area = 0.0
    for current, nxt in zip(points, points[1:] + points[:1]):
        area += current[0] * nxt[1] - nxt[0] * current[1]
    return area / 2.0


def _canonical_loop(points: list[tuple[float, float]], precision: int) -> tuple[tuple[float, float], ...]:
    rounded = [(round(point[0], precision), round(point[1], precision)) for point in points]
    if _signed_area(rounded) < 0:
        rounded.reverse()
    start_index = min(range(len(rounded)), key=lambda idx: (rounded[idx][0], rounded[idx][1]))
    canonical = rounded[start_index:] + rounded[:start_index]
    return tuple(canonical)


def _bounds(points: list[tuple[float, float]]) -> tuple[float, float, float, float]:
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return (min(xs), min(ys), max(xs), max(ys))


def _max_bounds_delta(projected_loops: list[list[tuple[float, float]]], exported_loops: list[list[tuple[float, float]]]) -> float:
    projected_canonical = sorted(_canonical_loop(loop, 3) for loop in projected_loops)
    exported_canonical = sorted(_canonical_loop(loop, 3) for loop in exported_loops)
    if len(projected_canonical) != len(exported_canonical):
        return float("inf")
    max_delta = 0.0
    for projected_loop, exported_loop in zip(projected_canonical, exported_canonical):
        for projected_point, exported_point in zip(projected_loop, exported_loop):
            max_delta = max(max_delta, abs(projected_point[0] - exported_point[0]), abs(projected_point[1] - exported_point[1]))
    return max_delta


def main(argv: list[str]) -> int:
    args = _parse_args(argv)
    blend_path = Path(args.blend).resolve()
    _assert(blend_path.exists(), f"Blend file does not exist: {blend_path}")

    bpy.ops.wm.open_mainfile(filepath=str(blend_path))

    sys.path.insert(0, str(REPO_ROOT.parent))
    import SpecIO
    from SpecIO.io_svg import SVGExporter

    SpecIO.register()
    try:
        scene = bpy.context.scene
        scene.specio.export_scale = 1.0
        scene.specio.export_precision = args.precision
        exporter = SVGExporter(
            scale=scene.specio.export_scale,
            precision=scene.specio.export_precision,
            image_mode=scene.specio.image_export_mode,
            default_fill_color=scene.specio.export_default_fill_color,
            default_stroke_color=scene.specio.export_default_stroke_color,
            apply_stroke=scene.specio.export_apply_stroke,
            stroke_width=scene.specio.export_stroke_width,
        )
        camera = scene.camera
        _assert(camera is not None, "Expected the regression blend to have an active scene camera")

        objects = []
        for object_name in args.objects:
            obj = bpy.data.objects.get(object_name)
            _assert(obj is not None, f"Expected object '{object_name}' in {blend_path}")
            _assert(obj.type == "MESH", f"Expected mesh object '{object_name}'")
            objects.append(obj)

        with tempfile.TemporaryDirectory(prefix="specio-camera-mesh-regression-") as temp_dir:
            svg_path = Path(temp_dir) / "camera_mesh_regression.svg"
            export_result = exporter.export_objects(str(svg_path), objects, scene)
            _assert(export_result == {"FINISHED"}, "Expected SVG exporter to finish successfully")

            root = ET.parse(svg_path).getroot()
            namespace = {"svg": "http://www.w3.org/2000/svg"}
            svg_paths = root.findall(".//svg:path", namespace)

            results: list[dict[str, object]] = []
            for obj in objects:
                projected_faces = exporter._mesh_camera_projection_faces(obj, scene, camera)
                projected_loops = [face["points"] for face in projected_faces]
                exported_loops: list[list[tuple[float, float]]] = []
                for path in svg_paths:
                    path_id = path.get("id") or ""
                    if path_id == obj.name or path_id.startswith(f"{obj.name}_"):
                        exported_loops.extend(_parse_svg_path_loops(path.get("d", "")))

                projected_counter = Counter(_canonical_loop(loop, args.precision) for loop in projected_loops)
                exported_counter = Counter(_canonical_loop(loop, args.precision) for loop in exported_loops)
                counters_match = projected_counter == exported_counter

                object_result = {
                    "object": obj.name,
                    "projected_loop_count": len(projected_loops),
                    "exported_loop_count": len(exported_loops),
                    "counters_match": counters_match,
                    "projected_total_area": round(sum(abs(_signed_area(loop)) for loop in projected_loops), 6),
                    "exported_total_area": round(sum(abs(_signed_area(loop)) for loop in exported_loops), 6),
                    "max_bounds_delta": round(_max_bounds_delta(projected_loops, exported_loops), 6),
                }
                results.append(object_result)

                _assert(counters_match, f"Projected/exported loops differ for {obj.name}: {object_result}")

            print(
                json.dumps(
                    {
                        "ok": True,
                        "blend": str(blend_path),
                        "objects": [obj.name for obj in objects],
                        "results": results,
                    },
                    indent=2,
                )
            )
    finally:
        SpecIO.unregister()

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []))
"""Import a sample SVG in headless Blender and report feature coverage details."""

from __future__ import annotations

import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import bpy


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT.parent))

import SpecIO


SUPPORTED_TAGS = {"rect", "circle", "ellipse", "line", "path", "polygon", "polyline"}


def strip_namespace(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def svg_feature_summary(svg_path: Path) -> dict[str, object]:
    root = ET.parse(svg_path).getroot()
    tag_counts: dict[str, int] = {}
    supported_count = 0
    transform_count = 0
    rounded_rect_ids: list[str] = []
    gradient_paint_count = 0
    text_as_path_ids: list[str] = []

    for element in root.iter():
        tag = strip_namespace(element.tag)
        tag_counts[tag] = tag_counts.get(tag, 0) + 1
        if tag in SUPPORTED_TAGS:
            supported_count += 1
        if element.get("transform"):
            transform_count += 1
        if tag == "rect" and (element.get("rx") or element.get("ry")):
            rounded_rect_ids.append(element.get("id", ""))

        style = element.get("style", "")
        if "url(#" in style:
            gradient_paint_count += 1
        if tag == "path" and str(element.get("id", "")).startswith("text"):
            text_as_path_ids.append(element.get("id", ""))

    return {
        "tag_counts": tag_counts,
        "supported_geometry_count": supported_count,
        "transform_count": transform_count,
        "rounded_rect_ids": rounded_rect_ids,
        "gradient_paint_count": gradient_paint_count,
        "text_path_ids": text_as_path_ids,
    }


def object_bounds_svg(obj) -> list[float]:
    points: list[tuple[float, float]] = []
    for spline in obj.data.splines:
        if spline.type == "BEZIER":
            for bezier_point in spline.bezier_points:
                for point in (bezier_point.co, bezier_point.handle_left, bezier_point.handle_right):
                    world = obj.matrix_world @ point
                    points.append((float(world.x), float(-world.y)))
        else:
            for point in spline.points:
                world = obj.matrix_world @ point.co.xyz
                points.append((float(world.x), float(-world.y)))

    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return [round(min(xs), 3), round(min(ys), 3), round(max(xs), 3), round(max(ys), 3)]


def collect_object_probe(name: str) -> dict[str, object] | None:
    obj = bpy.data.objects.get(name)
    if obj is None:
        return None

    return {
        "name": obj.name,
        "spline_types": [spline.type for spline in obj.data.splines],
        "bounds_svg": object_bounds_svg(obj),
        "materials": [material.name for material in obj.data.materials if material is not None],
        "display_color": [round(float(channel), 3) for channel in obj.color],
        "style": {
            key: obj.get(key)
            for key in (
                "specio_svg_fill",
                "specio_svg_stroke",
                "specio_svg_stroke_width",
                "specio_svg_stroke_linecap",
                "specio_svg_stroke_linejoin",
            )
            if obj.get(key) is not None
        },
    }


def main(argv: list[str]) -> int:
    if not argv:
        raise SystemExit("Expected SVG file path")

    svg_path = Path(argv[0]).resolve()
    feature_summary = svg_feature_summary(svg_path)
    existing_objects = {obj.name for obj in bpy.data.objects}

    result = list(bpy.ops.specio.import_svg(filepath=str(svg_path)))
    imported_objects = sorted(name for name in bpy.data.objects.keys() if name not in existing_objects)

    payload = {
        "svg_path": str(svg_path),
        "import_result": result,
        "feature_summary": feature_summary,
        "imported_object_count": len(imported_objects),
        "imported_object_names_sample": imported_objects[:15],
        "probes": {
            "rect2052": collect_object_probe("rect2052"),
            "rect2103": collect_object_probe("rect2103"),
            "rect2107": collect_object_probe("rect2107"),
            "rect2111": collect_object_probe("rect2111"),
            "text2445": collect_object_probe("text2445"),
            "path2384": collect_object_probe("path2384"),
        },
    }
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    SpecIO.register()
    try:
        sys.exit(main(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []))
    finally:
        SpecIO.unregister()
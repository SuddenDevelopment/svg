import unittest
import xml.etree.ElementTree as ET

from io_svg.style import (
    CSSRules,
    apply_curve_style_settings,
    export_style_attributes,
    extract_style_attributes,
    is_stroke_enabled,
    is_hidden_style,
    merge_style_attributes,
    parse_color_value,
    parse_css_style_block,
    parse_numeric_style_value,
    normalize_style_value,
    parse_style_attribute,
    resolve_stroke_width,
    resolve_display_color,
)


class CurveStub:
    def __init__(self):
        self.dimensions = "2D"
        self.fill_mode = "NONE"
        self.bevel_mode = "ROUND"
        self.bevel_depth = 0.0
        self.use_fill_caps = False
        self.bevel_resolution = 4


class ObjectStub:
    def __init__(self):
        self.color = (0.0, 0.0, 0.0, 1.0)


class TestSVGStyle(unittest.TestCase):
    def test_parses_inline_style_attribute(self):
        parsed = parse_style_attribute(
            "fill: red; stroke: blue; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: bevel"
        )

        self.assertEqual(parsed["fill"], "red")
        self.assertEqual(parsed["stroke"], "blue")
        self.assertEqual(parsed["stroke-width"], "2.5")
        self.assertEqual(parsed["stroke-linecap"], "round")
        self.assertEqual(parsed["stroke-linejoin"], "bevel")

    def test_extracts_style_from_attributes_and_inline_style(self):
        element = ET.fromstring(
            '<path style="fill: red; stroke: blue; stroke-linejoin: round" stroke="green" stroke-linecap="square" visibility="hidden" />'
        )

        extracted = extract_style_attributes(element)
        self.assertEqual(extracted["fill"], "red")
        # Inline style (stroke: blue) has higher priority than presentation attribute (stroke="green")
        self.assertEqual(extracted["stroke"], "blue")
        self.assertEqual(extracted["stroke-linecap"], "square")
        self.assertEqual(extracted["stroke-linejoin"], "round")
        self.assertEqual(extracted["visibility"], "hidden")

    def test_extracts_fill_rule_from_presentation_attribute(self):
        element = ET.fromstring('<path fill-rule="evenodd" d="M0,0" />')

        extracted = extract_style_attributes(element)
        self.assertEqual(extracted["fill-rule"], "evenodd")

    def test_merges_parent_and_child_style(self):
        merged = merge_style_attributes(
            {"fill": "red", "stroke": "blue", "stroke-linecap": "round"},
            {"stroke": "green", "stroke-width": "3", "stroke-linejoin": "bevel"},
        )

        self.assertEqual(
            merged,
            {
                "fill": "red",
                "stroke": "green",
                "stroke-linecap": "round",
                "stroke-width": "3",
                "stroke-linejoin": "bevel",
            },
        )

    def test_detects_hidden_style(self):
        self.assertTrue(is_hidden_style({"display": "none"}))
        self.assertTrue(is_hidden_style({"visibility": "hidden"}))
        self.assertFalse(is_hidden_style({"fill": "red"}))

    def test_filters_exported_style_attributes(self):
        exported = export_style_attributes(
            {
                "fill": "red",
                "stroke": "blue",
                "stroke-width": "2",
                "stroke-linecap": "round",
                "stroke-linejoin": "bevel",
                "display": "inline",
            }
        )

        self.assertEqual(
            exported,
            {
                "fill": "red",
                "stroke": "blue",
                "stroke-width": "2",
                "stroke-linecap": "round",
                "stroke-linejoin": "bevel",
            },
        )

    def test_preserves_explicit_none_paint_values(self):
        exported = export_style_attributes({"fill": "none", "stroke": "none", "stroke-width": "1.5"})

        self.assertEqual(exported, {"fill": "none", "stroke": "none", "stroke-width": "1.5"})

    def test_normalizes_none_and_visibility_keywords(self):
        self.assertEqual(normalize_style_value("fill", " NONE "), "none")
        self.assertEqual(normalize_style_value("stroke", "NoNe"), "none")
        self.assertEqual(normalize_style_value("fill-rule", " EvenOdd "), "evenodd")
        self.assertEqual(normalize_style_value("stroke-linecap", " Round "), "round")
        self.assertEqual(normalize_style_value("stroke-linejoin", " Bevel "), "bevel")
        self.assertEqual(normalize_style_value("visibility", " Hidden "), "hidden")

    def test_parses_numeric_style_values_with_units(self):
        self.assertEqual(parse_numeric_style_value("2.5px"), 2.5)
        self.assertEqual(parse_numeric_style_value(" 1e1mm "), 10.0)
        self.assertIsNone(parse_numeric_style_value("abc"))

    def test_defaults_stroke_width_to_one_when_stroke_is_present(self):
        self.assertEqual(resolve_stroke_width({"stroke": "orange"}), 1.0)
        self.assertTrue(is_stroke_enabled({"stroke": "orange"}))
        self.assertIsNone(resolve_stroke_width({"stroke": "orange", "stroke-width": "0"}))

    def test_parses_supported_svg_colors(self):
        self.assertEqual(parse_color_value("orange"), (1.0, 0.647, 0.0, 1.0))
        self.assertEqual(parse_color_value("#0f08"), (0.0, 1.0, 0.0, 0.5333333333333333))
        self.assertEqual(parse_color_value("rgb(255, 128, 0)"), (1.0, 0.5019607843137255, 0.0, 1.0))
        self.assertEqual(parse_color_value("rgba(100%, 0%, 0%, 0.5)"), (1.0, 0.0, 0.0, 0.5))
        self.assertIsNone(parse_color_value("currentColor"))

    def test_resolves_display_color_preferring_stroke(self):
        self.assertEqual(
            resolve_display_color({"fill": "red", "stroke": "orange"}),
            (1.0, 0.647, 0.0, 1.0),
        )
        self.assertEqual(resolve_display_color({"fill": "#336699"}), (0.2, 0.4, 0.6, 1.0))
        self.assertIsNone(resolve_display_color({"fill": "none", "stroke": "none"}))

    def test_applies_curve_style_settings_for_stroke_display(self):
        curve = CurveStub()
        obj = ObjectStub()

        apply_curve_style_settings(
            curve,
            obj,
            {
                "fill": "none",
                "stroke": "orange",
                "stroke-width": "2.5px",
                "stroke-linecap": "square",
                "stroke-linejoin": "bevel",
            },
            scale=2.0,
        )

        self.assertEqual(curve.dimensions, "3D")
        self.assertEqual(curve.fill_mode, "NONE")
        self.assertEqual(curve.bevel_depth, 2.5)
        self.assertTrue(curve.use_fill_caps)
        self.assertEqual(curve.bevel_resolution, 0)
        self.assertEqual(obj.color, (1.0, 0.647, 0.0, 1.0))

    def test_defaults_to_filled_2d_curves_when_fill_not_explicitly_disabled(self):
        curve = CurveStub()
        obj = ObjectStub()

        apply_curve_style_settings(
            curve,
            obj,
            {"stroke": "#336699", "stroke-width": "3", "stroke-linejoin": "round"},
            scale=1.0,
        )

        self.assertEqual(curve.dimensions, "2D")
        self.assertEqual(curve.fill_mode, "BOTH")
        self.assertEqual(curve.bevel_depth, 1.5)
        self.assertGreaterEqual(curve.bevel_resolution, 1)
        self.assertEqual(obj.color, (0.2, 0.4, 0.6, 1.0))

    def test_stroke_defaults_to_visible_width_when_omitted(self):
        curve = CurveStub()
        obj = ObjectStub()

        apply_curve_style_settings(
            curve,
            obj,
            {"fill": "none", "stroke": "orange"},
            scale=2.0,
        )

        self.assertEqual(curve.dimensions, "3D")
        self.assertEqual(curve.bevel_depth, 1.0)
        self.assertEqual(obj.color, (1.0, 0.647, 0.0, 1.0))

    def test_parses_css_style_block_with_comma_selectors(self):
        css = ".cls-1, .cls-7 { fill: #009540; }\n.cls-2 { fill: #e20613; }"
        rules = parse_css_style_block(css)

        self.assertIn("cls-1", rules.by_class)
        self.assertIn("cls-7", rules.by_class)
        self.assertIn("cls-2", rules.by_class)
        self.assertEqual(rules.by_class["cls-1"]["fill"], "#009540")
        self.assertEqual(rules.by_class["cls-7"]["fill"], "#009540")
        self.assertEqual(rules.by_class["cls-2"]["fill"], "#e20613")

    def test_css_class_styles_resolve_on_elements(self):
        rules = parse_css_style_block(".red { fill: #ff0000; }")
        element = ET.fromstring('<path class="red" d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertEqual(extracted["fill"], "#ff0000")

    def test_inline_style_overrides_css_class(self):
        rules = parse_css_style_block(".red { fill: #ff0000; }")
        element = ET.fromstring('<path class="red" style="fill: blue" d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertEqual(extracted["fill"], "blue")

    def test_css_class_overrides_presentation_attribute(self):
        """CSS class selector (specificity 0-1-0) beats presentation attribute (specificity 0)."""
        rules = parse_css_style_block(".red { fill: #ff0000; }")
        element = ET.fromstring('<path class="red" fill="green" d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertEqual(extracted["fill"], "#ff0000")

    def test_inline_style_overrides_presentation_attribute(self):
        """Inline style (highest priority) beats presentation attribute."""
        element = ET.fromstring('<path fill="green" style="fill: blue" d="M0,0"/>')
        extracted = extract_style_attributes(element)
        self.assertEqual(extracted["fill"], "blue")

    def test_inline_style_overrides_both_css_and_presentation(self):
        """Inline style beats both CSS class and presentation attribute."""
        rules = parse_css_style_block(".red { fill: #ff0000; }")
        element = ET.fromstring('<path class="red" fill="green" style="fill: blue" d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertEqual(extracted["fill"], "blue")

    def test_css_block_ignores_non_class_selectors(self):
        css = "path { fill: red; }\n#myid { fill: blue; }\n.valid { fill: green; }"
        rules = parse_css_style_block(css)

        self.assertEqual(len(rules.by_class), 1)
        self.assertIn("valid", rules.by_class)
        self.assertEqual(len(rules.by_element), 1)
        self.assertIn("path", rules.by_element)
        self.assertEqual(len(rules.by_id), 1)
        self.assertIn("myid", rules.by_id)

    def test_css_block_strips_comments(self):
        css = "/* comment */ .cls { fill: red; } /* end */"
        rules = parse_css_style_block(css)

        self.assertEqual(rules.by_class["cls"]["fill"], "red")

    def test_element_without_class_returns_empty_from_class_resolution(self):
        rules = parse_css_style_block(".red { fill: #ff0000; }")
        element = ET.fromstring('<path d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertNotIn("fill", extracted)

    def test_element_type_selector_applies_to_matching_tag(self):
        rules = parse_css_style_block("path { stroke: black; stroke-width: 2; }")
        element = ET.fromstring('<path d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertEqual(extracted["stroke"], "black")
        self.assertEqual(extracted["stroke-width"], "2")

    def test_id_selector_overrides_class_selector(self):
        """ID selector (specificity 1-0-0) beats class selector (0-1-0)."""
        rules = parse_css_style_block(".red { fill: red; }\n#special { fill: blue; }")
        element = ET.fromstring('<path class="red" id="special" d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertEqual(extracted["fill"], "blue")

    def test_class_selector_overrides_element_type_selector(self):
        """Class selector (specificity 0-1-0) beats element type selector (0-0-1)."""
        rules = parse_css_style_block("path { fill: black; }\n.red { fill: red; }")
        element = ET.fromstring('<path class="red" d="M0,0"/>')

        extracted = extract_style_attributes(element, rules)
        self.assertEqual(extracted["fill"], "red")

    def test_full_cascade_priority_order(self):
        """Verify complete cascade: presentation < element CSS < class CSS < ID CSS < inline."""
        rules = parse_css_style_block(
            "path { fill: black; stroke: black; stroke-width: 1; }\n"
            ".cls { fill: green; stroke: green; }\n"
            "#item { fill: blue; }"
        )
        element = ET.fromstring(
            '<path class="cls" id="item" fill="gray" stroke="gray" '
            'stroke-width="5" style="fill: red" d="M0,0"/>'
        )

        extracted = extract_style_attributes(element, rules)
        # fill: presentation(gray) < element(black) < class(green) < id(blue) < inline(red)
        self.assertEqual(extracted["fill"], "red")
        # stroke: presentation(gray) < element(black) < class(green), no id or inline
        self.assertEqual(extracted["stroke"], "green")
        # stroke-width: presentation(5) < element(1), no class/id/inline
        self.assertEqual(extracted["stroke-width"], "1")


if __name__ == "__main__":
    unittest.main()
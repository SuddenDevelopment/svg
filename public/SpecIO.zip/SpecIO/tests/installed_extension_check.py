"""Verify a packaged SpecIO extension is installed, enabled, and operational.

Run this after installing the built package into a Blender profile.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile

import bpy


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _write_svg(path: Path) -> None:
    path.write_text(
        """<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80" viewBox="0 0 120 80">
  <g id="InstallCheck">
    <rect id="installRect" x="10" y="10" width="40" height="20" fill="#dd6644" />
    <path id="installPath" d="M 70 10 C 85 10 95 30 110 30" fill="none" stroke="#2244aa" stroke-width="3" />
  </g>
</svg>
""",
        encoding="utf-8",
    )


def main(argv: list[str]) -> int:
    _assert(hasattr(bpy.types.Scene, "specio"), "Expected Scene.specio property group from installed extension")
    _assert(hasattr(bpy.ops.specio, "import_svg"), "Expected specio.import_svg operator from installed extension")
    _assert(hasattr(bpy.ops.specio, "export_svg"), "Expected specio.export_svg operator from installed extension")

    bpy.context.scene.specio.import_scale = 1.0
    bpy.context.scene.specio.export_scale = 1.0
    bpy.context.scene.specio.export_precision = 3

    with tempfile.TemporaryDirectory(prefix="specio-installed-") as temp_dir:
        work_dir = Path(temp_dir)
        input_path = work_dir / "installed_check.svg"
        output_path = work_dir / "installed_check_out.svg"
        _write_svg(input_path)

        import_result = list(bpy.ops.specio.import_svg(filepath=str(input_path)))
        _assert(import_result == ["FINISHED"], "Installed extension import did not finish successfully")
        _assert(bpy.data.objects.get("installRect") is not None, "Expected installRect object from installed extension import")
        _assert(bpy.data.objects.get("installPath") is not None, "Expected installPath object from installed extension import")

        bpy.ops.object.select_all(action="DESELECT")
        active = None
        for object_name in ("installRect", "installPath"):
            obj = bpy.data.objects.get(object_name)
            _assert(obj is not None, f"Expected imported object '{object_name}'")
            obj.select_set(True)
            if active is None:
                active = obj
        bpy.context.view_layer.objects.active = active

        export_result = list(bpy.ops.specio.export_svg(filepath=str(output_path)))
        _assert(export_result == ["FINISHED"], "Installed extension export did not finish successfully")
        _assert(output_path.exists(), "Expected installed extension export to create an SVG file")

        print(
            json.dumps(
                {
                    "ok": True,
                    "import_result": import_result,
                    "export_result": export_result,
                    "object_names": ["installRect", "installPath"],
                    "output_path": str(output_path),
                },
                indent=2,
            )
        )

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []))
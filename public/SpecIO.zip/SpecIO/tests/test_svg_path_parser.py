import unittest

from io_svg.formatting import format_number, format_xy
from io_svg.path_parser import parse_svg_path, recommended_curve_resolution


class TestSVGPathParser(unittest.TestCase):
    def test_parses_absolute_line_path(self):
        subpaths = parse_svg_path("M 0 0 L 10 0 L 10 10 Z")

        self.assertEqual(len(subpaths), 1)
        subpath = subpaths[0]
        self.assertEqual(subpath.start, (0.0, 0.0))
        self.assertTrue(subpath.closed)
        self.assertEqual([segment.kind for segment in subpath.segments], ["L", "L"])
        self.assertEqual([segment.end for segment in subpath.segments], [(10.0, 0.0), (10.0, 10.0)])

    def test_parses_relative_and_axis_commands(self):
        subpaths = parse_svg_path("m 5 5 h 10 v 15 l -5 -5")

        self.assertEqual(len(subpaths), 1)
        subpath = subpaths[0]
        self.assertEqual(subpath.start, (5.0, 5.0))
        self.assertEqual([segment.end for segment in subpath.segments], [(15.0, 5.0), (15.0, 20.0), (10.0, 15.0)])

    def test_parses_cubic_segments(self):
        subpaths = parse_svg_path("M 0 0 C 10 0 10 10 20 10 c 5 0 5 10 10 10")

        self.assertEqual(len(subpaths), 1)
        subpath = subpaths[0]
        self.assertEqual([segment.kind for segment in subpath.segments], ["C", "C"])
        self.assertEqual(subpath.segments[0].control1, (10.0, 0.0))
        self.assertEqual(subpath.segments[0].control2, (10.0, 10.0))
        self.assertEqual(subpath.segments[0].end, (20.0, 10.0))
        self.assertEqual(subpath.segments[1].control1, (25.0, 10.0))
        self.assertEqual(subpath.segments[1].control2, (25.0, 20.0))
        self.assertEqual(subpath.segments[1].end, (30.0, 20.0))

    def test_parses_smooth_cubic_segments(self):
        subpaths = parse_svg_path("M 0 0 C 10 0 10 10 20 10 S 30 20 40 10")

        self.assertEqual(len(subpaths), 1)
        subpath = subpaths[0]
        self.assertEqual([segment.kind for segment in subpath.segments], ["C", "C"])
        self.assertEqual(subpath.segments[1].control1, (30.0, 10.0))
        self.assertEqual(subpath.segments[1].control2, (30.0, 20.0))
        self.assertEqual(subpath.segments[1].end, (40.0, 10.0))

    def test_parses_quadratic_and_smooth_quadratic_as_cubic(self):
        subpaths = parse_svg_path("M 0 0 Q 10 10 20 0 t 20 0")

        self.assertEqual(len(subpaths), 1)
        subpath = subpaths[0]
        self.assertEqual([segment.kind for segment in subpath.segments], ["C", "C"])
        self.assertEqual(subpath.segments[0].control1, (6.666666666666666, 6.666666666666666))
        self.assertEqual(subpath.segments[0].control2, (13.333333333333334, 6.666666666666666))
        self.assertEqual(subpath.segments[0].end, (20.0, 0.0))
        self.assertEqual(subpath.segments[1].end, (40.0, 0.0))

    def test_parses_arc_segments_as_cubic(self):
        subpaths = parse_svg_path("M 0 0 A 10 10 0 0 1 20 0")

        self.assertEqual(len(subpaths), 1)
        subpath = subpaths[0]
        self.assertTrue(all(segment.kind == "C" for segment in subpath.segments))
        self.assertEqual(subpath.segments[-1].end, (20.0, 0.0))
        self.assertGreaterEqual(len(subpath.segments), 1)

    def test_parses_relative_arc_segments(self):
        subpaths = parse_svg_path("M 5 5 a 10 10 0 0 1 20 0")

        self.assertEqual(len(subpaths), 1)
        self.assertEqual(subpaths[0].segments[-1].end, (25.0, 5.0))

    def test_parses_rotated_arc_segments(self):
        subpaths = parse_svg_path("M 10 20 A 30 15 45 0 1 80 70")

        self.assertEqual(len(subpaths), 1)
        subpath = subpaths[0]
        self.assertEqual([segment.kind for segment in subpath.segments], ["C", "C"])
        self.assertAlmostEqual(subpath.segments[0].end[0], 50.0, places=5)
        self.assertAlmostEqual(subpath.segments[0].end[1], 20.0, places=5)
        self.assertEqual(subpath.segments[-1].end, (80.0, 70.0))

    def test_arc_sweep_flag_changes_curve_direction(self):
        sweep_positive = parse_svg_path("M 0 0 A 20 20 0 0 1 40 0")[0]
        sweep_negative = parse_svg_path("M 0 0 A 20 20 0 0 0 40 0")[0]

        self.assertEqual(sweep_positive.segments[-1].end, (40.0, 0.0))
        self.assertEqual(sweep_negative.segments[-1].end, (40.0, 0.0))
        self.assertLess(sweep_positive.segments[0].end[1], 0.0)
        self.assertGreater(sweep_negative.segments[0].end[1], 0.0)

    def test_large_arc_flag_changes_segment_count(self):
        small_arc = parse_svg_path("M 10 10 A 30 20 0 0 1 50 20")[0]
        large_arc = parse_svg_path("M 10 10 A 30 20 0 1 1 50 20")[0]

        self.assertEqual(small_arc.segments[-1].end, (50.0, 20.0))
        self.assertEqual(large_arc.segments[-1].end, (50.0, 20.0))
        self.assertEqual(len(small_arc.segments), 2)
        self.assertEqual(len(large_arc.segments), 3)

    def test_recommends_high_resolution_for_few_cubic_segments(self):
        subpaths = parse_svg_path("M 0 0 H 10 V 20 C 8 30 2 30 0 20 Z")

        self.assertEqual(recommended_curve_resolution(subpaths), 64)

    def test_recommends_lower_resolution_for_dense_cubic_paths(self):
        subpaths = parse_svg_path(
            "M 0 0 C 1 0 1 1 2 1 C 3 1 3 2 4 2 C 5 2 5 3 6 3 C 7 3 7 4 8 4 C 9 4 9 5 10 5 C 11 5 11 6 12 6 C 13 6 13 7 14 7 C 15 7 15 8 16 8 C 17 8 17 9 18 9"
        )

        self.assertEqual(recommended_curve_resolution(subpaths), 24)

    def test_recommends_default_resolution_for_line_only_paths(self):
        subpaths = parse_svg_path("M 0 0 L 10 0 L 10 10 Z")

        self.assertEqual(recommended_curve_resolution(subpaths), 12)

    def test_ignores_malformed_trailing_data(self):
        subpaths = parse_svg_path("M 0 0 L 10")

        self.assertEqual(len(subpaths), 1)
        self.assertEqual(subpaths[0].start, (0.0, 0.0))
        self.assertEqual(subpaths[0].segments, [])


class TestSVGFormatting(unittest.TestCase):
    def test_format_number_trims_noise(self):
        self.assertEqual(format_number(1.2300, 3), "1.23")
        self.assertEqual(format_number(-0.0, 3), "0")
        self.assertEqual(format_number(10.0, 3), "10")

    def test_format_xy_formats_pair(self):
        self.assertEqual(format_xy((1.25, -3.5), 2), "1.25 -3.5")


if __name__ == "__main__":
    unittest.main()
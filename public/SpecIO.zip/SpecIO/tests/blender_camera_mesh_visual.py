"""Visual regression for camera-projected mesh export using a fixed Blender fixture.

Run with Blender from the repository root, for example:

    blender -b --factory-startup --python tests/blender_camera_mesh_visual.py -- --blend ../cyberdash/assets/logo_cube_2.blend
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import tempfile

import bpy


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BLEND = REPO_ROOT.parent / "cyberdash" / "assets" / "logo_cube_2.blend"
DEFAULT_OBJECTS = ("Cube.004", "Cube.005")


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render original meshes and imported SVG to compare visible coverage")
    parser.add_argument(
        "--blend",
        default=str(DEFAULT_BLEND),
        help="Blend file to open for the visual regression case.",
    )
    parser.add_argument(
        "--objects",
        nargs="+",
        default=list(DEFAULT_OBJECTS),
        help="Object names to include in the visual comparison.",
    )
    parser.add_argument(
        "--alpha-mae-threshold",
        type=float,
        default=0.02,
        help="Maximum allowed mean absolute alpha error.",
    )
    parser.add_argument(
        "--changed-pixel-threshold",
        type=float,
        default=0.06,
        help="Maximum allowed fraction of pixels with meaningful alpha change.",
    )
    parser.add_argument(
        "--artifact-dir",
        default=str(REPO_ROOT / "artifacts" / "camera_mesh_visual"),
        help="Directory where original/imported/diff render artifacts will be written.",
    )
    return parser.parse_args(argv)


def _configure_render(output_path: Path, resolution_x: int, resolution_y: int, resolution_percentage: int) -> None:
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys() else "BLENDER_EEVEE"
    scene.render.resolution_x = resolution_x
    scene.render.resolution_y = resolution_y
    scene.render.resolution_percentage = resolution_percentage
    scene.render.film_transparent = True
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.filepath = str(output_path)


def _render_to_file(output_path: Path, resolution_x: int, resolution_y: int, resolution_percentage: int) -> None:
    _configure_render(output_path, resolution_x, resolution_y, resolution_percentage)
    bpy.ops.render.render(write_still=True)


def _load_pixels(image_path: Path) -> tuple[list[float], tuple[int, int]]:
    image = bpy.data.images.load(str(image_path), check_existing=False)
    try:
        pixels = list(image.pixels)
        size = (int(image.size[0]), int(image.size[1]))
    finally:
        bpy.data.images.remove(image)
    return pixels, size


def _compare_alpha_pixels(reference_pixels: list[float], candidate_pixels: list[float]) -> dict[str, float]:
    _assert(len(reference_pixels) == len(candidate_pixels), "Expected both renders to have the same pixel count")
    total = 0.0
    max_delta = 0.0
    changed_pixels = 0
    pixel_count = len(reference_pixels) // 4

    for index in range(3, len(reference_pixels), 4):
        delta = abs(reference_pixels[index] - candidate_pixels[index])
        total += delta
        max_delta = max(max_delta, delta)
        if delta > 0.1:
            changed_pixels += 1

    return {
        "alpha_mean_absolute_error": total / max(pixel_count, 1),
        "alpha_max_delta": max_delta,
        "changed_pixel_ratio": changed_pixels / max(pixel_count, 1),
    }


def _alpha_change_bbox(reference_pixels: list[float], candidate_pixels: list[float], size: tuple[int, int]) -> list[int] | None:
    width, height = size
    min_x = width
    min_y = height
    max_x = -1
    max_y = -1
    for pixel_index in range(width * height):
        alpha_index = pixel_index * 4 + 3
        delta = abs(reference_pixels[alpha_index] - candidate_pixels[alpha_index])
        if delta <= 0.1:
            continue
        x = pixel_index % width
        y = pixel_index // width
        min_x = min(min_x, x)
        min_y = min(min_y, y)
        max_x = max(max_x, x)
        max_y = max(max_y, y)

    if max_x < 0 or max_y < 0:
        return None
    return [min_x, min_y, max_x, max_y]


def _write_alpha_diff_image(
    output_path: Path,
    reference_pixels: list[float],
    candidate_pixels: list[float],
    size: tuple[int, int],
) -> None:
    image = bpy.data.images.new(output_path.stem, width=size[0], height=size[1], alpha=True)
    try:
        pixels: list[float] = []
        for pixel_index in range(size[0] * size[1]):
            alpha_index = pixel_index * 4 + 3
            delta = abs(reference_pixels[alpha_index] - candidate_pixels[alpha_index])
            pixels.extend((delta, 0.0, 0.0, 1.0))
        image.pixels = pixels
        image.filepath_raw = str(output_path)
        image.file_format = "PNG"
        image.save()
    finally:
        bpy.data.images.remove(image)


def _ensure_override_material() -> bpy.types.Material:
    material = bpy.data.materials.get("SpecIOVisualOverride")
    if material is None:
        material = bpy.data.materials.new("SpecIOVisualOverride")
    material.use_nodes = True
    node_tree = material.node_tree
    nodes = node_tree.nodes
    links = node_tree.links
    nodes.clear()
    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (300, 0)
    emission = nodes.new("ShaderNodeEmission")
    emission.location = (0, 0)
    emission.inputs["Color"].default_value = (1.0, 1.0, 1.0, 1.0)
    emission.inputs["Strength"].default_value = 1.0
    links.new(emission.outputs["Emission"], output.inputs["Surface"])
    return material


def _set_render_visibility(target_names: set[str]) -> None:
    scene = bpy.context.scene
    camera_name = scene.camera.name if scene.camera is not None else None
    for obj in bpy.data.objects:
        keep_visible = obj.name in target_names or obj.name == camera_name
        obj.hide_render = not keep_visible


def _export_selected(output_path: Path, object_names: list[str]) -> list[str]:
    bpy.ops.object.select_all(action="DESELECT")
    active = None
    for object_name in object_names:
        obj = bpy.data.objects.get(object_name)
        _assert(obj is not None, f"Expected object '{object_name}'")
        obj.select_set(True)
        if active is None:
            active = obj
    _assert(active is not None, "Expected at least one object to export")
    bpy.context.view_layer.objects.active = active
    return list(bpy.ops.specio.export_svg(filepath=str(output_path)))


def _import_root_collection_name(input_path: Path) -> str:
    return f"{input_path.stem}_SVG"


def _collection_object_names(collection_name: str) -> list[str]:
    collection = bpy.data.collections.get(collection_name)
    _assert(collection is not None, f"Expected collection '{collection_name}'")
    names: list[str] = []

    def visit(current) -> None:
        for obj in current.objects:
            if obj.name not in names:
                names.append(obj.name)
        for child in current.children:
            visit(child)

    visit(collection)
    return names


def _reset_to_empty_scene() -> None:
    bpy.ops.wm.read_factory_settings(use_empty=True)


def _ensure_import_render_camera(render_width: float, render_height: float) -> None:
    scene = bpy.context.scene
    camera_data = bpy.data.cameras.new("SpecIOVisualMeshCamera")
    camera_data.type = "ORTHO"
    camera_data.ortho_scale = max(render_width, render_height)
    camera = bpy.data.objects.new("SpecIOVisualMeshCamera", camera_data)
    scene.collection.objects.link(camera)
    camera.location = (render_width / 2.0, -render_height / 2.0, 100.0)
    camera.rotation_euler = (0.0, 0.0, 0.0)
    camera.data.clip_start = 0.1
    camera.data.clip_end = 1000.0
    scene.camera = camera


def main(argv: list[str]) -> int:
    args = _parse_args(argv)
    blend_path = Path(args.blend).resolve()
    _assert(blend_path.exists(), f"Blend file does not exist: {blend_path}")

    bpy.ops.wm.open_mainfile(filepath=str(blend_path))

    sys.path.insert(0, str(REPO_ROOT.parent))
    import SpecIO

    SpecIO.register()
    try:
        scene = bpy.context.scene
        resolution_x = int(scene.render.resolution_x)
        resolution_y = int(scene.render.resolution_y)
        resolution_percentage = int(scene.render.resolution_percentage)
        render_width = resolution_x * resolution_percentage / 100.0
        render_height = resolution_y * resolution_percentage / 100.0

        target_names = set(args.objects)
        for object_name in target_names:
            _assert(bpy.data.objects.get(object_name) is not None, f"Expected object '{object_name}' in {blend_path}")
        _assert(scene.camera is not None, "Expected the regression blend to have an active scene camera")

        artifact_dir = Path(args.artifact_dir).resolve() / "__".join(args.objects)
        artifact_dir.mkdir(parents=True, exist_ok=True)

        with tempfile.TemporaryDirectory(prefix="specio-camera-mesh-visual-") as temp_dir:
            work_dir = Path(temp_dir)
            original_png = work_dir / "original.png"
            exported_svg = work_dir / "roundtrip.svg"
            imported_png = work_dir / "imported.png"
            diff_png = artifact_dir / "alpha_diff.png"
            original_copy = artifact_dir / "original.png"
            imported_copy = artifact_dir / "imported.png"
            exported_copy = artifact_dir / "roundtrip.svg"

            override_material = _ensure_override_material()
            bpy.context.view_layer.material_override = override_material
            _set_render_visibility(target_names)
            _render_to_file(original_png, resolution_x, resolution_y, resolution_percentage)

            export_result = _export_selected(exported_svg, list(args.objects))
            _assert(export_result == ["FINISHED"], "Expected blend export to finish successfully")

            SpecIO.unregister()
            _reset_to_empty_scene()
            SpecIO.register()
            imported_scene = bpy.context.scene
            imported_scene.specio.import_scale = 1.0
            imported_scene.specio.export_scale = 1.0
            imported_scene.specio.export_precision = 3
            import_result = list(bpy.ops.specio.import_svg(filepath=str(exported_svg)))
            _assert(import_result == ["FINISHED"], "Expected imported SVG to load successfully")

            root_collection_name = _import_root_collection_name(exported_svg)
            imported_object_names = _collection_object_names(root_collection_name)
            _assert(imported_object_names, "Expected imported SVG objects for visual regression")

            _ensure_import_render_camera(render_width, render_height)
            bpy.context.view_layer.material_override = _ensure_override_material()
            _set_render_visibility(set(imported_object_names))
            _render_to_file(imported_png, resolution_x, resolution_y, resolution_percentage)

            original_pixels, original_size = _load_pixels(original_png)
            imported_pixels, imported_size = _load_pixels(imported_png)
            _assert(original_size == imported_size, "Expected original and imported renders to share dimensions")

            original_copy.write_bytes(original_png.read_bytes())
            imported_copy.write_bytes(imported_png.read_bytes())
            exported_copy.write_bytes(exported_svg.read_bytes())
            _write_alpha_diff_image(diff_png, original_pixels, imported_pixels, original_size)

            metrics = _compare_alpha_pixels(original_pixels, imported_pixels)
            change_bbox = _alpha_change_bbox(original_pixels, imported_pixels, original_size)
            print(
                json.dumps(
                    {
                        "blend": str(blend_path),
                        "objects": list(args.objects),
                        "export_result": export_result,
                        "import_result": import_result,
                        "render_size": original_size,
                        "metrics": metrics,
                        "changed_pixel_bbox": change_bbox,
                        "artifacts": {
                            "original": str(original_copy),
                            "imported": str(imported_copy),
                            "diff": str(diff_png),
                            "svg": str(exported_copy),
                        },
                    },
                    indent=2,
                )
            )
            _assert(
                metrics["alpha_mean_absolute_error"] <= args.alpha_mae_threshold,
                f"Alpha MAE too high: {metrics['alpha_mean_absolute_error']:.6f}",
            )
            _assert(
                metrics["changed_pixel_ratio"] <= args.changed_pixel_threshold,
                f"Changed-pixel ratio too high: {metrics['changed_pixel_ratio']:.6f}",
            )
            print(json.dumps({"ok": True}, indent=2))
    finally:
        try:
            SpecIO.unregister()
        except Exception:
            pass

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []))
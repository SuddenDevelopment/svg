import unittest
import xml.etree.ElementTree as ET

from io_svg.gradients import average_gradient_color, extract_paint_server_id, parse_svg_gradients


class TestSVGGradients(unittest.TestCase):
    def test_extracts_paint_server_id(self):
        self.assertEqual(extract_paint_server_id("url(#lens) rgb(0, 0, 0)"), "lens")
        self.assertIsNone(extract_paint_server_id("red"))

    def test_parses_linear_gradient_with_inherited_stops(self):
        root = ET.fromstring(
            """
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
              <defs>
                <linearGradient id="base" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#ff0000" />
                  <stop offset="100%" stop-color="#0000ff" />
                </linearGradient>
                <linearGradient id="derived" xlink:href="#base" gradientUnits="userSpaceOnUse" x1="10" x2="30" />
              </defs>
            </svg>
            """
        )

        gradients = parse_svg_gradients(root)
        derived = gradients["derived"]
        self.assertEqual(derived.kind, "linear")
        self.assertEqual(derived.gradient_units, "userSpaceOnUse")
        self.assertEqual((derived.x1, derived.y1, derived.x2, derived.y2), (10.0, 0.0, 30.0, 0.0))
        self.assertEqual(len(derived.stops), 2)

    def test_parses_radial_gradient_defaults_and_average_color(self):
        root = ET.fromstring(
            """
            <svg xmlns="http://www.w3.org/2000/svg">
              <defs>
                <radialGradient id="lens">
                  <stop offset="0" style="stop-color:white;stop-opacity:1" />
                  <stop offset="1" style="stop-color:black;stop-opacity:0.5" />
                </radialGradient>
              </defs>
            </svg>
            """
        )

        gradients = parse_svg_gradients(root)
        lens = gradients["lens"]
        self.assertEqual(lens.kind, "radial")
        self.assertEqual((lens.cx, lens.cy, lens.r, lens.fx, lens.fy), (0.5, 0.5, 0.5, 0.5, 0.5))
        self.assertEqual(average_gradient_color(lens), (0.5, 0.5, 0.5, 0.75))


if __name__ == "__main__":
    unittest.main()
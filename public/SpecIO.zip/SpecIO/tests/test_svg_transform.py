import unittest

from io_svg.transform import IDENTITY_TRANSFORM, apply_transform, multiply_transforms, parse_svg_transform


class TestSVGTransform(unittest.TestCase):
    def test_returns_identity_for_missing_transform(self):
        self.assertEqual(parse_svg_transform(None), IDENTITY_TRANSFORM)

    def test_parses_scale_transform(self):
        transform = parse_svg_transform("scale(-1, 2)")
        self.assertEqual(apply_transform((3.0, 4.0), transform), (-3.0, 8.0))

    def test_parses_matrix_transform(self):
        transform = parse_svg_transform("matrix(0, -1, 1, 0, 0, 0)")
        self.assertEqual(apply_transform((5.0, 7.0), transform), (7.0, -5.0))

    def test_parses_translate_and_rotate_about_center(self):
        transform = parse_svg_transform("translate(10, 5) rotate(90, 10, 5)")
        x, y = apply_transform((12.0, 5.0), transform)
        self.assertAlmostEqual(x, 5.0)
        self.assertAlmostEqual(y, 17.0)

    def test_multiplies_nested_transforms(self):
        parent = parse_svg_transform("translate(10, 0)")
        child = parse_svg_transform("scale(2)")
        combined = multiply_transforms(parent, child)
        self.assertEqual(apply_transform((3.0, 4.0), combined), (16.0, 8.0))


if __name__ == "__main__":
    unittest.main()
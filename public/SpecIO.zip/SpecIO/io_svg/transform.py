"""Pure SVG transform parsing helpers."""

from __future__ import annotations

import math
import re


AffineTransform = tuple[float, float, float, float, float, float]

IDENTITY_TRANSFORM: AffineTransform = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)

TRANSFORM_RE = re.compile(r"([A-Za-z]+)\s*\(([^)]*)\)")
NUMBER_RE = re.compile(r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?")


def parse_svg_transform(transform_text: str | None) -> AffineTransform:
    """Parse an SVG transform attribute into a 2D affine transform tuple."""
    if not transform_text or not transform_text.strip():
        return IDENTITY_TRANSFORM

    transform = IDENTITY_TRANSFORM
    for name, args_text in TRANSFORM_RE.findall(transform_text):
        args = [float(value) for value in NUMBER_RE.findall(args_text)]
        current = _transform_for_command(name, args)
        transform = multiply_transforms(current, transform)
    return transform


def multiply_transforms(left: AffineTransform, right: AffineTransform) -> AffineTransform:
    """Return the affine transform for applying right, then left."""
    a1, b1, c1, d1, e1, f1 = left
    a2, b2, c2, d2, e2, f2 = right
    return (
        a1 * a2 + c1 * b2,
        b1 * a2 + d1 * b2,
        a1 * c2 + c1 * d2,
        b1 * c2 + d1 * d2,
        a1 * e2 + c1 * f2 + e1,
        b1 * e2 + d1 * f2 + f1,
    )


def apply_transform(point: tuple[float, float], transform: AffineTransform) -> tuple[float, float]:
    """Apply an affine transform to a 2D point."""
    x, y = point
    a, b, c, d, e, f = transform
    return (a * x + c * y + e, b * x + d * y + f)


def invert_transform(transform: AffineTransform) -> AffineTransform:
    """Return the inverse affine transform or identity if singular."""
    a, b, c, d, e, f = transform
    determinant = a * d - b * c
    if abs(determinant) < 1e-12:
        return IDENTITY_TRANSFORM

    inverse_scale = 1.0 / determinant
    inverse = (
        d * inverse_scale,
        -b * inverse_scale,
        -c * inverse_scale,
        a * inverse_scale,
        0.0,
        0.0,
    )
    ia, ib, ic, id_, _, _ = inverse
    return (
        ia,
        ib,
        ic,
        id_,
        -(ia * e + ic * f),
        -(ib * e + id_ * f),
    )


def _transform_for_command(name: str, args: list[float]) -> AffineTransform:
    normalized_name = name.strip().lower()
    if normalized_name == "matrix" and len(args) == 6:
        return tuple(args)  # type: ignore[return-value]
    if normalized_name == "translate":
        tx = args[0] if args else 0.0
        ty = args[1] if len(args) > 1 else 0.0
        return (1.0, 0.0, 0.0, 1.0, tx, ty)
    if normalized_name == "scale":
        sx = args[0] if args else 1.0
        sy = args[1] if len(args) > 1 else sx
        return (sx, 0.0, 0.0, sy, 0.0, 0.0)
    if normalized_name == "rotate":
        angle = math.radians(args[0]) if args else 0.0
        rotation = _rotation_transform(angle)
        if len(args) < 3:
            return rotation
        cx, cy = args[1], args[2]
        return multiply_transforms(
            (1.0, 0.0, 0.0, 1.0, cx, cy),
            multiply_transforms(
                rotation,
                (1.0, 0.0, 0.0, 1.0, -cx, -cy),
            ),
        )
    if normalized_name == "skewx" and args:
        tangent = math.tan(math.radians(args[0]))
        return (1.0, 0.0, tangent, 1.0, 0.0, 0.0)
    if normalized_name == "skewy" and args:
        tangent = math.tan(math.radians(args[0]))
        return (1.0, tangent, 0.0, 1.0, 0.0, 0.0)
    return IDENTITY_TRANSFORM


def _rotation_transform(angle: float) -> AffineTransform:
    cosine = math.cos(angle)
    sine = math.sin(angle)
    return (cosine, sine, -sine, cosine, 0.0, 0.0)
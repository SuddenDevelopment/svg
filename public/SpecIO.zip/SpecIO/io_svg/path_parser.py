"""Pure Python SVG path parsing helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
import math
import re


Point = tuple[float, float]

TOKEN_RE = re.compile(
    r"[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?"
)


@dataclass(slots=True)
class PathSegment:
    """A parsed SVG path segment."""

    kind: str
    end: Point
    control1: Point | None = None
    control2: Point | None = None


@dataclass(slots=True)
class PathSubpath:
    """A parsed SVG subpath beginning with a move command."""

    start: Point
    segments: list[PathSegment] = field(default_factory=list)
    closed: bool = False


def recommended_curve_resolution(subpaths: list[PathSubpath]) -> int:
    """Return a Blender curve resolution suited to the parsed path complexity."""
    cubic_counts = [
        sum(1 for segment in subpath.segments if segment.kind == "C")
        for subpath in subpaths
        if subpath.segments
    ]
    if not cubic_counts:
        return 12

    smallest_cubic_count = min((count for count in cubic_counts if count > 0), default=0)
    if smallest_cubic_count == 0:
        return 12
    if smallest_cubic_count <= 2:
        return 64
    if smallest_cubic_count <= 4:
        return 48
    if smallest_cubic_count <= 8:
        return 32
    return 24


def parse_svg_path(path_data: str) -> list[PathSubpath]:
    """Parse a supported subset of SVG path commands.

    Supported commands: M, m, L, l, H, h, V, v, C, c, S, s, Q, q, T, t, A, a, Z, z.
    Malformed trailing data is ignored instead of raising.
    """
    tokens = TOKEN_RE.findall(path_data)
    if not tokens:
        return []

    subpaths: list[PathSubpath] = []
    current_command: str | None = None
    current_point: Point = (0.0, 0.0)
    active_subpath: PathSubpath | None = None
    previous_cubic_control: Point | None = None
    previous_quadratic_control: Point | None = None
    index = 0

    while index < len(tokens):
        token = tokens[index]
        if _is_command(token):
            current_command = token
            index += 1
            if current_command in {"Z", "z"}:
                if active_subpath is not None:
                    active_subpath.closed = True
                    current_point = active_subpath.start
                previous_cubic_control = None
                previous_quadratic_control = None
                continue

        if current_command is None:
            break

        command = current_command

        if command in {"M", "m"}:
            coords, index = _read_coordinate_sequence(tokens, index)
            if not coords:
                break

            current_point = _resolve_point(command, current_point, coords[0])
            active_subpath = PathSubpath(start=current_point)
            subpaths.append(active_subpath)
            previous_cubic_control = None
            previous_quadratic_control = None

            for coord in coords[1:]:
                next_point = _resolve_point(command, current_point, coord)
                active_subpath.segments.append(PathSegment(kind="L", end=next_point))
                current_point = next_point
            current_command = "L" if command == "M" else "l"
            continue

        if active_subpath is None:
            index = _skip_to_next_command(tokens, index)
            continue

        if command in {"L", "l"}:
            coords, index = _read_coordinate_sequence(tokens, index)
            if not coords:
                break
            for coord in coords:
                current_point = _append_line(active_subpath, command, current_point, coord)
            previous_cubic_control = None
            previous_quadratic_control = None
            continue

        if command in {"H", "h"}:
            values, index = _read_number_sequence(tokens, index)
            if not values:
                break
            for value in values:
                next_point = _resolve_horizontal(command, current_point, value)
                active_subpath.segments.append(PathSegment(kind="L", end=next_point))
                current_point = next_point
            previous_cubic_control = None
            previous_quadratic_control = None
            continue

        if command in {"V", "v"}:
            values, index = _read_number_sequence(tokens, index)
            if not values:
                break
            for value in values:
                next_point = _resolve_vertical(command, current_point, value)
                active_subpath.segments.append(PathSegment(kind="L", end=next_point))
                current_point = next_point
            previous_cubic_control = None
            previous_quadratic_control = None
            continue

        if command in {"C", "c"}:
            groups, index = _read_cubic_sequence(tokens, index)
            if not groups:
                break
            for control1, control2, end in groups:
                if command.islower():
                    resolved_c1 = (current_point[0] + control1[0], current_point[1] + control1[1])
                    resolved_c2 = (current_point[0] + control2[0], current_point[1] + control2[1])
                    resolved_end = (current_point[0] + end[0], current_point[1] + end[1])
                else:
                    resolved_c1 = control1
                    resolved_c2 = control2
                    resolved_end = end
                active_subpath.segments.append(
                    PathSegment(
                        kind="C",
                        end=resolved_end,
                        control1=resolved_c1,
                        control2=resolved_c2,
                    )
                )
                current_point = resolved_end
                previous_cubic_control = resolved_c2
                previous_quadratic_control = None
            continue

        if command in {"S", "s"}:
            groups, index = _read_smooth_cubic_sequence(tokens, index)
            if not groups:
                break
            for control2, end in groups:
                control1 = _reflect_control_point(previous_cubic_control, current_point)
                resolved_c2 = _resolve_point(command, current_point, control2)
                resolved_end = _resolve_point(command, current_point, end)
                active_subpath.segments.append(
                    PathSegment(
                        kind="C",
                        end=resolved_end,
                        control1=control1,
                        control2=resolved_c2,
                    )
                )
                current_point = resolved_end
                previous_cubic_control = resolved_c2
                previous_quadratic_control = None
            continue

        if command in {"Q", "q"}:
            groups, index = _read_quadratic_sequence(tokens, index)
            if not groups:
                break
            for quadratic_control, end in groups:
                resolved_q = _resolve_point(command, current_point, quadratic_control)
                resolved_end = _resolve_point(command, current_point, end)
                control1, control2 = _quadratic_to_cubic_controls(
                    current_point,
                    resolved_q,
                    resolved_end,
                )
                active_subpath.segments.append(
                    PathSegment(
                        kind="C",
                        end=resolved_end,
                        control1=control1,
                        control2=control2,
                    )
                )
                current_point = resolved_end
                previous_cubic_control = None
                previous_quadratic_control = resolved_q
            continue

        if command in {"T", "t"}:
            coords, index = _read_coordinate_sequence(tokens, index)
            if not coords:
                break
            for coord in coords:
                quadratic_control = _reflect_control_point(previous_quadratic_control, current_point)
                resolved_end = _resolve_point(command, current_point, coord)
                control1, control2 = _quadratic_to_cubic_controls(
                    current_point,
                    quadratic_control,
                    resolved_end,
                )
                active_subpath.segments.append(
                    PathSegment(
                        kind="C",
                        end=resolved_end,
                        control1=control1,
                        control2=control2,
                    )
                )
                current_point = resolved_end
                previous_cubic_control = None
                previous_quadratic_control = quadratic_control
            continue

        if command in {"A", "a"}:
            groups, index = _read_arc_sequence(tokens, index)
            if not groups:
                break
            for rx, ry, rotation, large_arc_flag, sweep_flag, end in groups:
                resolved_end = _resolve_point(command, current_point, end)
                arc_segments = _arc_to_cubic_segments(
                    current_point,
                    resolved_end,
                    rx,
                    ry,
                    rotation,
                    large_arc_flag,
                    sweep_flag,
                )
                if not arc_segments:
                    if resolved_end != current_point:
                        active_subpath.segments.append(PathSegment(kind="L", end=resolved_end))
                    current_point = resolved_end
                    previous_cubic_control = None
                    previous_quadratic_control = None
                    continue

                for control1, control2, cubic_end in arc_segments:
                    active_subpath.segments.append(
                        PathSegment(
                            kind="C",
                            end=cubic_end,
                            control1=control1,
                            control2=control2,
                        )
                    )
                    previous_cubic_control = control2
                    previous_quadratic_control = None
                    current_point = cubic_end
            continue

        index = _skip_to_next_command(tokens, index)

    return subpaths


def _is_command(token: str) -> bool:
    return len(token) == 1 and token.isalpha()


def _read_coordinate_sequence(tokens: list[str], index: int):
    coords: list[Point] = []
    while index + 1 < len(tokens) and not _is_command(tokens[index]) and not _is_command(tokens[index + 1]):
        coords.append((float(tokens[index]), float(tokens[index + 1])))
        index += 2
    return coords, index


def _read_number_sequence(tokens: list[str], index: int):
    values: list[float] = []
    while index < len(tokens) and not _is_command(tokens[index]):
        values.append(float(tokens[index]))
        index += 1
    return values, index


def _read_cubic_sequence(tokens: list[str], index: int):
    groups: list[tuple[Point, Point, Point]] = []
    while index + 5 < len(tokens) and all(not _is_command(tokens[index + offset]) for offset in range(6)):
        groups.append(
            (
                (float(tokens[index]), float(tokens[index + 1])),
                (float(tokens[index + 2]), float(tokens[index + 3])),
                (float(tokens[index + 4]), float(tokens[index + 5])),
            )
        )
        index += 6
    return groups, index


def _read_smooth_cubic_sequence(tokens: list[str], index: int):
    groups: list[tuple[Point, Point]] = []
    while index + 3 < len(tokens) and all(not _is_command(tokens[index + offset]) for offset in range(4)):
        groups.append(
            (
                (float(tokens[index]), float(tokens[index + 1])),
                (float(tokens[index + 2]), float(tokens[index + 3])),
            )
        )
        index += 4
    return groups, index


def _read_quadratic_sequence(tokens: list[str], index: int):
    groups: list[tuple[Point, Point]] = []
    while index + 3 < len(tokens) and all(not _is_command(tokens[index + offset]) for offset in range(4)):
        groups.append(
            (
                (float(tokens[index]), float(tokens[index + 1])),
                (float(tokens[index + 2]), float(tokens[index + 3])),
            )
        )
        index += 4
    return groups, index


def _read_arc_sequence(tokens: list[str], index: int):
    groups: list[tuple[float, float, float, int, int, Point]] = []
    while index + 6 < len(tokens) and all(not _is_command(tokens[index + offset]) for offset in range(7)):
        groups.append(
            (
                float(tokens[index]),
                float(tokens[index + 1]),
                float(tokens[index + 2]),
                int(float(tokens[index + 3])),
                int(float(tokens[index + 4])),
                (float(tokens[index + 5]), float(tokens[index + 6])),
            )
        )
        index += 7
    return groups, index


def _resolve_point(command: str, current_point: Point, coord: Point) -> Point:
    if command.islower():
        return (current_point[0] + coord[0], current_point[1] + coord[1])
    return coord


def _resolve_horizontal(command: str, current_point: Point, value: float) -> Point:
    return (current_point[0] + value, current_point[1]) if command.islower() else (value, current_point[1])


def _resolve_vertical(command: str, current_point: Point, value: float) -> Point:
    return (current_point[0], current_point[1] + value) if command.islower() else (current_point[0], value)


def _append_line(active_subpath: PathSubpath, command: str, current_point: Point, coord: Point) -> Point:
    next_point = _resolve_point(command, current_point, coord)
    active_subpath.segments.append(PathSegment(kind="L", end=next_point))
    return next_point


def _reflect_control_point(control_point: Point | None, anchor_point: Point) -> Point:
    if control_point is None:
        return anchor_point
    return (
        2 * anchor_point[0] - control_point[0],
        2 * anchor_point[1] - control_point[1],
    )


def _quadratic_to_cubic_controls(start: Point, control: Point, end: Point) -> tuple[Point, Point]:
    control1 = (
        start[0] + (2.0 / 3.0) * (control[0] - start[0]),
        start[1] + (2.0 / 3.0) * (control[1] - start[1]),
    )
    control2 = (
        end[0] + (2.0 / 3.0) * (control[0] - end[0]),
        end[1] + (2.0 / 3.0) * (control[1] - end[1]),
    )
    return control1, control2


def _arc_to_cubic_segments(
    start: Point,
    end: Point,
    rx: float,
    ry: float,
    rotation_degrees: float,
    large_arc_flag: int,
    sweep_flag: int,
) -> list[tuple[Point, Point, Point]]:
    rx = abs(rx)
    ry = abs(ry)
    if rx == 0 or ry == 0 or start == end:
        return []

    phi = math.radians(rotation_degrees % 360.0)
    cos_phi = math.cos(phi)
    sin_phi = math.sin(phi)

    dx2 = (start[0] - end[0]) / 2.0
    dy2 = (start[1] - end[1]) / 2.0
    x1p = cos_phi * dx2 + sin_phi * dy2
    y1p = -sin_phi * dx2 + cos_phi * dy2

    radius_scale = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
    if radius_scale > 1.0:
        scale = math.sqrt(radius_scale)
        rx *= scale
        ry *= scale

    rx_sq = rx * rx
    ry_sq = ry * ry
    x1p_sq = x1p * x1p
    y1p_sq = y1p * y1p

    denominator = rx_sq * y1p_sq + ry_sq * x1p_sq
    if denominator == 0:
        return []

    sign = -1.0 if large_arc_flag == sweep_flag else 1.0
    factor_sq = max(0.0, (rx_sq * ry_sq - rx_sq * y1p_sq - ry_sq * x1p_sq) / denominator)
    factor = sign * math.sqrt(factor_sq)
    cxp = factor * (rx * y1p / ry)
    cyp = factor * (-ry * x1p / rx)

    center_x = cos_phi * cxp - sin_phi * cyp + (start[0] + end[0]) / 2.0
    center_y = sin_phi * cxp + cos_phi * cyp + (start[1] + end[1]) / 2.0

    start_vector = ((x1p - cxp) / rx, (y1p - cyp) / ry)
    end_vector = ((-x1p - cxp) / rx, (-y1p - cyp) / ry)

    start_angle = _vector_angle((1.0, 0.0), start_vector)
    sweep_angle = _vector_angle(start_vector, end_vector)
    if not sweep_flag and sweep_angle > 0:
        sweep_angle -= 2.0 * math.pi
    elif sweep_flag and sweep_angle < 0:
        sweep_angle += 2.0 * math.pi

    segment_count = max(1, int(math.ceil(abs(sweep_angle) / (math.pi / 2.0))))
    angle_step = sweep_angle / segment_count
    segments: list[tuple[Point, Point, Point]] = []

    for segment_index in range(segment_count):
        angle_start = start_angle + segment_index * angle_step
        angle_end = angle_start + angle_step
        alpha = 4.0 / 3.0 * math.tan((angle_end - angle_start) / 4.0)

        p0 = (math.cos(angle_start), math.sin(angle_start))
        p1 = (p0[0] - alpha * p0[1], p0[1] + alpha * p0[0])
        p3 = (math.cos(angle_end), math.sin(angle_end))
        p2 = (p3[0] + alpha * p3[1], p3[1] - alpha * p3[0])

        control1 = _map_ellipse_point(p1, center_x, center_y, rx, ry, cos_phi, sin_phi)
        control2 = _map_ellipse_point(p2, center_x, center_y, rx, ry, cos_phi, sin_phi)
        cubic_end = _map_ellipse_point(p3, center_x, center_y, rx, ry, cos_phi, sin_phi)
        segments.append((control1, control2, cubic_end))

    if segments:
        control1, control2, _ = segments[-1]
        segments[-1] = (control1, control2, end)

    return segments


def _map_ellipse_point(
    point: Point,
    center_x: float,
    center_y: float,
    rx: float,
    ry: float,
    cos_phi: float,
    sin_phi: float,
) -> Point:
    x = center_x + cos_phi * rx * point[0] - sin_phi * ry * point[1]
    y = center_y + sin_phi * rx * point[0] + cos_phi * ry * point[1]
    return (x, y)


def _vector_angle(u: Point, v: Point) -> float:
    cross = u[0] * v[1] - u[1] * v[0]
    dot = u[0] * v[0] + u[1] * v[1]
    return math.atan2(cross, dot)


def _skip_to_next_command(tokens: list[str], index: int) -> int:
    while index < len(tokens) and not _is_command(tokens[index]):
        index += 1
    return index
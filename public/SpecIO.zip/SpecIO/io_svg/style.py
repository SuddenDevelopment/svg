"""Pure SVG style helpers."""

from __future__ import annotations

import math
import re
from typing import MutableMapping
from xml.etree.ElementTree import Element


STYLE_ATTRIBUTE_KEYS = (
    "display",
    "fill",
    "fill-rule",
    "stroke",
    "stroke-linecap",
    "stroke-linejoin",
    "stroke-width",
    "visibility",
)

STYLE_METADATA_PROPERTIES = {
    "fill": "specio_svg_fill",
    "fill-rule": "specio_svg_fill_rule",
    "stroke": "specio_svg_stroke",
    "stroke-linecap": "specio_svg_stroke_linecap",
    "stroke-linejoin": "specio_svg_stroke_linejoin",
    "stroke-width": "specio_svg_stroke_width",
}


CSS_COLOR_KEYWORDS = {
    "black": (0.0, 0.0, 0.0, 1.0),
    "blue": (0.0, 0.0, 1.0, 1.0),
    "cyan": (0.0, 1.0, 1.0, 1.0),
    "gray": (0.502, 0.502, 0.502, 1.0),
    "green": (0.0, 0.502, 0.0, 1.0),
    "grey": (0.502, 0.502, 0.502, 1.0),
    "magenta": (1.0, 0.0, 1.0, 1.0),
    "navy": (0.0, 0.0, 0.502, 1.0),
    "orange": (1.0, 0.647, 0.0, 1.0),
    "purple": (0.502, 0.0, 0.502, 1.0),
    "red": (1.0, 0.0, 0.0, 1.0),
    "white": (1.0, 1.0, 1.0, 1.0),
    "yellow": (1.0, 1.0, 0.0, 1.0),
}

NUMERIC_STYLE_PATTERN = re.compile(r"^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?")
RGB_COLOR_PATTERN = re.compile(r"^(rgba?)\((.*)\)$", re.IGNORECASE)


def normalize_style_value(key: str, value: str) -> str:
    """Normalize supported SVG style values while preserving non-keyword values."""
    normalized = value.strip()
    lowered = normalized.lower()
    if key in {"fill", "stroke"} and lowered == "none":
        return "none"
    if key == "fill-rule" and lowered in {"evenodd", "nonzero"}:
        return lowered
    if key == "stroke-linecap" and lowered in {"butt", "round", "square"}:
        return lowered
    if key == "stroke-linejoin" and lowered in {"miter", "round", "bevel"}:
        return lowered
    if key == "display" and lowered == "none":
        return "none"
    if key == "visibility" and lowered in {"hidden", "collapse", "visible"}:
        return lowered
    return normalized


def parse_style_attribute(style_text: str) -> dict[str, str]:
    """Parse an inline SVG style attribute into a key-value mapping."""
    parsed: dict[str, str] = {}
    for chunk in style_text.split(";"):
        if ":" not in chunk:
            continue
        key, value = chunk.split(":", 1)
        normalized_key = key.strip()
        normalized_value = normalize_style_value(normalized_key, value)
        if normalized_key and normalized_value:
            parsed[normalized_key] = normalized_value
    return parsed


_CSS_COMMENT_PATTERN = re.compile(r"/\*.*?\*/", re.DOTALL)
_CSS_RULE_PATTERN = re.compile(r"([^{}]+)\{([^{}]*)\}")


class CSSRules:
    """Parsed CSS rules from ``<style>`` blocks, grouped by selector type."""

    __slots__ = ("by_element", "by_class", "by_id")

    def __init__(self) -> None:
        self.by_element: dict[str, dict[str, str]] = {}
        self.by_class: dict[str, dict[str, str]] = {}
        self.by_id: dict[str, dict[str, str]] = {}

    def __bool__(self) -> bool:
        return bool(self.by_element or self.by_class or self.by_id)


def parse_css_style_block(text: str) -> CSSRules:
    """Parse a CSS ``<style>`` block into rules grouped by selector type.

    Supports element-type selectors (``path``), class selectors (``.cls-1``),
    and ID selectors (``#myid``).  Compound and pseudo selectors are ignored.
    """
    rules = CSSRules()
    cleaned = _CSS_COMMENT_PATTERN.sub("", text)
    for match in _CSS_RULE_PATTERN.finditer(cleaned):
        selectors_text = match.group(1)
        properties = parse_style_attribute(match.group(2))
        if not properties:
            continue
        for selector in selectors_text.split(","):
            selector = selector.strip()
            if not selector:
                continue
            if selector.startswith("."):
                name = selector[1:]
                rules.by_class.setdefault(name, {}).update(properties)
            elif selector.startswith("#"):
                name = selector[1:]
                rules.by_id.setdefault(name, {}).update(properties)
            elif selector.isidentifier():
                rules.by_element.setdefault(selector, {}).update(properties)
    return rules


def _local_tag(tag: str) -> str:
    """Return the local name of an XML tag, stripping any namespace."""
    return tag.split("}", 1)[1] if "}" in tag else tag


def _resolve_css_styles(
    element: Element,
    css_rules: CSSRules | None,
) -> dict[str, str]:
    """Resolve all CSS ``<style>`` rules that apply to *element*.

    Rules are applied in specificity order so higher-specificity selectors
    overwrite lower ones:

    1. Element-type selectors  (specificity 0-0-1)
    2. Class selectors          (specificity 0-1-0)
    3. ID selectors             (specificity 1-0-0)
    """
    if not css_rules:
        return {}
    merged: dict[str, str] = {}

    # Element-type selectors (lowest CSS specificity)
    tag = _local_tag(element.tag)
    elem_props = css_rules.by_element.get(tag)
    if elem_props:
        merged.update(elem_props)

    # Class selectors
    class_attr = element.get("class", "").strip()
    if class_attr:
        for class_name in class_attr.split():
            class_props = css_rules.by_class.get(class_name)
            if class_props:
                merged.update(class_props)

    # ID selectors (highest CSS specificity)
    id_attr = element.get("id", "").strip()
    if id_attr:
        id_props = css_rules.by_id.get(id_attr)
        if id_props:
            merged.update(id_props)

    return merged


def extract_style_attributes(
    element: Element,
    css_rules: CSSRules | None = None,
) -> dict[str, str]:
    """Extract supported style attributes from an SVG element.

    Resolution order follows the CSS cascade (last wins):

    1. Presentation attributes  (specificity 0, lowest)
    2. CSS ``<style>`` rules     (element / class / id specificity)
    3. Inline ``style`` attribute (highest priority)
    """
    style: dict[str, str] = {}

    # 1. Presentation attributes (lowest priority)
    for key in STYLE_ATTRIBUTE_KEYS:
        value = element.get(key)
        if value:
            style[key] = normalize_style_value(key, value)

    # 2. CSS rules from <style> blocks
    css_styles = _resolve_css_styles(element, css_rules)
    style.update(css_styles)

    # 3. Inline style attribute (highest priority)
    inline = parse_style_attribute(element.get("style", ""))
    style.update(inline)

    return style


def merge_style_attributes(parent: dict[str, str] | None, current: dict[str, str] | None) -> dict[str, str]:
    """Merge parent and current SVG style mappings with current taking precedence."""
    merged: dict[str, str] = {}
    if parent:
        merged.update(parent)
    if current:
        merged.update(current)
    return merged


def is_hidden_style(style: dict[str, str] | None) -> bool:
    """Return True when the supported SVG style indicates the element is hidden."""
    if not style:
        return False

    display = style.get("display", "").strip().lower()
    visibility = style.get("visibility", "").strip().lower()
    return display == "none" or visibility in {"hidden", "collapse"}


def export_style_attributes(style: dict[str, str] | None) -> dict[str, str]:
    """Return exportable presentation attributes in deterministic key order."""
    if not style:
        return {}

    exported: dict[str, str] = {}
    for key in ("fill", "fill-rule", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin"):
        value = style.get(key)
        if value:
            exported[key] = value
    return exported


def parse_numeric_style_value(value: str | None) -> float | None:
    """Extract a finite numeric value from a style token such as 2.5 or 2.5px."""
    if not value:
        return None

    match = NUMERIC_STYLE_PATTERN.match(value.strip())
    if not match:
        return None

    try:
        number = float(match.group(0))
    except ValueError:
        return None

    return number if math.isfinite(number) else None


def parse_color_value(value: str | None) -> tuple[float, float, float, float] | None:
    """Convert a supported SVG color token into an RGBA tuple in the 0..1 range."""
    if not value:
        return None

    normalized = value.strip().lower()
    if not normalized or normalized == "none":
        return None

    if normalized.startswith("url("):
        close_index = normalized.find(")")
        if close_index != -1:
            fallback = normalized[close_index + 1 :].strip()
            return parse_color_value(fallback) if fallback else None

    keyword = CSS_COLOR_KEYWORDS.get(normalized)
    if keyword:
        return keyword

    if normalized.startswith("#"):
        hex_value = normalized[1:]
        if len(hex_value) in {3, 4}:
            hex_value = "".join(component * 2 for component in hex_value)
        if len(hex_value) == 6:
            hex_value = f"{hex_value}ff"
        if len(hex_value) != 8:
            return None
        try:
            return tuple(int(hex_value[index:index + 2], 16) / 255.0 for index in range(0, 8, 2))
        except ValueError:
            return None

    rgb_match = RGB_COLOR_PATTERN.match(normalized)
    if not rgb_match:
        return None

    function_name, component_text = rgb_match.groups()
    components = [component.strip() for component in component_text.split(",")]
    expected_components = 4 if function_name.lower() == "rgba" else 3
    if len(components) != expected_components:
        return None

    rgba: list[float] = []
    for index, component in enumerate(components):
        parsed_component = _parse_color_component(component, is_alpha=index == 3)
        if parsed_component is None:
            return None
        rgba.append(parsed_component)

    if len(rgba) == 3:
        rgba.append(1.0)

    return tuple(rgba)


def resolve_display_color(style: dict[str, str] | None) -> tuple[float, float, float, float] | None:
    """Return the most useful display color for an imported SVG element."""
    if not style:
        return None

    stroke_value = style.get("stroke")
    if stroke_value and stroke_value.strip().lower() != "none":
        return parse_color_value(stroke_value)

    fill_value = style.get("fill")
    if fill_value is None or fill_value.strip().lower() != "none":
        return parse_color_value(fill_value)

    return None


def apply_curve_style_settings(
    curve_data,
    obj,
    style: dict[str, str] | None,
    scale: float = 1.0,
) -> None:
    """Apply practical SVG paint semantics to imported curve display settings."""
    if not style or curve_data is None:
        return

    stroke_width = resolve_stroke_width(style)
    stroke_enabled = stroke_width is not None
    fill_enabled = is_fill_enabled(style)

    if hasattr(curve_data, "dimensions"):
        curve_data.dimensions = "2D" if fill_enabled else "3D"

    if fill_enabled:
        _set_curve_fill_mode(curve_data)

    if hasattr(curve_data, "bevel_mode"):
        curve_data.bevel_mode = "ROUND"

    if hasattr(curve_data, "bevel_depth"):
        bevel_depth = 0.0
        if stroke_enabled and stroke_width > 0:
            bevel_depth = stroke_width * max(scale, 0.0) / 2.0
        curve_data.bevel_depth = bevel_depth

    linecap = style.get("stroke-linecap", "").strip().lower()
    if hasattr(curve_data, "use_fill_caps"):
        curve_data.use_fill_caps = linecap in {"butt", "square"}

    linejoin = style.get("stroke-linejoin", "").strip().lower()
    if hasattr(curve_data, "bevel_resolution"):
        if linejoin == "round":
            curve_data.bevel_resolution = max(1, int(getattr(curve_data, "bevel_resolution", 0)))
        elif linejoin in {"bevel", "miter"}:
            curve_data.bevel_resolution = 0

    display_color = resolve_display_color(style)
    if display_color and obj is not None and hasattr(obj, "color"):
        obj.color = display_color


def is_fill_enabled(style: dict[str, str] | None) -> bool:
    """Return True when SVG fill semantics indicate the curve should be filled."""
    if not style:
        return True

    fill_value = style.get("fill")
    return fill_value is None or fill_value.strip().lower() != "none"


def resolve_stroke_width(style: dict[str, str] | None) -> float | None:
    """Return the effective stroke width for a visible SVG stroke, defaulting to 1 when omitted."""
    if not style:
        return None

    stroke_value = style.get("stroke")
    if not stroke_value or stroke_value.strip().lower() == "none":
        return None

    stroke_width_value = style.get("stroke-width")
    if stroke_width_value is None or not stroke_width_value.strip():
        return 1.0

    stroke_width = parse_numeric_style_value(stroke_width_value)
    if stroke_width is None or stroke_width <= 0:
        return None
    return stroke_width


def is_stroke_enabled(style: dict[str, str] | None) -> bool:
    """Return True when SVG stroke semantics indicate the curve should render a stroke."""
    return resolve_stroke_width(style) is not None


def _set_curve_fill_mode(curve_data) -> None:
    """Set the filled curve mode using the enum supported by the active Blender build."""
    if not hasattr(curve_data, "fill_mode"):
        return

    for fill_mode in ("BOTH", "FULL"):
        try:
            curve_data.fill_mode = fill_mode
            return
        except (TypeError, ValueError):
            continue


def apply_style_metadata(target: MutableMapping[str, str], style: dict[str, str] | None) -> None:
    """Persist supported SVG style attributes onto a mapping-like target."""
    if not style:
        return

    for style_key, property_name in STYLE_METADATA_PROPERTIES.items():
        value = style.get(style_key)
        if value:
            target[property_name] = value


def extract_style_metadata(source) -> dict[str, str]:
    """Read persisted SVG style metadata from a mapping-like source."""
    style: dict[str, str] = {}
    for style_key, property_name in STYLE_METADATA_PROPERTIES.items():
        value = source.get(property_name)
        if isinstance(value, str) and value.strip():
            style[style_key] = value.strip()
    return style


def _parse_color_component(component: str, is_alpha: bool) -> float | None:
    """Parse a single rgb or alpha component into the 0..1 range."""
    if component.endswith("%"):
        number = parse_numeric_style_value(component[:-1])
        if number is None:
            return None
        if is_alpha:
            return max(0.0, min(number / 100.0, 1.0))
        return max(0.0, min(number / 100.0, 1.0))

    number = parse_numeric_style_value(component)
    if number is None:
        return None

    if is_alpha:
        return max(0.0, min(number, 1.0))

    return max(0.0, min(number / 255.0, 1.0))
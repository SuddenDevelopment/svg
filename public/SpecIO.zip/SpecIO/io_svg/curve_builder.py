"""Blender curve construction helpers for supported SVG elements."""

from __future__ import annotations

import math
import re

import bpy

from .path_parser import parse_svg_path, recommended_curve_resolution
from .style import _set_curve_fill_mode
from .transform import IDENTITY_TRANSFORM, apply_transform


class SVGCurveBuilder:
    """Create Blender curve objects for supported SVG element types."""

    def __init__(self, scale: float = 1.0):
        self.scale = scale

    def create_curve_from_element(
        self,
        element,
        element_id: str,
        context: bpy.types.Context,
        transform=IDENTITY_TRANSFORM,
    ):
        """Create a Blender curve object from a supported SVG element."""
        tag = element.tag.split("}", 1)[-1] if "}" in element.tag else element.tag
        spline_builder = self._spline_builder_for_tag(tag)
        if spline_builder is None:
            return None

        curve_data = bpy.data.curves.new(element_id, type="CURVE")
        curve_data.dimensions = "2D"
        _set_curve_fill_mode(curve_data)
        curve_obj = bpy.data.objects.new(element_id, curve_data)
        context.scene.collection.objects.link(curve_obj)

        spline_builder(curve_data, element, transform)
        if not curve_data.splines:
            bpy.data.objects.remove(curve_obj, do_unlink=True)
            bpy.data.curves.remove(curve_data, do_unlink=True)
            return None

        return curve_obj

    def _spline_builder_for_tag(self, tag: str):
        """Return the spline-construction helper for a supported SVG element tag."""
        builders = {
            "rect": self._create_rect_spline,
            "circle": self._create_circle_spline,
            "ellipse": self._create_ellipse_spline,
            "line": self._create_line_spline,
            "path": self._create_path_spline,
            "polyline": lambda curve_data, element, transform: self._create_poly_points_spline(curve_data, element, transform, is_closed=False),
            "polygon": lambda curve_data, element, transform: self._create_poly_points_spline(curve_data, element, transform, is_closed=True),
        }
        return builders.get(tag)

    def _create_rect_spline(self, curve_data: bpy.types.Curve, element, transform=IDENTITY_TRANSFORM) -> None:
        """Create a closed poly spline for an SVG rect element."""
        try:
            x = float(element.get("x", 0))
            y = float(element.get("y", 0))
            width = float(element.get("width", 0))
            height = float(element.get("height", 0))
            radius_x = float(element.get("rx", 0) or 0)
            radius_y = float(element.get("ry", 0) or 0)
        except (TypeError, ValueError):
            return

        if width <= 0 or height <= 0:
            return

        if radius_x > 0 or radius_y > 0:
            self._create_rounded_rect_spline(curve_data, x, y, width, height, radius_x, radius_y, transform)
            return

        spline = curve_data.splines.new("POLY")
        spline.points.add(3)
        points = [
            self._poly_point((x, y), transform),
            self._poly_point((x + width, y), transform),
            self._poly_point((x + width, y + height), transform),
            self._poly_point((x, y + height), transform),
        ]

        for index, point in enumerate(points):
            spline.points[index].co = point

        spline.use_cyclic_u = True

    def _create_circle_spline(self, curve_data: bpy.types.Curve, element, transform=IDENTITY_TRANSFORM) -> None:
        """Create a bezier spline approximating an SVG circle."""
        try:
            cx = float(element.get("cx", 0))
            cy = float(element.get("cy", 0))
            radius = float(element.get("r", 0))
        except (TypeError, ValueError):
            return

        if radius <= 0:
            return

        self._create_ellipse_bezier_spline(curve_data, cx, cy, radius, radius, transform)

    def _create_ellipse_spline(self, curve_data: bpy.types.Curve, element, transform=IDENTITY_TRANSFORM) -> None:
        """Create a bezier spline approximating an SVG ellipse."""
        try:
            cx = float(element.get("cx", 0))
            cy = float(element.get("cy", 0))
            radius_x = float(element.get("rx", 0))
            radius_y = float(element.get("ry", 0))
        except (TypeError, ValueError):
            return

        if radius_x <= 0 or radius_y <= 0:
            return

        self._create_ellipse_bezier_spline(curve_data, cx, cy, radius_x, radius_y, transform)

    def _create_ellipse_bezier_spline(
        self,
        curve_data: bpy.types.Curve,
        center_x: float,
        center_y: float,
        radius_x: float,
        radius_y: float,
        transform=IDENTITY_TRANSFORM,
    ) -> None:
        """Create a bezier spline approximating an axis-aligned ellipse."""
        spline = curve_data.splines.new("BEZIER")
        spline.bezier_points.add(3)
        handle_x = radius_x * 4 / 3 * math.tan(math.pi / 8)
        handle_y = radius_y * 4 / 3 * math.tan(math.pi / 8)
        self._apply_transformed_ellipse_points(spline, center_x, center_y, radius_x, radius_y, handle_x, handle_y, transform)

        spline.use_cyclic_u = True

    def _apply_transformed_ellipse_points(
        self,
        spline,
        center_x: float,
        center_y: float,
        radius_x: float,
        radius_y: float,
        handle_x: float,
        handle_y: float,
        transform,
    ) -> None:
        """Assign transformed bezier control data for an ellipse or circle spline."""
        points = [
            ((center_x + radius_x, center_y), (center_x + radius_x, center_y - handle_y), (center_x + radius_x, center_y + handle_y)),
            ((center_x, center_y + radius_y), (center_x + handle_x, center_y + radius_y), (center_x - handle_x, center_y + radius_y)),
            ((center_x - radius_x, center_y), (center_x - radius_x, center_y + handle_y), (center_x - radius_x, center_y - handle_y)),
            ((center_x, center_y - radius_y), (center_x - handle_x, center_y - radius_y), (center_x + handle_x, center_y - radius_y)),
        ]

        for index, (point, handle_left, handle_right) in enumerate(points):
            bezier_point = spline.bezier_points[index]
            bezier_point.co = self._bezier_point(point, transform)
            bezier_point.handle_left = self._bezier_point(handle_left, transform)
            bezier_point.handle_right = self._bezier_point(handle_right, transform)

    def _create_path_spline(self, curve_data: bpy.types.Curve, element, transform=IDENTITY_TRANSFORM) -> None:
        """Create curve splines for supported SVG path data."""
        path_data = element.get("d", "")
        if not path_data.strip():
            return

        subpaths = parse_svg_path(path_data)
        if not subpaths:
            return

        self._set_curve_resolution(curve_data, recommended_curve_resolution(subpaths))

        for subpath in subpaths:
            if not subpath.segments:
                continue
            if any(segment.kind == "C" for segment in subpath.segments):
                self._create_bezier_path_spline(curve_data, subpath, transform)
            else:
                self._create_poly_path_spline(curve_data, subpath, transform)

    def _create_line_spline(self, curve_data: bpy.types.Curve, element, transform=IDENTITY_TRANSFORM) -> None:
        """Create a poly spline for an SVG line element."""
        try:
            x1 = float(element.get("x1", 0))
            y1 = float(element.get("y1", 0))
            x2 = float(element.get("x2", 0))
            y2 = float(element.get("y2", 0))
        except (TypeError, ValueError):
            return

        if x1 == x2 and y1 == y2:
            return

        spline = curve_data.splines.new("POLY")
        spline.points.add(1)
        spline.points[0].co = self._poly_point((x1, y1), transform)
        spline.points[1].co = self._poly_point((x2, y2), transform)

    def _create_poly_points_spline(
        self,
        curve_data: bpy.types.Curve,
        element,
        transform,
        is_closed: bool,
    ) -> None:
        """Create a poly spline from an SVG polyline or polygon element."""
        points = self._extract_coordinates(element.get("points", ""))
        if len(points) < 2:
            return

        spline = curve_data.splines.new("POLY")
        spline.points.add(len(points) - 1)
        for index, (x, y) in enumerate(points):
            spline.points[index].co = self._poly_point((x, y), transform)

        spline.use_cyclic_u = is_closed

    def _create_poly_path_spline(self, curve_data: bpy.types.Curve, subpath, transform=IDENTITY_TRANSFORM) -> None:
        """Create a poly spline from a parsed line-only path subpath."""
        points = [subpath.start] + [segment.end for segment in subpath.segments]
        if len(points) < 2:
            return

        spline = curve_data.splines.new("POLY")
        spline.points.add(len(points) - 1)
        for index, (x, y) in enumerate(points):
            spline.points[index].co = self._poly_point((x, y), transform)

        spline.use_cyclic_u = subpath.closed

    def _create_bezier_path_spline(self, curve_data: bpy.types.Curve, subpath, transform=IDENTITY_TRANSFORM) -> None:
        """Create a bezier spline from a parsed path subpath."""
        node_points = [subpath.start] + [segment.end for segment in subpath.segments]
        if len(node_points) < 2:
            return

        spline = curve_data.splines.new("BEZIER")
        spline.bezier_points.add(len(node_points) - 1)

        left_handles = [point for point in node_points]
        right_handles = [point for point in node_points]

        for index, segment in enumerate(subpath.segments):
            start = node_points[index]
            end = node_points[index + 1]
            if segment.kind == "C" and segment.control1 and segment.control2:
                right_handles[index] = segment.control1
                left_handles[index + 1] = segment.control2
            else:
                control1, control2 = self._line_controls(start, end)
                right_handles[index] = control1
                left_handles[index + 1] = control2

        if subpath.closed:
            control1, control2 = self._line_controls(node_points[-1], node_points[0])
            right_handles[-1] = control1
            left_handles[0] = control2
            spline.use_cyclic_u = True

        for index, point in enumerate(node_points):
            bezier_point = spline.bezier_points[index]
            x, y = point
            left_x, left_y = left_handles[index]
            right_x, right_y = right_handles[index]
            bezier_point.co = self._bezier_point((x, y), transform)
            bezier_point.handle_left_type = "FREE"
            bezier_point.handle_right_type = "FREE"
            bezier_point.handle_left = self._bezier_point((left_x, left_y), transform)
            bezier_point.handle_right = self._bezier_point((right_x, right_y), transform)

    def _create_rounded_rect_spline(
        self,
        curve_data: bpy.types.Curve,
        x: float,
        y: float,
        width: float,
        height: float,
        radius_x: float,
        radius_y: float,
        transform,
    ) -> None:
        """Create a bezier spline for a rounded SVG rect element."""
        if radius_x <= 0 and radius_y > 0:
            radius_x = radius_y
        elif radius_y <= 0 and radius_x > 0:
            radius_y = radius_x

        radius_x = max(0.0, min(radius_x, width / 2.0))
        radius_y = max(0.0, min(radius_y, height / 2.0))
        if radius_x == 0.0 or radius_y == 0.0:
            self._create_rect_spline(curve_data, {"x": x, "y": y, "width": width, "height": height}, transform)
            return

        spline = curve_data.splines.new("BEZIER")
        spline.bezier_points.add(7)
        handle_scale = 4.0 / 3.0 * math.tan(math.pi / 8.0)
        handle_x = radius_x * handle_scale
        handle_y = radius_y * handle_scale

        points = [
            (x + radius_x, y),
            (x + width - radius_x, y),
            (x + width, y + radius_y),
            (x + width, y + height - radius_y),
            (x + width - radius_x, y + height),
            (x + radius_x, y + height),
            (x, y + height - radius_y),
            (x, y + radius_y),
        ]

        left_handles = [None] * len(points)
        right_handles = [None] * len(points)

        right_handles[0], left_handles[1] = self._line_controls(points[0], points[1])
        right_handles[1] = (points[1][0] + handle_x, points[1][1])
        left_handles[2] = (points[2][0], points[2][1] - handle_y)
        right_handles[2], left_handles[3] = self._line_controls(points[2], points[3])
        right_handles[3] = (points[3][0], points[3][1] + handle_y)
        left_handles[4] = (points[4][0] + handle_x, points[4][1])
        right_handles[4], left_handles[5] = self._line_controls(points[4], points[5])
        right_handles[5] = (points[5][0] - handle_x, points[5][1])
        left_handles[6] = (points[6][0], points[6][1] + handle_y)
        right_handles[6], left_handles[7] = self._line_controls(points[6], points[7])
        right_handles[7] = (points[7][0], points[7][1] - handle_y)
        left_handles[0] = (points[0][0] - handle_x, points[0][1])

        for index, point in enumerate(points):
            bezier_point = spline.bezier_points[index]
            bezier_point.co = self._bezier_point(point, transform)
            bezier_point.handle_left_type = "FREE"
            bezier_point.handle_right_type = "FREE"
            bezier_point.handle_left = self._bezier_point(left_handles[index], transform)
            bezier_point.handle_right = self._bezier_point(right_handles[index], transform)

        spline.use_cyclic_u = True

    def _poly_point(self, point: tuple[float, float], transform) -> tuple[float, float, float, float]:
        """Convert an SVG point into a transformed Blender poly point."""
        x, y = apply_transform(point, transform)
        return (x * self.scale, -y * self.scale, 0.0, 1.0)

    def _bezier_point(self, point: tuple[float, float], transform) -> tuple[float, float, float]:
        """Convert an SVG point into a transformed Blender bezier point."""
        x, y = apply_transform(point, transform)
        return (x * self.scale, -y * self.scale, 0.0)

    def _line_controls(self, start: tuple[float, float], end: tuple[float, float]):
        """Return cubic controls that represent a straight line."""
        dx = (end[0] - start[0]) / 3.0
        dy = (end[1] - start[1]) / 3.0
        control1 = (start[0] + dx, start[1] + dy)
        control2 = (start[0] + 2 * dx, start[1] + 2 * dy)
        return control1, control2

    def _set_curve_resolution(self, curve_data: bpy.types.Curve, resolution: int) -> None:
        """Apply a minimum viewport and render resolution to imported curves."""
        if hasattr(curve_data, "resolution_u"):
            curve_data.resolution_u = max(int(getattr(curve_data, "resolution_u", 0)), resolution)
        if hasattr(curve_data, "render_resolution_u"):
            curve_data.render_resolution_u = max(int(getattr(curve_data, "render_resolution_u", 0)), resolution)

    def _extract_coordinates(self, coords_str: str) -> list[tuple[float, float]]:
        """Extract coordinate pairs from an SVG coordinate string."""
        if not coords_str.strip():
            return []

        normalized = re.sub(r"[,\s]+", " ", coords_str.strip())
        try:
            numbers = [float(value) for value in normalized.split() if value]
        except ValueError:
            return []

        coords = []
        for index in range(0, len(numbers), 2):
            if index + 1 < len(numbers):
                coords.append((numbers[index], numbers[index + 1]))
        return coords
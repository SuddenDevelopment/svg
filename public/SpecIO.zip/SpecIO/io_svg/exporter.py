"""SVG export helpers for SpecIO."""

from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path
import tempfile

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

from .document import SVGImageElement, SVGPathElement, build_svg_document
from .formatting import format_number, format_xy
from .gradient_materials import material_gradient_payload
from .gradients import average_gradient_color, gradient_from_payload
from .image_util import (
    SPECIO_IMAGE_HREF_PROP,
    SPECIO_IMAGE_PROP,
    SPECIO_IMAGE_X_PROP,
    SPECIO_IMAGE_Y_PROP,
    SPECIO_IMAGE_W_PROP,
    SPECIO_IMAGE_H_PROP,
    encode_image_as_data_uri,
    is_image_plane,
)
from .style import export_style_attributes, extract_style_metadata


SVG_ORDER_PATH_PROP = "specio_svg_order_path"
SVG_GROUP_ID_PROP = "specio_svg_group_id"
SVG_SYNTHETIC_ROOT_PROP = "specio_svg_synthetic_root"
SVG_STROKE_HELPER_PROP = "specio_svg_stroke_helper"
MESH_COLOR_MODE_MATERIAL = "MATERIAL_HEURISTIC"
MESH_COLOR_MODE_CAMERA_SAMPLE = "CAMERA_SAMPLE"


def _parse_order_path(value) -> tuple[int, ...] | None:
    """Return a parsed SVG sibling order path stored on a Blender data block."""
    if not value:
        return None

    if isinstance(value, (list, tuple)):
        try:
            return tuple(int(part) for part in value)
        except (TypeError, ValueError):
            return None

    try:
        parts = [part for part in str(value).split(".") if part]
        return tuple(int(part) for part in parts) if parts else None
    except ValueError:
        return None


class SVGExporter:
    """Export Blender curve objects as SVG path data."""

    def __init__(
        self,
        scale: float = 1.0,
        precision: int = 3,
        image_mode: str = "EMBED",
        default_fill_color: tuple[float, float, float] = (0.5, 0.5, 0.5),
        default_stroke_color: tuple[float, float, float] = (0.0, 0.0, 0.0),
        apply_stroke: bool = False,
        stroke_width: float = 1.0,
        project_through_camera: bool = False,
        cull_to_camera: bool = True,
        mesh_color_mode: str = MESH_COLOR_MODE_MATERIAL,
    ):
        self.scale = scale
        self.precision = precision
        self.image_mode = image_mode
        self.default_fill_color = self._coerce_rgb(default_fill_color, (0.5, 0.5, 0.5))
        self.default_stroke_color = self._coerce_rgb(default_stroke_color, (0.0, 0.0, 0.0))
        self.apply_stroke = bool(apply_stroke)
        self.stroke_width = max(float(stroke_width), 0.001)
        self.project_through_camera = project_through_camera
        self.cull_to_camera = bool(cull_to_camera)
        self.mesh_color_mode = mesh_color_mode or MESH_COLOR_MODE_MATERIAL
        self._projection_scene: bpy.types.Scene | None = None
        self._projection_camera: bpy.types.Object | None = None
        self._projection_render_width = 0.0
        self._projection_render_height = 0.0
        self._camera_sample_resolution: tuple[int, int] | None = None
        self._camera_sample_pixels: list[float] | None = None

    def export_objects(
        self,
        filepath: str,
        objects: list[bpy.types.Object],
        scene: bpy.types.Scene | None = None,
    ):
        """Export supported objects to an SVG file."""
        path = Path(filepath)
        if path.suffix.lower() != ".svg":
            raise ValueError("Export path must use the .svg extension")
        try:
            curve_objects = [
                obj
                for obj in objects
                if obj.type == "CURVE"
                and obj.data
                and obj.data.splines
                and not self._is_synthetic_stroke_helper(obj)
            ]
            text_objects = [
                obj
                for obj in objects
                if obj.type == "FONT"
                and getattr(obj, "data", None) is not None
                and not self._is_synthetic_stroke_helper(obj)
            ]
            image_objects = [obj for obj in objects if is_image_plane(obj)]
            camera = scene.camera if scene else None
            if self.project_through_camera:
                if scene is None or camera is None:
                    raise ValueError("Active scene camera is required for camera-projected SVG export")
                self._configure_camera_projection(scene, camera)
            else:
                self._clear_camera_projection()

            mesh_objects = [
                obj
                for obj in objects
                if camera is not None and self._supports_camera_mesh_export(obj)
            ]
            if not curve_objects and not text_objects and not image_objects and not mesh_objects:
                if any(obj.type == "MESH" and not is_image_plane(obj) for obj in objects):
                    raise ValueError(
                        "Select at least one curve, text, or image object to export, or select mesh objects with an active scene camera for camera-view export"
                    )
                raise ValueError("Select at least one curve, text, or image object to export")

            collection_paths = self._build_collection_path_map(scene) if scene else {}
            curve_like_objects = sorted(
                [*curve_objects, *text_objects],
                key=lambda obj: self._object_sort_key(obj, collection_paths),
            )
            svg_paths: list[SVGPathElement] = []
            gradient_registry: dict[str, str] = {}
            gradient_ids_in_use: set[str] = set()
            gradient_definitions = []
            for obj in curve_like_objects:
                style_attributes = self._style_attributes_for_object(
                    obj,
                    gradient_registry,
                    gradient_ids_in_use,
                    gradient_definitions,
                )
                object_paths = self._export_curve_like_object_paths(
                    obj,
                    scene,
                    camera,
                    collection_paths,
                    style_attributes,
                )
                svg_paths.extend(object_paths)

            mesh_bundles_by_group: dict[tuple[str, ...], list[dict[str, object]]] = {}
            mesh_group_order: list[tuple[str, ...]] = []
            for obj in sorted(mesh_objects, key=lambda o: self._object_sort_key(o, collection_paths)):
                style_attributes = self._style_attributes_for_object(
                    obj,
                    gradient_registry,
                    gradient_ids_in_use,
                    gradient_definitions,
                )
                group_path = self._resolve_group_path(obj, collection_paths)
                mesh_bundle = self._build_mesh_export_bundle(
                    obj,
                    None,
                    scene,
                    camera,
                    group_path,
                    style_attributes,
                )
                if group_path not in mesh_bundles_by_group:
                    mesh_bundles_by_group[group_path] = []
                    mesh_group_order.append(group_path)
                mesh_bundles_by_group[group_path].append(mesh_bundle)

            for group_path in mesh_group_order:
                sorted_bundles = self._sort_mesh_bundles_by_visibility(mesh_bundles_by_group[group_path])
                for bundle in sorted_bundles:
                    entries = list(bundle["path_entries"])
                    entries.sort(key=lambda item: self._mesh_path_entry_sort_key(item))
                    svg_paths.extend(path for _, path in entries)

            svg_images: list[SVGImageElement] = []
            for obj in sorted(image_objects, key=lambda o: self._object_sort_key(o, collection_paths)):
                image_element = self._export_image_element(obj, collection_paths, filepath=path)
                if image_element is not None:
                    svg_images.append(image_element)

            svg = build_svg_document(svg_paths, self.precision, gradients=gradient_definitions, images=svg_images or None)

            path.parent.mkdir(parents=True, exist_ok=True)
            import xml.etree.ElementTree as ET

            ET.ElementTree(svg).write(path, encoding="utf-8", xml_declaration=True)
            return {"FINISHED"}
        finally:
            self._clear_camera_projection()
            self._clear_camera_color_sampling()

    def _configure_camera_projection(self, scene: bpy.types.Scene, camera: bpy.types.Object) -> None:
        """Cache scene camera projection state for 2D export projection."""
        resolution_scale = scene.render.resolution_percentage / 100.0
        self._projection_scene = scene
        self._projection_camera = camera
        self._projection_render_width = scene.render.resolution_x * resolution_scale
        self._projection_render_height = scene.render.resolution_y * resolution_scale

    def _clear_camera_projection(self) -> None:
        """Clear cached camera projection state."""
        self._projection_scene = None
        self._projection_camera = None
        self._projection_render_width = 0.0
        self._projection_render_height = 0.0

    def _clear_camera_color_sampling(self) -> None:
        """Clear cached render sampling buffers."""
        self._camera_sample_resolution = None
        self._camera_sample_pixels = None

    def _overlaps_viewport(self, bounds: tuple[float, float, float, float]) -> bool:
        """Return whether projected SVG bounds overlap the configured camera viewport."""
        if self._projection_render_width <= 0 or self._projection_render_height <= 0:
            return True
        vp_max_x = self._projection_render_width * self.scale
        vp_max_y = self._projection_render_height * self.scale
        min_x, min_y, max_x, max_y = bounds
        return max_x >= 0.0 and min_x <= vp_max_x and max_y >= 0.0 and min_y <= vp_max_y

    def _is_synthetic_stroke_helper(self, obj: bpy.types.Object) -> bool:
        """Return whether an object is an importer-created stroke helper duplicate."""
        return bool(obj.get(SVG_STROKE_HELPER_PROP))

    def _supports_camera_mesh_export(self, obj: bpy.types.Object) -> bool:
        """Return whether an object can be exported from the active camera view as mesh silhouettes."""
        return bool(
            obj.type == "MESH"
            and not is_image_plane(obj)
            and obj.data
            and getattr(obj.data, "polygons", None)
            and len(obj.data.polygons) > 0
        )

    # ------------------------------------------------------------------
    # Image export
    # ------------------------------------------------------------------

    def _export_image_element(
        self,
        obj: bpy.types.Object,
        collection_paths: dict,
        filepath: Path | None = None,
    ) -> SVGImageElement | None:
        """Build an SVGImageElement from a SpecIO image plane, or None on failure."""
        try:
            href = self._resolve_export_href(obj, filepath)
            if not href:
                return None

            if self.project_through_camera:
                bounds = self._project_object_bounds(obj)
                x, y, max_x, max_y = bounds
                width = max_x - x
                height = max_y - y
                if width <= 0 or height <= 0:
                    return None

                group_path = self._resolve_group_path(obj, collection_paths)
                return SVGImageElement(
                    element_id=obj.name,
                    href=href,
                    x=x,
                    y=y,
                    width=width,
                    height=height,
                    bounds=bounds,
                    group_path=group_path,
                )

            x = float(obj.get(SPECIO_IMAGE_X_PROP, 0))
            y = float(obj.get(SPECIO_IMAGE_Y_PROP, 0))
            w = float(obj.get(SPECIO_IMAGE_W_PROP, 0))
            h = float(obj.get(SPECIO_IMAGE_H_PROP, 0))
            if w <= 0 or h <= 0:
                return None

            bounds = (x, y, x + w, y + h)
            group_path = self._resolve_group_path(obj, collection_paths)
            return SVGImageElement(
                element_id=obj.name,
                href=href,
                x=x,
                y=y,
                width=w,
                height=h,
                bounds=bounds,
                group_path=group_path,
            )
        except Exception:
            return None

    def _resolve_export_href(self, obj: bpy.types.Object, filepath: Path | None) -> str | None:
        """Determine the href value for an exported image element."""
        original_href: str = obj.get(SPECIO_IMAGE_HREF_PROP, "") or ""

        if self.image_mode == "LINK" and original_href and not original_href.startswith("data:"):
            return original_href

        # Embed: read pixels from the Blender image and encode as data URI.
        blender_image = self._find_image_on_object(obj)
        if blender_image is None:
            # Fall back to the stored href if we cannot find the image data.
            return original_href or None

        image_bytes = self._image_to_bytes(blender_image)
        if image_bytes is None:
            return original_href or None

        # Determine extension from the image filepath or default to png.
        ext = Path(blender_image.filepath or ".png").suffix or ".png"
        return encode_image_as_data_uri(image_bytes, ext)

    @staticmethod
    def _find_image_on_object(obj: bpy.types.Object):
        """Return the first image texture from the object's material, if any."""
        if not obj.data or not getattr(obj.data, "materials", None):
            return None
        for mat in obj.data.materials:
            if mat is None or not mat.use_nodes:
                continue
            for node in mat.node_tree.nodes:
                if node.type == "TEX_IMAGE" and node.image:
                    return node.image
        return None

    @staticmethod
    def _image_to_bytes(blender_image) -> bytes | None:
        """Extract raw file bytes from a packed or file-backed Blender image."""
        if blender_image.packed_file and blender_image.packed_file.data:
            return bytes(blender_image.packed_file.data)

        fpath = blender_image.filepath_from_user()
        if fpath:
            p = Path(fpath)
            if p.is_file():
                try:
                    return p.read_bytes()
                except OSError:
                    pass
        return None

    def _export_object_paths(
        self,
        obj: bpy.types.Object,
        group_path: tuple[str, ...],
        style_attributes: dict[str, str],
    ):
        """Convert a curve object into one or more SVG path definitions."""
        return self._export_curve_data_paths(obj, obj.data, group_path, style_attributes)

    def _export_curve_like_object_paths(
        self,
        obj: bpy.types.Object,
        scene: bpy.types.Scene | None,
        camera: bpy.types.Object | None,
        collection_paths: dict[bpy.types.Collection, tuple[str, ...]],
        style_attributes: dict[str, str],
    ) -> list[SVGPathElement]:
        """Convert a curve or text object into one or more SVG path definitions."""
        group_path = self._resolve_group_path(obj, collection_paths)
        if obj.type == "CURVE":
            return self._export_curve_data_paths(obj, obj.data, group_path, style_attributes)
        if obj.type == "FONT":
            if scene is not None and camera is not None and self._text_object_uses_mesh_projection(obj):
                temp_mesh = self._mesh_data_from_text_object(obj)
                try:
                    return self._export_mesh_data_paths(obj, temp_mesh, scene, camera, group_path, style_attributes)
                finally:
                    obj.to_mesh_clear()

            temp_curve = self._curve_data_from_text_object(obj)
            try:
                return self._export_curve_data_paths(obj, temp_curve, group_path, style_attributes)
            finally:
                obj.to_curve_clear()
        raise ValueError(f"Object {obj.name} is not exportable as curve data")

    def _text_object_uses_mesh_projection(self, obj: bpy.types.Object) -> bool:
        """Return whether a text object should export via temporary mesh projection."""
        text_data = getattr(obj, "data", None)
        if text_data is None:
            return False
        extrude = float(getattr(text_data, "extrude", 0.0) or 0.0)
        bevel_depth = float(getattr(text_data, "bevel_depth", 0.0) or 0.0)
        return extrude > 0.0 or bevel_depth > 0.0

    def _curve_data_from_text_object(self, obj: bpy.types.Object):
        """Return temporary curve data generated from a text object for SVG export."""
        depsgraph = bpy.context.evaluated_depsgraph_get()
        curve_data = obj.to_curve(depsgraph, apply_modifiers=True)
        if curve_data is None:
            raise ValueError(f"Object {obj.name} could not be converted to curve data")
        return curve_data

    def _mesh_data_from_text_object(self, obj: bpy.types.Object):
        """Return temporary mesh data generated from a text object for SVG export."""
        depsgraph = bpy.context.evaluated_depsgraph_get()
        mesh_data = obj.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
        if mesh_data is None:
            raise ValueError(f"Object {obj.name} could not be converted to mesh data")
        return mesh_data

    def _project_point_to_svg(self, point) -> tuple[float, float]:
        """Project a world-space point through the configured scene camera."""
        if self._projection_scene is None or self._projection_camera is None:
            raise ValueError("Camera projection is not configured")
        camera_point = world_to_camera_view(self._projection_scene, self._projection_camera, point)
        return (
            float(camera_point.x * self._projection_render_width * self.scale),
            float((1.0 - camera_point.y) * self._projection_render_height * self.scale),
        )

    def _project_object_bounds(self, obj: bpy.types.Object) -> tuple[float, float, float, float]:
        """Project an object's bounding box to screen-space bounds."""
        points = [self._project_point_to_svg(obj.matrix_world @ Vector(corner)) for corner in obj.bound_box]
        return self._bounds(points)

    def _export_curve_data_paths(
        self,
        obj: bpy.types.Object,
        curve_data,
        group_path: tuple[str, ...],
        style_attributes: dict[str, str],
    ) -> list[SVGPathElement]:
        """Convert curve data bound to an object transform into SVG path definitions."""
        paths: list[SVGPathElement] = []
        splines = getattr(curve_data, "splines", None)
        if not splines:
            raise ValueError(f"Object {obj.name} has no exportable spline data")

        multiple_splines = len(splines) > 1
        any_spline_had_data = False

        for index, spline in enumerate(splines, start=1):
            if spline.type == "BEZIER":
                path_data, bounds = self._bezier_spline_to_path(obj, spline)
            else:
                path_data, bounds = self._poly_spline_to_path(obj, spline)

            if not path_data:
                continue

            any_spline_had_data = True

            if self.cull_to_camera and self.project_through_camera and not self._overlaps_viewport(bounds):
                continue

            path_id = obj.name if not multiple_splines else f"{obj.name}_{index:03d}"
            paths.append(
                SVGPathElement(
                    path_id=path_id,
                    path_data=path_data,
                    bounds=bounds,
                    group_path=group_path,
                    attributes=style_attributes.copy(),
                )
            )

        if not paths:
            if any_spline_had_data:
                # All splines are outside the camera viewport; silently skip this object.
                return []
            raise ValueError(f"Object {obj.name} has no exportable spline data")
        return paths

    def _export_mesh_object_paths(
        self,
        obj: bpy.types.Object,
        scene: bpy.types.Scene,
        camera: bpy.types.Object,
        group_path: tuple[str, ...],
        style_attributes: dict[str, str],
    ) -> list[SVGPathElement]:
        """Convert a mesh object's projected polygons into compound filled SVG path data."""
        return self._export_mesh_data_paths(obj, None, scene, camera, group_path, style_attributes)

    def _export_mesh_data_paths(
        self,
        obj: bpy.types.Object,
        mesh_data,
        scene: bpy.types.Scene,
        camera: bpy.types.Object,
        group_path: tuple[str, ...],
        style_attributes: dict[str, str],
    ) -> list[SVGPathElement]:
        """Convert mesh data into compound filled SVG path data via camera projection."""
        return [path for _, path in self._export_mesh_data_path_entries(obj, mesh_data, scene, camera, group_path, style_attributes)]

    def _export_mesh_data_path_entries(
        self,
        obj: bpy.types.Object,
        mesh_data,
        scene: bpy.types.Scene,
        camera: bpy.types.Object,
        group_path: tuple[str, ...],
        style_attributes: dict[str, str],
    ) -> list[tuple[tuple[float, float, float], SVGPathElement]]:
        """Convert mesh data into projected SVG paths plus depth sort keys."""
        return list(self._build_mesh_export_bundle(obj, mesh_data, scene, camera, group_path, style_attributes)["path_entries"])

    def _build_mesh_export_bundle(
        self,
        obj: bpy.types.Object,
        mesh_data,
        scene: bpy.types.Scene,
        camera: bpy.types.Object,
        group_path: tuple[str, ...],
        style_attributes: dict[str, str],
    ) -> dict[str, object]:
        """Build projected SVG paths and visibility metadata for a mesh object."""
        projected_faces = self._mesh_camera_projection_faces(obj, scene, camera, mesh_data=mesh_data)
        grouped_faces: dict[str, dict[str, object]] = {}
        for face in projected_faces:
            face_style_attributes = style_attributes.copy()
            face_style_attributes.update(face["style_attributes"])
            style_key = json.dumps(face_style_attributes, sort_keys=True, separators=(",", ":"))
            grouped_faces.setdefault(
                style_key,
                {
                    "style_attributes": face_style_attributes,
                    "loops": [],
                    "depths": [],
                },
            )["loops"].append(face["points"])
            grouped_faces[style_key]["depths"].append(float(face["depth"]))

        paths: list[tuple[tuple[float, float, float], SVGPathElement]] = []
        multiple_groups = len(grouped_faces) > 1
        for index, group in enumerate(grouped_faces.values(), start=1):
            path_data, bounds = self._compound_polygon_path(group["loops"])
            if not path_data:
                continue

            group_attributes = group["style_attributes"].copy()
            if len(group["loops"]) > 1:
                # Keep raw SVG rendering on the default nonzero rule while
                # carrying the mesh roundtrip hint for SpecIO re-import.
                group_attributes["data-specio-import-fill-rule"] = "evenodd"

            path_id = obj.name if not multiple_groups else f"{obj.name}_{index:03d}"
            depths = [float(depth) for depth in group["depths"]]
            paths.append(
                (
                    self._mesh_group_depth_sort_key(depths),
                    SVGPathElement(
                    path_id=path_id,
                    path_data=path_data,
                    bounds=bounds,
                    group_path=group_path,
                    attributes=group_attributes,
                    ),
                )
            )

        if not paths:
            raise ValueError(f"Object {obj.name} has no exportable projected mesh faces")
        return {
            "object_name": obj.name,
            "path_entries": paths,
            "projected_faces": projected_faces,
            "fallback_sort_key": min((entry[0] for entry in paths), default=(float("inf"), float("inf"), float("inf"))),
        }

    def _mesh_group_depth_sort_key(self, depths: list[float]) -> tuple[float, float, float]:
        """Return a stable far-to-near mesh paint-order key from projected face depths."""
        if not depths:
            return (float("-inf"), float("-inf"), float("-inf"))
        return (min(depths), sum(depths) / len(depths), max(depths))

    def _mesh_path_entry_sort_key(
        self,
        item: tuple[tuple[float, float, float], SVGPathElement],
    ) -> tuple[float, float, float, str]:
        """Return an SVG painter-order key that draws farther projected mesh paths first."""
        depth_key, path = item
        return (-depth_key[0], -depth_key[1], -depth_key[2], path.path_id)

    def _sort_mesh_bundles_by_visibility(self, bundles: list[dict[str, object]]) -> list[dict[str, object]]:
        """Order projected mesh objects by coarse front-most visibility in the active view."""
        if len(bundles) <= 1:
            return bundles

        front_wins, front_hits = self._mesh_visibility_front_scores(bundles)
        return sorted(
            bundles,
            key=lambda bundle: (
                front_wins.get(str(bundle["object_name"]), 0),
                front_hits.get(str(bundle["object_name"]), 0),
                *self._mesh_bundle_fallback_sort_key(bundle),
            ),
        )

    def _mesh_bundle_fallback_sort_key(self, bundle: dict[str, object]) -> tuple[float, float, float, str]:
        """Return the fallback painter-order key for a projected mesh bundle."""
        depth_key = tuple(bundle.get("fallback_sort_key") or (float("inf"), float("inf"), float("inf")))
        return (-float(depth_key[0]), -float(depth_key[1]), -float(depth_key[2]), str(bundle["object_name"]))

    def _mesh_visibility_front_scores(
        self,
        bundles: list[dict[str, object]],
    ) -> tuple[dict[str, int], dict[str, int]]:
        """Return coarse pairwise front-win and front-hit counts from projected face samples."""
        bounds = self._mesh_visibility_bounds(bundles)
        if bounds is None:
            return {}, {}

        grid_width, grid_height = self._mesh_visibility_grid_size(bounds)
        if grid_width <= 0 or grid_height <= 0:
            return {}, {}

        occupancy: dict[tuple[int, int], dict[str, float]] = defaultdict(dict)
        for bundle in bundles:
            object_name = str(bundle["object_name"])
            sample_bins = self._mesh_bundle_visibility_bins(bundle, bounds, grid_width, grid_height)
            for bin_key, depth in sample_bins.items():
                occupancy[bin_key][object_name] = depth

        front_wins: dict[str, int] = defaultdict(int)
        front_hits: dict[str, int] = defaultdict(int)
        for contenders in occupancy.values():
            if len(contenders) <= 1:
                continue

            ordered = sorted(contenders.items(), key=lambda item: (item[1], item[0]))
            front_name = ordered[0][0]
            front_hits[front_name] += 1
            for index, (near_name, near_depth) in enumerate(ordered[:-1]):
                for far_name, far_depth in ordered[index + 1:]:
                    if abs(near_depth - far_depth) <= 1e-5:
                        continue
                    front_wins[near_name] += 1
                    front_wins[far_name] -= 1

        return dict(front_wins), dict(front_hits)

    def _mesh_visibility_bounds(self, bundles: list[dict[str, object]]) -> tuple[float, float, float, float] | None:
        """Return the projected bounds for coarse visibility binning."""
        xs: list[float] = []
        ys: list[float] = []
        for bundle in bundles:
            for face in bundle.get("projected_faces", []):
                for point in face.get("points", []):
                    xs.append(float(point[0]))
                    ys.append(float(point[1]))
        if not xs or not ys:
            return None
        return (min(xs), min(ys), max(xs), max(ys))

    def _mesh_visibility_grid_size(self, bounds: tuple[float, float, float, float]) -> tuple[int, int]:
        """Return a bounded bin grid that tracks projected overlap without excessive cost."""
        width = max(bounds[2] - bounds[0], 1.0)
        height = max(bounds[3] - bounds[1], 1.0)
        max_dimension = 96
        if width >= height:
            return max_dimension, max(24, min(max_dimension, round(max_dimension * (height / width))))
        return max(24, min(max_dimension, round(max_dimension * (width / height)))), max_dimension

    def _mesh_bundle_visibility_bins(
        self,
        bundle: dict[str, object],
        bounds: tuple[float, float, float, float],
        grid_width: int,
        grid_height: int,
    ) -> dict[tuple[int, int], float]:
        """Return the nearest projected face depth per coarse screen bin for one mesh object."""
        min_x, min_y, max_x, max_y = bounds
        width = max(max_x - min_x, 1.0)
        height = max(max_y - min_y, 1.0)
        bins: dict[tuple[int, int], float] = {}
        for face in bundle.get("projected_faces", []):
            points = face.get("points", [])
            if not points:
                continue
            centroid_x = sum(float(point[0]) for point in points) / len(points)
            centroid_y = sum(float(point[1]) for point in points) / len(points)
            x_index = min(grid_width - 1, max(0, int(((centroid_x - min_x) / width) * grid_width)))
            y_index = min(grid_height - 1, max(0, int(((centroid_y - min_y) / height) * grid_height)))
            bin_key = (x_index, y_index)
            depth = float(face["depth"])
            previous = bins.get(bin_key)
            if previous is None or depth < previous:
                bins[bin_key] = depth
        return bins

    def _mesh_camera_projection_faces(
        self,
        obj: bpy.types.Object,
        scene: bpy.types.Scene,
        camera: bpy.types.Object,
        mesh_data=None,
    ) -> list[dict[str, object]]:
        """Return projected 2D polygons for mesh faces seen by the active camera."""
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        mesh = mesh_data if mesh_data is not None else evaluated.to_mesh()
        matrix_world = obj.matrix_world if mesh_data is not None else evaluated.matrix_world
        camera_matrix = camera.matrix_world.inverted()
        try:
            if mesh is None or not mesh.polygons:
                return []

            resolution_scale = scene.render.resolution_percentage / 100.0
            render_width = scene.render.resolution_x * resolution_scale
            render_height = scene.render.resolution_y * resolution_scale
            projected_faces: list[dict[str, object]] = []
            matrix_normal = matrix_world.to_3x3()
            use_camera_sample_mode = self._use_camera_sample_mode(obj, mesh_data)

            for polygon in mesh.polygons:
                points: list[tuple[float, float]] = []
                depths: list[float] = []
                world_points: list[Vector] = []
                for vertex_index in polygon.vertices:
                    world_point = matrix_world @ mesh.vertices[vertex_index].co
                    camera_point = world_to_camera_view(scene, camera, world_point)
                    camera_space_point = camera_matrix @ world_point
                    world_points.append(world_point)
                    points.append(
                        (
                            float(camera_point.x * render_width * self.scale),
                            float((1.0 - camera_point.y) * render_height * self.scale),
                        )
                    )
                    depths.append(float(-camera_space_point.z))

                if self.cull_to_camera:
                    face_min_x = min(p[0] for p in points)
                    face_max_x = max(p[0] for p in points)
                    face_min_y = min(p[1] for p in points)
                    face_max_y = max(p[1] for p in points)
                    vp_max_x = render_width * self.scale
                    vp_max_y = render_height * self.scale
                    if face_max_x < 0.0 or face_min_x > vp_max_x or face_max_y < 0.0 or face_min_y > vp_max_y:
                        continue

                points = self._normalize_polygon_winding(points)
                if len(points) < 3 or abs(self._signed_area(points)) <= 1e-6:
                    continue

                world_centroid = self._world_centroid(world_points)
                if use_camera_sample_mode:
                    world_normal = (matrix_normal @ polygon.normal).normalized()
                    face_radius = max((point - world_centroid).length for point in world_points)
                    if not self._mesh_face_is_camera_visible(scene, camera, obj, world_centroid, world_normal, face_radius):
                        continue
                    face_style_attributes = self._mesh_face_style_attributes(
                        obj,
                        polygon.material_index,
                        scene=scene,
                        camera=camera,
                        sample_points=points,
                    )
                else:
                    face_style_attributes = self._mesh_face_style_attributes(obj, polygon.material_index)

                projected_faces.append(
                    {
                        "points": points,
                        "depth": sum(depths) / len(depths),
                        "style_attributes": face_style_attributes,
                    }
                )

            projected_faces.sort(
                key=lambda face: (
                    face["depth"],
                    round(min(point[0] for point in face["points"]), 6),
                    round(min(point[1] for point in face["points"]), 6),
                    obj.name,
                )
            )
            return projected_faces
        finally:
            if mesh_data is None:
                evaluated.to_mesh_clear()

    def _polygon_points_to_path(self, points: list[tuple[float, float]]):
        """Convert a 2D polygon loop into an SVG path."""
        if len(points) < 3:
            return "", (0.0, 0.0, 0.0, 0.0)

        commands = [f"M {format_xy(points[0], self.precision)}"]
        commands.extend(f"L {format_xy(point, self.precision)}" for point in points[1:])
        commands.append("Z")
        return " ".join(commands), self._bounds(points)

    def _compound_polygon_path(self, loops: list[list[tuple[float, float]]]):
        """Convert multiple polygon loops into a single compound SVG path."""
        valid_loops = [self._normalize_polygon_winding(loop) for loop in loops if len(loop) >= 3]
        valid_loops = [loop for loop in valid_loops if abs(self._signed_area(loop)) > 1e-6]
        if not valid_loops:
            return "", (0.0, 0.0, 0.0, 0.0)

        commands: list[str] = []
        all_points: list[tuple[float, float]] = []
        for loop in valid_loops:
            commands.append(f"M {format_xy(loop[0], self.precision)}")
            commands.extend(f"L {format_xy(point, self.precision)}" for point in loop[1:])
            commands.append("Z")
            all_points.extend(loop)
        return " ".join(commands), self._bounds(all_points)

    def _signed_area(self, points: list[tuple[float, float]]) -> float:
        """Return the signed area of a closed 2D polygon loop."""
        area = 0.0
        for current, nxt in zip(points, points[1:] + points[:1]):
            area += current[0] * nxt[1] - nxt[0] * current[1]
        return area / 2.0

    def _normalize_polygon_winding(self, points: list[tuple[float, float]]) -> list[tuple[float, float]]:
        """Return a polygon loop with stable winding so compound fill does not self-cancel."""
        if self._signed_area(points) < 0:
            return list(reversed(points))
        return list(points)

    def _mesh_face_style_attributes(
        self,
        obj: bpy.types.Object,
        material_index: int,
        scene: bpy.types.Scene | None = None,
        camera: bpy.types.Object | None = None,
        sample_points: list[tuple[float, float]] | None = None,
    ) -> dict[str, str]:
        """Return SVG fill attributes for a projected mesh face based on its Blender material or camera sample."""
        rgba = None
        if self._use_camera_sample_mode(obj) and scene is not None and camera is not None and sample_points:
            rgba = self._sample_camera_face_rgba(scene, camera, sample_points)

        if rgba is None:
            rgba = self._material_color_for_slot(obj, material_index)
        if rgba is None:
            rgba = (*self.default_fill_color, 1.0)

        style_attributes = {"fill": self._rgba_to_svg_color(rgba)}
        if rgba[3] < 0.999:
            style_attributes["fill-opacity"] = self._format_scalar(rgba[3])
        return style_attributes

    def _use_camera_sample_mode(self, obj: bpy.types.Object, mesh_data=None) -> bool:
        """Return whether final camera color sampling should drive projected mesh face colors."""
        return bool(
            self.mesh_color_mode == MESH_COLOR_MODE_CAMERA_SAMPLE
            and self.project_through_camera
            and obj.type == "MESH"
            and mesh_data is None
        )

    def _mesh_face_is_camera_visible(
        self,
        scene: bpy.types.Scene,
        camera: bpy.types.Object,
        obj: bpy.types.Object,
        world_centroid: Vector,
        world_normal: Vector,
        face_radius: float,
    ) -> bool:
        """Return whether a mesh face is visible from the active camera at its centroid."""
        depsgraph = bpy.context.evaluated_depsgraph_get()
        ray_origin, ray_direction, ray_distance, view_direction = self._camera_visibility_ray(camera, world_centroid)
        if view_direction.dot(world_normal) <= 1e-5:
            return False

        hit, hit_location, _normal, _hit_polygon_index, hit_object, _matrix = scene.ray_cast(
            depsgraph,
            ray_origin,
            ray_direction,
            distance=ray_distance,
        )
        if not hit or hit_object is None:
            return False

        return hit_object.original == obj and (hit_location - world_centroid).length <= face_radius + 1e-4

    def _camera_visibility_ray(
        self,
        camera: bpy.types.Object,
        world_point: Vector,
    ) -> tuple[Vector, Vector, float, Vector]:
        """Return the world-space ray used to test camera visibility for one face centroid."""
        camera_forward = (camera.matrix_world.to_quaternion() @ Vector((0.0, 0.0, -1.0))).normalized()
        if getattr(camera.data, "type", "PERSP") == "ORTHO":
            offset = max(float(getattr(camera.data, "clip_end", 1000.0)), 1000.0)
            origin = world_point - camera_forward * offset
            direction = camera_forward
            distance = offset * 2.0
            view_direction = -camera_forward
            return origin, direction, distance, view_direction

        origin = camera.matrix_world.translation.copy()
        direction = (world_point - origin).normalized()
        distance = max((world_point - origin).length + 0.001, 0.001)
        view_direction = (origin - world_point).normalized()
        return origin, direction, distance, view_direction

    def _world_centroid(self, points: list[Vector]) -> Vector:
        """Return the centroid of a world-space point list."""
        centroid = Vector((0.0, 0.0, 0.0))
        for point in points:
            centroid += point
        return centroid / max(len(points), 1)

    def _sample_camera_face_rgba(
        self,
        scene: bpy.types.Scene,
        camera: bpy.types.Object,
        sample_points: list[tuple[float, float]],
    ) -> tuple[float, float, float, float] | None:
        """Sample the final shaded camera render color for a projected face."""
        if not self._ensure_camera_color_sampling(scene, camera):
            return None
        if self._camera_sample_resolution is None or not self._camera_sample_pixels:
            return None

        width, height = self._camera_sample_resolution
        sample_x = sum(point[0] for point in sample_points) / len(sample_points)
        sample_y = sum(point[1] for point in sample_points) / len(sample_points)
        pixel_x = int(round(sample_x / max(self.scale, 1e-8)))
        pixel_y_top = int(round(sample_y / max(self.scale, 1e-8)))
        pixel_x = max(0, min(width - 1, pixel_x))
        pixel_y_top = max(0, min(height - 1, pixel_y_top))
        pixel_y = height - 1 - pixel_y_top
        pixel_index = (pixel_y * width + pixel_x) * 4
        return self._clamp_rgba(self._camera_sample_pixels[pixel_index:pixel_index + 4])

    def _ensure_camera_color_sampling(self, scene: bpy.types.Scene, camera: bpy.types.Object) -> bool:
        """Render the active scene through Eevee and cache the final camera pixels for sampling."""
        if self._camera_sample_resolution is not None and self._camera_sample_pixels is not None:
            return True

        render_settings = scene.render
        original_engine = render_settings.engine
        original_filepath = render_settings.filepath
        original_file_format = render_settings.image_settings.file_format
        original_color_mode = render_settings.image_settings.color_mode
        eevee_engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys() else "BLENDER_EEVEE"
        temporary_path: Path | None = None
        try:
            render_settings.engine = eevee_engine
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as handle:
                temporary_path = Path(handle.name)
            render_settings.filepath = str(temporary_path)
            render_settings.image_settings.file_format = "PNG"
            render_settings.image_settings.color_mode = "RGBA"
            bpy.ops.render.render(write_still=True, use_viewport=False)

            rendered_image = bpy.data.images.load(str(temporary_path), check_existing=False)
            if rendered_image is None or len(rendered_image.size) < 2:
                return False

            try:
                width = int(rendered_image.size[0])
                height = int(rendered_image.size[1])
                if width <= 0 or height <= 0:
                    return False

                self._camera_sample_resolution = (width, height)
                self._camera_sample_pixels = list(rendered_image.pixels[:])
                return True
            finally:
                bpy.data.images.remove(rendered_image)
        except Exception:
            self._clear_camera_color_sampling()
            return False
        finally:
            render_settings.engine = original_engine
            render_settings.filepath = original_filepath
            render_settings.image_settings.file_format = original_file_format
            render_settings.image_settings.color_mode = original_color_mode
            if temporary_path is not None:
                try:
                    temporary_path.unlink(missing_ok=True)
                except OSError:
                    pass

    def _material_color_for_slot(self, obj: bpy.types.Object, material_index: int) -> tuple[float, float, float, float] | None:
        """Return the most useful RGBA color for a material slot."""
        materials = getattr(getattr(obj, "data", None), "materials", None)
        if not materials or material_index >= len(materials):
            return None

        material = materials[material_index]
        if material is None:
            return None

        gradient_payload = material_gradient_payload(material)
        if gradient_payload:
            try:
                return self._clamp_rgba(average_gradient_color(gradient_from_payload(gradient_payload)))
            except Exception:
                pass

        node_rgba = self._material_node_rgba(material)
        if node_rgba is not None:
            return node_rgba

        diffuse = getattr(material, "diffuse_color", None)
        if diffuse is None:
            return None
        return self._clamp_rgba(diffuse)

    def _material_node_rgba(self, material: bpy.types.Material) -> tuple[float, float, float, float] | None:
        """Resolve a representative RGBA from a node-based material output tree."""
        if not material.use_nodes or material.node_tree is None:
            return None

        output = self._active_material_output(material.node_tree)
        if output is not None:
            surface_input = output.inputs.get("Surface")
            rgba = self._resolve_shader_socket_rgba(surface_input, set())
            if rgba is not None:
                return rgba

        principled = next((node for node in material.node_tree.nodes if node.type == "BSDF_PRINCIPLED"), None)
        if principled is not None:
            return self._resolve_shader_node_rgba(principled, set())

        return None

    def _active_material_output(self, node_tree):
        """Return the active material output node when present."""
        outputs = [node for node in node_tree.nodes if node.type == "OUTPUT_MATERIAL"]
        if not outputs:
            return None

        active = next((node for node in outputs if getattr(node, "is_active_output", False)), None)
        return active or outputs[0]

    def _resolve_shader_socket_rgba(self, socket, visited: set[tuple[int, str]]) -> tuple[float, float, float, float] | None:
        """Resolve an RGBA value from a shader input socket."""
        if socket is None:
            return None
        if getattr(socket, "is_linked", False) and socket.links:
            return self._resolve_socket_rgba(socket.links[0].from_socket, visited)
        return None

    def _resolve_socket_rgba(self, socket, visited: set[tuple[int, str]]) -> tuple[float, float, float, float] | None:
        """Resolve an RGBA value from a linked node socket."""
        if socket is None:
            return None

        token = (id(socket.node), getattr(socket, "identifier", socket.name))
        if token in visited:
            return None

        visited.add(token)
        try:
            node = socket.node
            if node.type in {
                "BSDF_PRINCIPLED",
                "BSDF_DIFFUSE",
                "BSDF_GLOSSY",
                "BSDF_GLASS",
                "BSDF_TRANSLUCENT",
                "BSDF_TOON",
                "BSDF_REFRACTION",
                "EMISSION",
                "BACKGROUND",
                "MIX_SHADER",
                "ADD_SHADER",
            }:
                return self._resolve_shader_node_rgba(node, visited)

            if node.type == "RGB":
                return self._rgba_from_default(getattr(socket, "default_value", None))

            if node.type == "MIX_RGB":
                fac = self._resolve_scalar_socket_value(node.inputs.get("Fac"), visited, 0.5)
                color_a = self._resolve_color_socket_rgba(node.inputs.get("Color1"), visited)
                color_b = self._resolve_color_socket_rgba(node.inputs.get("Color2"), visited)
                return self._blend_rgba(color_a, color_b, fac)

            if node.type == "VALTORGB":
                fac = self._resolve_scalar_socket_value(node.inputs.get("Fac"), visited, 0.5)
                return self._color_ramp_rgba(node, fac)

            default_rgba = self._rgba_from_default(getattr(socket, "default_value", None))
            if default_rgba is not None:
                return default_rgba
            return None
        finally:
            visited.remove(token)

    def _resolve_shader_node_rgba(self, node, visited: set[tuple[int, str]]) -> tuple[float, float, float, float] | None:
        """Resolve a representative RGBA value for a shader node."""
        if node.type == "BSDF_PRINCIPLED":
            base_rgba = self._resolve_color_socket_rgba(node.inputs.get("Base Color"), visited)
            alpha = self._resolve_scalar_socket_value(node.inputs.get("Alpha"), visited, base_rgba[3] if base_rgba else 1.0)
            if base_rgba is not None:
                return (base_rgba[0], base_rgba[1], base_rgba[2], alpha)

            emission_socket = node.inputs.get("Emission Color") or node.inputs.get("Emission")
            emission_rgba = self._resolve_color_socket_rgba(emission_socket, visited)
            if emission_rgba is not None:
                strength = self._resolve_scalar_socket_value(node.inputs.get("Emission Strength"), visited, 1.0)
                return self._scale_rgba(emission_rgba, max(strength, 0.0))
            return None

        if node.type in {
            "BSDF_DIFFUSE",
            "BSDF_GLOSSY",
            "BSDF_GLASS",
            "BSDF_TRANSLUCENT",
            "BSDF_TOON",
            "BSDF_REFRACTION",
            "EMISSION",
            "BACKGROUND",
        }:
            color_rgba = self._resolve_color_socket_rgba(node.inputs.get("Color"), visited)
            if color_rgba is None:
                return None
            if node.type == "EMISSION":
                strength = self._resolve_scalar_socket_value(node.inputs.get("Strength"), visited, 1.0)
                return self._scale_rgba(color_rgba, max(strength, 0.0))
            return color_rgba

        if node.type == "MIX_SHADER":
            fac = self._resolve_scalar_socket_value(node.inputs.get("Fac"), visited, 0.5)
            shader_a = self._resolve_shader_socket_rgba(node.inputs[1], visited)
            shader_b = self._resolve_shader_socket_rgba(node.inputs[2], visited)
            return self._blend_rgba(shader_a, shader_b, fac)

        if node.type == "ADD_SHADER":
            shader_a = self._resolve_shader_socket_rgba(node.inputs[0], visited)
            shader_b = self._resolve_shader_socket_rgba(node.inputs[1], visited)
            return self._add_rgba(shader_a, shader_b)

        return None

    def _resolve_color_socket_rgba(self, socket, visited: set[tuple[int, str]]) -> tuple[float, float, float, float] | None:
        """Resolve an RGBA value from a color input socket or its default value."""
        if socket is None:
            return None
        if getattr(socket, "is_linked", False) and socket.links:
            rgba = self._resolve_socket_rgba(socket.links[0].from_socket, visited)
            if rgba is not None:
                return rgba
        return self._rgba_from_default(getattr(socket, "default_value", None))

    def _resolve_scalar_socket_value(self, socket, visited: set[tuple[int, str]], fallback: float) -> float:
        """Resolve a scalar input value from a linked socket or fallback default."""
        if socket is None:
            return fallback
        if getattr(socket, "is_linked", False) and socket.links:
            value = self._resolve_socket_scalar(socket.links[0].from_socket, visited)
            if value is not None:
                return value

        default_value = getattr(socket, "default_value", None)
        if isinstance(default_value, (int, float)):
            return float(default_value)
        return fallback

    def _resolve_socket_scalar(self, socket, visited: set[tuple[int, str]]) -> float | None:
        """Resolve a scalar value from a linked node socket."""
        if socket is None:
            return None

        token = (id(socket.node), getattr(socket, "identifier", socket.name), "scalar")
        if token in visited:
            return None

        visited.add(token)
        try:
            node = socket.node
            if node.type == "VALUE":
                return float(getattr(socket, "default_value", 0.0))

            if node.type == "MATH":
                value_a = self._resolve_scalar_socket_value(node.inputs[0], visited, float(node.inputs[0].default_value))
                value_b = self._resolve_scalar_socket_value(node.inputs[1], visited, float(node.inputs[1].default_value))
                operation = getattr(node, "operation", "").upper()
                if operation == "ADD":
                    return value_a + value_b
                if operation == "SUBTRACT":
                    return value_a - value_b
                if operation == "MULTIPLY":
                    return value_a * value_b
                if operation == "DIVIDE":
                    return value_a / value_b if abs(value_b) > 1e-8 else None
                if operation == "MINIMUM":
                    return min(value_a, value_b)
                if operation == "MAXIMUM":
                    return max(value_a, value_b)

            rgba = self._resolve_socket_rgba(socket, visited)
            if rgba is not None:
                return 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]

            default_value = getattr(socket, "default_value", None)
            if isinstance(default_value, (int, float)):
                return float(default_value)
            return None
        finally:
            visited.remove(token)

    def _color_ramp_rgba(self, node, fac: float) -> tuple[float, float, float, float] | None:
        """Sample a representative RGBA value from a ColorRamp node."""
        color_ramp = getattr(node, "color_ramp", None)
        elements = list(getattr(color_ramp, "elements", []) or [])
        if not elements:
            return None

        position = max(0.0, min(1.0, fac))
        if position <= elements[0].position:
            return self._clamp_rgba(elements[0].color)
        if position >= elements[-1].position:
            return self._clamp_rgba(elements[-1].color)

        for left, right in zip(elements, elements[1:]):
            if left.position <= position <= right.position:
                span = max(right.position - left.position, 1e-8)
                blend = (position - left.position) / span
                return self._blend_rgba(self._clamp_rgba(left.color), self._clamp_rgba(right.color), blend)
        return self._clamp_rgba(elements[-1].color)

    def _rgba_from_default(self, value) -> tuple[float, float, float, float] | None:
        """Return a clamped RGBA tuple from a Blender socket default value."""
        if value is None:
            return None
        try:
            components = tuple(float(component) for component in value[:4])
        except (TypeError, ValueError, IndexError):
            return None
        if len(components) >= 4:
            return self._clamp_rgba(components[:4])
        if len(components) == 3:
            return self._clamp_rgba((*components, 1.0))
        return None

    def _blend_rgba(
        self,
        rgba_a: tuple[float, float, float, float] | None,
        rgba_b: tuple[float, float, float, float] | None,
        fac: float,
    ) -> tuple[float, float, float, float] | None:
        """Linearly blend two RGBA colors."""
        if rgba_a is None:
            return rgba_b
        if rgba_b is None:
            return rgba_a

        factor = max(0.0, min(1.0, float(fac)))
        return self._clamp_rgba(
            tuple((1.0 - factor) * rgba_a[index] + factor * rgba_b[index] for index in range(4))
        )

    def _add_rgba(
        self,
        rgba_a: tuple[float, float, float, float] | None,
        rgba_b: tuple[float, float, float, float] | None,
    ) -> tuple[float, float, float, float] | None:
        """Combine two RGBA colors from an Add Shader node."""
        if rgba_a is None:
            return rgba_b
        if rgba_b is None:
            return rgba_a
        return self._clamp_rgba(tuple(rgba_a[index] + rgba_b[index] for index in range(4)))

    def _scale_rgba(self, rgba: tuple[float, float, float, float], factor: float) -> tuple[float, float, float, float]:
        """Scale RGB channels by a factor while preserving alpha."""
        return self._clamp_rgba((rgba[0] * factor, rgba[1] * factor, rgba[2] * factor, rgba[3]))

    def _clamp_rgba(self, rgba) -> tuple[float, float, float, float]:
        """Clamp an RGBA sequence to 0..1."""
        components = tuple(float(component) for component in rgba[:4])
        if len(components) < 4:
            components = (*components[:3], 1.0)
        return tuple(max(0.0, min(1.0, component)) for component in components[:4])

    def _rgba_to_svg_color(self, rgba: tuple[float, ...]) -> str:
        """Convert an RGBA tuple in 0..1 space to an SVG hex color string."""
        channels = [max(0, min(255, round(component * 255))) for component in rgba[:3]]
        return "#" + "".join(f"{channel:02x}" for channel in channels)

    def _coerce_rgb(
        self,
        value: tuple[float, ...] | list[float],
        fallback: tuple[float, float, float],
    ) -> tuple[float, float, float]:
        """Return a clamped RGB tuple from Blender property values or a fallback."""
        try:
            components = tuple(float(component) for component in value[:3])
        except (TypeError, ValueError):
            return fallback
        if len(components) != 3:
            return fallback
        return tuple(max(0.0, min(1.0, component)) for component in components)

    def _format_scalar(self, value: float) -> str:
        """Format a single numeric SVG attribute value."""
        return format_number(float(value), self.precision)

    def _fill_rgba_for_object(self, obj: bpy.types.Object) -> tuple[float, float, float, float]:
        """Return the best export fill color for an object or the configured fallback."""
        material_rgba = self._material_color_for_slot(obj, 0)
        if material_rgba is not None:
            return material_rgba

        object_color = getattr(obj, "color", None)
        if object_color is not None:
            rgba = tuple(float(component) for component in object_color[:4])
            if any(abs(component - 1.0) > 1e-6 for component in rgba):
                return rgba

        return (*self.default_fill_color, 1.0)

    def _apply_style_defaults(self, obj: bpy.types.Object, style_attributes: dict[str, str]) -> dict[str, str]:
        """Fill in export-time SVG paint defaults without overriding explicit styles."""
        if "fill" not in style_attributes:
            rgba = self._fill_rgba_for_object(obj)
            style_attributes["fill"] = self._rgba_to_svg_color(rgba)
            if rgba[3] < 0.999:
                style_attributes["fill-opacity"] = self._format_scalar(rgba[3])

        if "stroke" not in style_attributes:
            if self.apply_stroke:
                style_attributes["stroke"] = self._rgba_to_svg_color((*self.default_stroke_color, 1.0))
                style_attributes.setdefault("stroke-width", self._format_scalar(self.stroke_width))
            else:
                style_attributes["stroke"] = "none"

        return style_attributes

    def _style_attributes_for_object(
        self,
        obj: bpy.types.Object,
        gradient_registry: dict[str, str],
        gradient_ids_in_use: set[str],
        gradient_definitions: list,
    ) -> dict[str, str]:
        """Collect exportable SVG style attributes stored on a Blender object."""
        style_attributes = export_style_attributes(extract_style_metadata(obj))
        payload = material_gradient_payload(self._active_material(obj))
        if payload:
            payload_key_data = dict(payload)
            payload_key_data.pop("gradient_id", None)
            payload_key_data.pop("paint_target", None)
            payload_key = json.dumps(payload_key_data, sort_keys=True, separators=(",", ":"))
            gradient_id = gradient_registry.get(payload_key)
            if gradient_id is None:
                preferred_id = str(payload.get("gradient_id") or "specioGradient")
                gradient_id = self._unique_gradient_id(preferred_id, gradient_ids_in_use)
                gradient_registry[payload_key] = gradient_id
                gradient_ids_in_use.add(gradient_id)

                stored_payload = dict(payload)
                stored_payload["gradient_id"] = gradient_id
                gradient_definitions.append(gradient_from_payload(stored_payload))

            paint_target = str(payload.get("paint_target") or "fill")
            style_attributes[paint_target] = f"url(#{gradient_id})"
            if paint_target == "stroke" and "fill" not in style_attributes:
                style_attributes["fill"] = "none"

        return self._apply_style_defaults(obj, style_attributes)


    def _active_material(self, obj: bpy.types.Object):
        if not obj.data or not obj.data.materials:
            return None
        return obj.data.materials[0]


    def _unique_gradient_id(self, preferred_id: str, used_ids: set[str]) -> str:
        candidate = preferred_id or "specioGradient"
        if candidate not in used_ids:
            return candidate

        suffix = 1
        while True:
            candidate = f"{preferred_id}_{suffix:03d}"
            if candidate not in used_ids:
                return candidate
            suffix += 1

    def _build_collection_path_map(self, scene: bpy.types.Scene) -> dict[bpy.types.Collection, tuple[str, ...]]:
        """Map scene collection descendants to deterministic export group paths."""
        collection_paths: dict[bpy.types.Collection, tuple[str, ...]] = {}

        def visit(collection: bpy.types.Collection, prefix: tuple[str, ...]):
            for child in sorted(collection.children, key=self._collection_sort_key):
                child_path = prefix if self._is_synthetic_root_collection(child) else prefix + (self._export_group_id(child),)
                collection_paths[child] = child_path
                visit(child, child_path)

        visit(scene.collection, ())
        return collection_paths

    def _resolve_group_path(
        self,
        obj: bpy.types.Object,
        collection_paths: dict[bpy.types.Collection, tuple[str, ...]],
    ) -> tuple[str, ...]:
        """Resolve the best export group path for an object from its collections."""
        candidates = [collection_paths[col] for col in obj.users_collection if col in collection_paths]
        if not candidates:
            return ()
        return sorted(candidates, key=lambda item: (len(item), item))[0]

    def _object_sort_key(
        self,
        obj: bpy.types.Object,
        collection_paths: dict[bpy.types.Collection, tuple[str, ...]],
    ) -> tuple[bool, tuple[int, ...], tuple[str, ...], str]:
        """Return a stable export sort key that prefers preserved SVG sibling order."""
        order_path = self._order_path_for(obj)
        return (
            order_path is None,
            order_path or (),
            self._resolve_group_path(obj, collection_paths),
            obj.name,
        )

    def _collection_sort_key(self, collection: bpy.types.Collection) -> tuple[bool, tuple[int, ...], str]:
        """Return a stable sort key for collection traversal during export."""
        order_path = self._order_path_for(collection)
        return (order_path is None, order_path or (), collection.name)

    def _order_path_for(self, owner) -> tuple[int, ...] | None:
        """Return the stored SVG sibling order path for an object or collection."""
        try:
            value = owner.get(SVG_ORDER_PATH_PROP)
        except AttributeError:
            return None
        return _parse_order_path(value)

    def _export_group_id(self, collection: bpy.types.Collection) -> str:
        """Return the original SVG group id for a collection when available."""
        value = collection.get(SVG_GROUP_ID_PROP)
        return str(value) if value else collection.name

    def _is_synthetic_root_collection(self, collection: bpy.types.Collection) -> bool:
        """Return whether a collection is the importer-created SVG root wrapper."""
        return bool(collection.get(SVG_SYNTHETIC_ROOT_PROP))

    def _poly_spline_to_path(self, obj: bpy.types.Object, spline):
        """Convert a poly-like spline to SVG path data."""
        points = [self._point_to_svg(obj.matrix_world @ point.co.xyz) for point in spline.points]
        if not points:
            return "", (0.0, 0.0, 0.0, 0.0)

        commands = [f"M {format_xy(points[0], self.precision)}"]
        commands.extend(f"L {format_xy(point, self.precision)}" for point in points[1:])
        if spline.use_cyclic_u:
            commands.append("Z")
        return " ".join(commands), self._bounds(points)

    def _bezier_spline_to_path(self, obj: bpy.types.Object, spline):
        """Convert a bezier spline to SVG path data."""
        bezier_points = spline.bezier_points
        if not bezier_points:
            return "", (0.0, 0.0, 0.0, 0.0)

        svg_points = [self._point_to_svg(obj.matrix_world @ point.co) for point in bezier_points]
        commands = [f"M {format_xy(svg_points[0], self.precision)}"]
        all_points = list(svg_points)

        for index in range(len(bezier_points) - 1):
            current = bezier_points[index]
            nxt = bezier_points[index + 1]
            handle_right = self._point_to_svg(obj.matrix_world @ current.handle_right)
            handle_left = self._point_to_svg(obj.matrix_world @ nxt.handle_left)
            end = self._point_to_svg(obj.matrix_world @ nxt.co)
            all_points.extend([handle_right, handle_left, end])
            commands.append(
                "C "
                f"{format_xy(handle_right, self.precision)} "
                f"{format_xy(handle_left, self.precision)} "
                f"{format_xy(end, self.precision)}"
            )

        if spline.use_cyclic_u and len(bezier_points) > 1:
            last = bezier_points[-1]
            first = bezier_points[0]
            handle_right = self._point_to_svg(obj.matrix_world @ last.handle_right)
            handle_left = self._point_to_svg(obj.matrix_world @ first.handle_left)
            end = self._point_to_svg(obj.matrix_world @ first.co)
            all_points.extend([handle_right, handle_left, end])
            commands.append(
                "C "
                f"{format_xy(handle_right, self.precision)} "
                f"{format_xy(handle_left, self.precision)} "
                f"{format_xy(end, self.precision)}"
            )
            commands.append("Z")

        return " ".join(commands), self._bounds(all_points)

    def _point_to_svg(self, point) -> tuple[float, float]:
        """Convert a Blender point into SVG coordinates."""
        if self.project_through_camera:
            return self._project_point_to_svg(point)
        return (point.x * self.scale, -point.y * self.scale)

    def _bounds(self, points: list[tuple[float, float]]):
        """Return min and max bounds for a point set."""
        xs = [point[0] for point in points]
        ys = [point[1] for point in points]
        return (min(xs), min(ys), max(xs), max(ys))

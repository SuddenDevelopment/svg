"""Pure SVG gradient parsing and serialization helpers."""

from __future__ import annotations

from dataclasses import dataclass, replace
import json
from xml.etree.ElementTree import Element

from .style import parse_color_value, parse_style_attribute
from .transform import IDENTITY_TRANSFORM, AffineTransform, parse_svg_transform


XLINK_HREF_SUFFIX = "}href"


@dataclass(slots=True)
class SVGGradientStop:
    """A single resolved SVG gradient stop."""

    offset: float
    color: tuple[float, float, float, float]


@dataclass(slots=True)
class SVGGradient:
    """A resolved SVG linear or radial gradient definition."""

    gradient_id: str
    kind: str
    gradient_units: str
    spread_method: str
    transform: AffineTransform
    x1: float | None = None
    y1: float | None = None
    x2: float | None = None
    y2: float | None = None
    cx: float | None = None
    cy: float | None = None
    r: float | None = None
    fx: float | None = None
    fy: float | None = None
    stops: list[SVGGradientStop] | None = None


def extract_paint_server_id(value: str | None) -> str | None:
    """Extract the referenced paint-server id from a url(#...) style token."""
    if not value:
        return None
    normalized = value.strip()
    if not normalized.startswith("url("):
        return None

    start = normalized.find("#")
    end = normalized.find(")", start)
    if start == -1 or end == -1:
        return None
    paint_id = normalized[start + 1 : end].strip()
    return paint_id or None


def parse_svg_gradients(root: Element) -> dict[str, SVGGradient]:
    """Parse and resolve SVG gradient definitions from an element tree."""
    elements_by_id: dict[str, Element] = {}
    for element in root.iter():
        tag = _strip_namespace(element.tag)
        if tag in {"linearGradient", "radialGradient"}:
            gradient_id = element.get("id")
            if gradient_id:
                elements_by_id[gradient_id] = element

    resolved: dict[str, SVGGradient] = {}

    def resolve(gradient_id: str) -> SVGGradient | None:
        if gradient_id in resolved:
            return resolved[gradient_id]

        element = elements_by_id.get(gradient_id)
        if element is None:
            return None

        tag = _strip_namespace(element.tag)
        base = None
        href = _extract_href(element)
        if href:
            base = resolve(href)

        gradient = _gradient_defaults(tag, gradient_id)
        if base is not None:
            gradient = replace(base, gradient_id=gradient_id)

        gradient.kind = "linear" if tag == "linearGradient" else "radial"
        gradient.gradient_units = element.get("gradientUnits") or gradient.gradient_units
        gradient.spread_method = element.get("spreadMethod") or gradient.spread_method
        gradient.transform = parse_svg_transform(element.get("gradientTransform")) if element.get("gradientTransform") else gradient.transform

        if gradient.kind == "linear":
            gradient.x1 = _parse_coordinate(element.get("x1"), gradient.x1)
            gradient.y1 = _parse_coordinate(element.get("y1"), gradient.y1)
            gradient.x2 = _parse_coordinate(element.get("x2"), gradient.x2)
            gradient.y2 = _parse_coordinate(element.get("y2"), gradient.y2)
        else:
            gradient.cx = _parse_coordinate(element.get("cx"), gradient.cx)
            gradient.cy = _parse_coordinate(element.get("cy"), gradient.cy)
            gradient.r = _parse_coordinate(element.get("r"), gradient.r)
            gradient.fx = _parse_coordinate(element.get("fx"), gradient.fx if gradient.fx is not None else gradient.cx)
            gradient.fy = _parse_coordinate(element.get("fy"), gradient.fy if gradient.fy is not None else gradient.cy)

        stops = _parse_gradient_stops(element)
        if stops:
            gradient.stops = stops
        elif gradient.stops is None:
            gradient.stops = []

        resolved[gradient_id] = gradient
        return gradient

    for gradient_id in elements_by_id:
        resolve(gradient_id)

    return {key: value for key, value in resolved.items() if value.stops}


def average_gradient_color(gradient: SVGGradient) -> tuple[float, float, float, float]:
    """Return a simple representative RGBA color for a gradient."""
    if not gradient.stops:
        return (0.8, 0.8, 0.8, 1.0)

    totals = [0.0, 0.0, 0.0, 0.0]
    for stop in gradient.stops:
        for index, channel in enumerate(stop.color):
            totals[index] += channel
    count = float(len(gradient.stops))
    return tuple(channel / count for channel in totals)


def gradient_to_payload(gradient: SVGGradient, paint_target: str = "fill") -> dict[str, object]:
    """Serialize a resolved gradient into a JSON-safe payload."""
    return {
        "gradient_id": gradient.gradient_id,
        "kind": gradient.kind,
        "gradient_units": gradient.gradient_units,
        "spread_method": gradient.spread_method,
        "transform": list(gradient.transform),
        "paint_target": paint_target,
        "x1": gradient.x1,
        "y1": gradient.y1,
        "x2": gradient.x2,
        "y2": gradient.y2,
        "cx": gradient.cx,
        "cy": gradient.cy,
        "r": gradient.r,
        "fx": gradient.fx,
        "fy": gradient.fy,
        "stops": [
            {
                "offset": stop.offset,
                "color": list(stop.color),
            }
            for stop in (gradient.stops or [])
        ],
    }


def gradient_from_payload(payload: dict[str, object]) -> SVGGradient:
    """Deserialize an SVG gradient payload into a gradient dataclass."""
    stops = [
        SVGGradientStop(
            offset=float(stop.get("offset", 0.0)),
            color=tuple(float(component) for component in stop.get("color", (0.0, 0.0, 0.0, 1.0))),
        )
        for stop in payload.get("stops", [])
    ]
    transform_values = payload.get("transform") or IDENTITY_TRANSFORM
    transform = tuple(float(value) for value in transform_values)
    if len(transform) != 6:
        transform = IDENTITY_TRANSFORM

    return SVGGradient(
        gradient_id=str(payload.get("gradient_id") or "specioGradient"),
        kind=str(payload.get("kind") or "linear"),
        gradient_units=str(payload.get("gradient_units") or "objectBoundingBox"),
        spread_method=str(payload.get("spread_method") or "pad"),
        transform=transform,
        x1=_payload_float(payload.get("x1")),
        y1=_payload_float(payload.get("y1")),
        x2=_payload_float(payload.get("x2")),
        y2=_payload_float(payload.get("y2")),
        cx=_payload_float(payload.get("cx")),
        cy=_payload_float(payload.get("cy")),
        r=_payload_float(payload.get("r")),
        fx=_payload_float(payload.get("fx")),
        fy=_payload_float(payload.get("fy")),
        stops=stops,
    )


def payload_to_json(payload: dict[str, object]) -> str:
    """Serialize a gradient payload to deterministic JSON text."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def payload_from_json(payload_text: str | None) -> dict[str, object] | None:
    """Parse a JSON-encoded gradient payload."""
    if not payload_text:
        return None
    try:
        parsed = json.loads(payload_text)
    except (TypeError, ValueError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _gradient_defaults(tag: str, gradient_id: str) -> SVGGradient:
    if tag == "linearGradient":
        return SVGGradient(
            gradient_id=gradient_id,
            kind="linear",
            gradient_units="objectBoundingBox",
            spread_method="pad",
            transform=IDENTITY_TRANSFORM,
            x1=0.0,
            y1=0.0,
            x2=1.0,
            y2=0.0,
            stops=[],
        )
    return SVGGradient(
        gradient_id=gradient_id,
        kind="radial",
        gradient_units="objectBoundingBox",
        spread_method="pad",
        transform=IDENTITY_TRANSFORM,
        cx=0.5,
        cy=0.5,
        r=0.5,
        fx=0.5,
        fy=0.5,
        stops=[],
    )


def _parse_gradient_stops(element: Element) -> list[SVGGradientStop]:
    stops: list[SVGGradientStop] = []
    for child in element:
        if _strip_namespace(child.tag) != "stop":
            continue

        style = parse_style_attribute(child.get("style", ""))
        stop_color = child.get("stop-color") or style.get("stop-color") or "black"
        rgba = parse_color_value(stop_color)
        if rgba is None:
            rgba = (0.0, 0.0, 0.0, 1.0)

        stop_opacity_value = child.get("stop-opacity") or style.get("stop-opacity")
        alpha = _parse_opacity(stop_opacity_value, rgba[3])
        offset = _parse_coordinate(child.get("offset"), 0.0)
        stops.append(SVGGradientStop(offset=max(0.0, min(offset, 1.0)), color=(rgba[0], rgba[1], rgba[2], alpha)))

    return sorted(stops, key=lambda item: item.offset)


def _extract_href(element: Element) -> str | None:
    href = element.get("href")
    if href is None:
        for key, value in element.attrib.items():
            if key.endswith(XLINK_HREF_SUFFIX):
                href = value
                break
    if not href:
        return None
    return href[1:] if href.startswith("#") else href


def _parse_coordinate(value: str | None, default: float | None) -> float | None:
    if value is None:
        return default
    normalized = value.strip()
    if not normalized:
        return default
    try:
        if normalized.endswith("%"):
            return float(normalized[:-1]) / 100.0
        return float(normalized)
    except ValueError:
        return default


def _parse_opacity(value: str | None, default: float) -> float:
    if value is None:
        return default
    try:
        return max(0.0, min(float(value.strip()), 1.0))
    except ValueError:
        return default


def _strip_namespace(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def _payload_float(value: object) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
"""Pure Python SVG formatting helpers."""


def format_number(value: float, precision: int) -> str:
    """Format a number with stable precision and trimmed zeros."""
    formatted = f"{value:.{precision}f}"
    formatted = formatted.rstrip("0").rstrip(".")
    return formatted if formatted and formatted != "-0" else "0"


def format_xy(point: tuple[float, float], precision: int) -> str:
    """Format an XY tuple for SVG output."""
    return f"{format_number(point[0], precision)} {format_number(point[1], precision)}"
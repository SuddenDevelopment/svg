"""Pure Python SVG document assembly helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
import xml.etree.ElementTree as ET

from .formatting import format_number
from .gradients import SVGGradient
from .transform import IDENTITY_TRANSFORM


Bounds = tuple[float, float, float, float]


@dataclass(slots=True)
class SVGPathElement:
    """A single SVG path plus optional group hierarchy metadata."""

    path_id: str
    path_data: str
    bounds: Bounds
    group_path: tuple[str, ...] = ()
    attributes: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class SVGImageElement:
    """An SVG ``<image>`` element for roundtrip export."""

    element_id: str
    href: str
    x: float
    y: float
    width: float
    height: float
    bounds: Bounds
    group_path: tuple[str, ...] = ()


def build_svg_document(
    paths: list[SVGPathElement],
    precision: int,
    gradients: list[SVGGradient] | None = None,
    images: list[SVGImageElement] | None = None,
) -> ET.Element:
    """Build an SVG element tree from exported path and image elements."""
    all_elements: list[SVGPathElement | SVGImageElement] = list(paths or [])
    if images:
        all_elements.extend(images)

    if not all_elements:
        raise ValueError("At least one SVG path or image element is required")

    min_x = min(el.bounds[0] for el in all_elements)
    min_y = min(el.bounds[1] for el in all_elements)
    max_x = max(el.bounds[2] for el in all_elements)
    max_y = max(el.bounds[3] for el in all_elements)
    width = max(max_x - min_x, 1.0)
    height = max(max_y - min_y, 1.0)

    svg = ET.Element(
        "svg",
        {
            "xmlns": "http://www.w3.org/2000/svg",
            "version": "1.1",
            "width": format_number(width, precision),
            "height": format_number(height, precision),
            "viewBox": " ".join(
                [
                    format_number(min_x, precision),
                    format_number(min_y, precision),
                    format_number(width, precision),
                    format_number(height, precision),
                ]
            ),
        },
    )

    if gradients:
        defs = ET.SubElement(svg, "defs")
        for gradient in sorted(gradients, key=lambda item: item.gradient_id):
            _append_gradient_definition(defs, gradient, precision)

    group_cache: dict[tuple[str, ...], ET.Element] = {(): svg}

    for path in (paths or []):
        parent = svg
        current_path: list[str] = []
        for group_name in path.group_path:
            current_path.append(group_name)
            key = tuple(current_path)
            if key not in group_cache:
                group_cache[key] = ET.SubElement(parent, "g", {"id": group_name})
            parent = group_cache[key]

        ET.SubElement(
            parent,
            "path",
            {
                "id": path.path_id,
                "d": path.path_data,
                "fill": "none",
                "stroke": "black",
                **path.attributes,
            },
        )

    for img in (images or []):
        parent = svg
        current_path: list[str] = []
        for group_name in img.group_path:
            current_path.append(group_name)
            key = tuple(current_path)
            if key not in group_cache:
                group_cache[key] = ET.SubElement(parent, "g", {"id": group_name})
            parent = group_cache[key]

        attrs: dict[str, str] = {
            "id": img.element_id,
            "href": img.href,
            "x": format_number(img.x, precision),
            "y": format_number(img.y, precision),
            "width": format_number(img.width, precision),
            "height": format_number(img.height, precision),
        }
        ET.SubElement(parent, "image", attrs)

    return svg


def _append_gradient_definition(parent: ET.Element, gradient: SVGGradient, precision: int) -> None:
    tag_name = "linearGradient" if gradient.kind == "linear" else "radialGradient"
    attributes = {
        "id": gradient.gradient_id,
        "gradientUnits": gradient.gradient_units,
    }
    if gradient.spread_method != "pad":
        attributes["spreadMethod"] = gradient.spread_method
    if gradient.transform != IDENTITY_TRANSFORM:
        attributes["gradientTransform"] = _format_gradient_transform(gradient.transform, precision)

    if gradient.kind == "linear":
        if gradient.x1 is not None:
            attributes["x1"] = format_number(gradient.x1, precision)
        if gradient.y1 is not None:
            attributes["y1"] = format_number(gradient.y1, precision)
        if gradient.x2 is not None:
            attributes["x2"] = format_number(gradient.x2, precision)
        if gradient.y2 is not None:
            attributes["y2"] = format_number(gradient.y2, precision)
    else:
        if gradient.cx is not None:
            attributes["cx"] = format_number(gradient.cx, precision)
        if gradient.cy is not None:
            attributes["cy"] = format_number(gradient.cy, precision)
        if gradient.r is not None:
            attributes["r"] = format_number(gradient.r, precision)
        if gradient.fx is not None:
            attributes["fx"] = format_number(gradient.fx, precision)
        if gradient.fy is not None:
            attributes["fy"] = format_number(gradient.fy, precision)

    gradient_element = ET.SubElement(parent, tag_name, attributes)
    for stop in gradient.stops or []:
        ET.SubElement(
            gradient_element,
            "stop",
            {
                "offset": format_number(stop.offset, precision),
                "stop-color": _format_rgb_hex(stop.color),
                "stop-opacity": format_number(stop.color[3], precision),
            },
        )


def _format_gradient_transform(transform, precision: int) -> str:
    return "matrix(" + " ".join(format_number(value, precision) for value in transform) + ")"


def _format_rgb_hex(color: tuple[float, float, float, float]) -> str:
    channels = [max(0, min(255, round(component * 255))) for component in color[:3]]
    return "#" + "".join(f"{channel:02x}" for channel in channels)
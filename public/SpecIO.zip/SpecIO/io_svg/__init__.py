"""SVG import and export helpers for SpecIO."""

from .document import SVGImageElement, SVGPathElement, build_svg_document
from .formatting import format_number, format_xy
from .gradients import SVGGradient, SVGGradientStop, average_gradient_color, extract_paint_server_id, gradient_from_payload, gradient_to_payload, parse_svg_gradients, payload_from_json, payload_to_json
from .path_parser import PathSegment, PathSubpath, parse_svg_path
from .style import (
    STYLE_ATTRIBUTE_KEYS,
    STYLE_METADATA_PROPERTIES,
    CSSRules,
    apply_curve_style_settings,
    apply_style_metadata,
    export_style_attributes,
    extract_style_attributes,
    extract_style_metadata,
    is_hidden_style,
    parse_color_value,
    parse_css_style_block,
    parse_numeric_style_value,
    resolve_display_color,
    merge_style_attributes,
    parse_style_attribute,
)
from .transform import IDENTITY_TRANSFORM, AffineTransform, apply_transform, invert_transform, multiply_transforms, parse_svg_transform

SVGCurveBuilder = None
create_gradient_material = None
material_gradient_payload = None
sync_specio_gradient_material = None
SVGExporter = None
SVGImporter = None

try:
    from .curve_builder import SVGCurveBuilder
    from .exporter import SVGExporter
    from .gradient_materials import create_gradient_material, material_gradient_payload, sync_specio_gradient_material
    from .importer import SVGImporter
except ModuleNotFoundError as exc:
    if exc.name != "bpy":
        raise

__all__ = (
    "PathSegment",
    "PathSubpath",
    "SVGGradient",
    "SVGGradientStop",
    "SVGPathElement",
    "SVGCurveBuilder",
    "STYLE_ATTRIBUTE_KEYS",
    "STYLE_METADATA_PROPERTIES",
    "AffineTransform",
    "IDENTITY_TRANSFORM",
    "SVGExporter",
    "SVGImporter",
    "average_gradient_color",
    "apply_transform",
    "apply_curve_style_settings",
    "apply_style_metadata",
    "build_svg_document",
    "create_gradient_material",
    "extract_paint_server_id",
    "export_style_attributes",
    "extract_style_attributes",
    "extract_style_metadata",
    "format_number",
    "format_xy",
    "gradient_from_payload",
    "gradient_to_payload",
    "invert_transform",
    "is_hidden_style",
    "material_gradient_payload",
    "merge_style_attributes",
    "multiply_transforms",
    "parse_svg_gradients",
    "parse_color_value",
    "parse_numeric_style_value",
    "parse_svg_path",
    "parse_svg_transform",
    "parse_style_attribute",
    "payload_from_json",
    "payload_to_json",
    "resolve_display_color",
    "sync_specio_gradient_material",
)
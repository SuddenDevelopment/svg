"""Raster image helpers for SVG <image> element import and export."""

from __future__ import annotations

import base64
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Custom property keys stored on Blender objects carrying imported images.
SPECIO_IMAGE_PROP = "specio_svg_image"
SPECIO_IMAGE_HREF_PROP = "specio_svg_image_href"
SPECIO_IMAGE_X_PROP = "specio_svg_image_x"
SPECIO_IMAGE_Y_PROP = "specio_svg_image_y"
SPECIO_IMAGE_W_PROP = "specio_svg_image_w"
SPECIO_IMAGE_H_PROP = "specio_svg_image_h"

_MIME_TO_EXT: dict[str, str] = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/bmp": ".bmp",
    "image/tiff": ".tiff",
}


def resolve_image_href(
    href: str,
    svg_directory: Path,
) -> tuple[bytes | None, str]:
    """Resolve an SVG image *href* to raw bytes and a file extension.

    Supported sources:
    - ``data:image/...;base64,...`` inline data URIs.
    - Relative or absolute local file paths resolved against *svg_directory*.

    Remote URLs (``http://``, ``https://``, ``ftp://``) are intentionally
    rejected to avoid SSRF.

    Returns ``(image_bytes, extension)`` on success or ``(None, "")`` when the
    href cannot be resolved.
    """
    if not href:
        return None, ""

    # ---- inline base64 data URI -------------------------------------------
    if href.startswith("data:"):
        return _decode_data_uri(href)

    # ---- reject remote URLs -----------------------------------------------
    lower = href.lower()
    if lower.startswith(("http://", "https://", "ftp://", "//")):
        logger.info("Skipping remote image reference: %.120s", href)
        return None, ""

    # ---- local file path --------------------------------------------------
    candidate = svg_directory / href
    try:
        candidate = candidate.resolve()
    except (OSError, ValueError):
        return None, ""

    if not candidate.is_file():
        logger.info("Referenced image file not found: %s", candidate)
        return None, ""

    ext = candidate.suffix.lower()
    try:
        image_bytes = candidate.read_bytes()
    except OSError:
        return None, ""
    return image_bytes, ext


def encode_image_as_data_uri(image_bytes: bytes, extension: str = ".png") -> str:
    """Encode raw image bytes into a ``data:`` URI for SVG embedding."""
    mime = _ext_to_mime(extension)
    encoded = base64.b64encode(image_bytes).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def is_image_plane(obj) -> bool:
    """Return whether a Blender object is a SpecIO-imported image plane."""
    return obj.type == "MESH" and bool(obj.get(SPECIO_IMAGE_PROP))


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _decode_data_uri(href: str) -> tuple[bytes | None, str]:
    """Decode a ``data:image/...;base64,...`` URI."""
    header, _, payload = href.partition(",")
    if not payload or "base64" not in header:
        return None, ""

    ext = ".png"
    header_lower = header.lower()
    for mime, candidate_ext in _MIME_TO_EXT.items():
        if mime in header_lower:
            ext = candidate_ext
            break

    try:
        image_bytes = base64.b64decode(payload, validate=True)
    except Exception:
        return None, ""

    if len(image_bytes) < 8:
        return None, ""

    return image_bytes, ext


def _ext_to_mime(extension: str) -> str:
    """Map a file extension to a MIME type, defaulting to ``image/png``."""
    ext = extension.lower().lstrip(".")
    mapping = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
        "gif": "image/gif",
        "bmp": "image/bmp",
        "tiff": "image/tiff",
    }
    return mapping.get(ext, "image/png")

"""SVG import helpers for SpecIO."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

import bpy

from .curve_builder import SVGCurveBuilder
from .gradient_materials import create_gradient_material
from .gradients import average_gradient_color, extract_paint_server_id, parse_svg_gradients
from .image_util import (
    SPECIO_IMAGE_HREF_PROP,
    SPECIO_IMAGE_PROP,
    SPECIO_IMAGE_X_PROP,
    SPECIO_IMAGE_Y_PROP,
    SPECIO_IMAGE_W_PROP,
    SPECIO_IMAGE_H_PROP,
    resolve_image_href,
)
from .path_parser import parse_svg_path
from .style import (
    CSSRules,
    apply_curve_style_settings,
    apply_style_metadata,
    extract_style_attributes,
    extract_style_metadata,
    is_fill_enabled,
    parse_numeric_style_value,
    is_stroke_enabled,
    is_hidden_style,
    merge_style_attributes,
    parse_color_value,
    parse_css_style_block,
)
from .transform import IDENTITY_TRANSFORM, multiply_transforms, parse_svg_transform


def _strip_namespace(tag: str) -> str:
    """Return the local tag name without any XML namespace."""
    return tag.split("}", 1)[-1] if "}" in tag else tag


SVG_ORDER_PATH_PROP = "specio_svg_order_path"
SVG_GROUP_ID_PROP = "specio_svg_group_id"
SVG_SYNTHETIC_ROOT_PROP = "specio_svg_synthetic_root"
SVG_STROKE_HELPER_PROP = "specio_svg_stroke_helper"
SVG_STROKE_SOURCE_PROP = "specio_svg_stroke_source"
SVG_SPLIT_COLLECTION_PROP = "specio_svg_split_collection"


def _serialize_order_path(order_path: tuple[int, ...]) -> str:
    """Serialize a sibling order path for storage on Blender data blocks."""
    return ".".join(str(part) for part in order_path)


def _spline_sample_polygon(spline) -> list[tuple[float, float]]:
    """Return a 2D polygon from a spline's control points, used for nesting tests."""
    if spline.type == "BEZIER":
        points: list[tuple[float, float]] = []
        bezier_points = spline.bezier_points
        if len(bezier_points) < 2:
            return [(p.co.x, p.co.y) for p in bezier_points]

        segment_count = len(bezier_points) if spline.use_cyclic_u else len(bezier_points) - 1
        for segment_index in range(segment_count):
            start = bezier_points[segment_index]
            end = bezier_points[(segment_index + 1) % len(bezier_points)]
            if not points:
                points.append((start.co.x, start.co.y))
            for step in range(1, 9):
                t = step / 8.0
                mt = 1.0 - t
                x = (
                    mt ** 3 * start.co.x
                    + 3.0 * mt ** 2 * t * start.handle_right.x
                    + 3.0 * mt * t ** 2 * end.handle_left.x
                    + t ** 3 * end.co.x
                )
                y = (
                    mt ** 3 * start.co.y
                    + 3.0 * mt ** 2 * t * start.handle_right.y
                    + 3.0 * mt * t ** 2 * end.handle_left.y
                    + t ** 3 * end.co.y
                )
                points.append((x, y))
        return points
    return [(p.co.x, p.co.y) for p in spline.points]


def _polygon_bbox(polygon: list[tuple[float, float]]) -> tuple[float, float, float, float] | None:
    """Return the axis-aligned bounding box of a polygon."""
    if not polygon:
        return None
    xs = [point[0] for point in polygon]
    ys = [point[1] for point in polygon]
    return (min(xs), min(ys), max(xs), max(ys))


def _polygon_area(polygon: list[tuple[float, float]]) -> float:
    """Return the signed area of a polygon."""
    if len(polygon) < 3:
        return 0.0

    area = 0.0
    for (x1, y1), (x2, y2) in zip(polygon, polygon[1:] + polygon[:1]):
        area += x1 * y2 - x2 * y1
    return area / 2.0


def _representative_polygon_point(polygon: list[tuple[float, float]]) -> tuple[float, float] | None:
    """Return a stable interior-ish sample point for a polygon."""
    if not polygon:
        return None

    centroid = (
        sum(point[0] for point in polygon) / len(polygon),
        sum(point[1] for point in polygon) / len(polygon),
    )
    if len(polygon) >= 3 and _point_in_polygon(centroid, polygon):
        return centroid
    return polygon[len(polygon) // 2]


def _point_in_polygon(point: tuple[float, float], polygon: list[tuple[float, float]]) -> bool:
    """Ray-casting point-in-polygon test in 2D."""
    x, y = point
    inside = False
    px, py = polygon[-1]
    for qx, qy in polygon:
        if (py > y) != (qy > y) and x < (qx - px) * (y - py) / (qy - py) + px:
            inside = not inside
        px, py = qx, qy
    return inside


def _reverse_spline_winding(spline) -> None:
    """Reverse the winding direction of a spline in-place.

    For Bezier splines the control points are reversed and each point's left/right
    handles are swapped, preserving the geometric shape while opposing the curve
    direction so Blender reads the spline as a hole when nested inside another.
    """
    if spline.type == "BEZIER":
        pts = spline.bezier_points
        n = len(pts)
        if n < 2:
            return
        saved = [
            (
                pts[i].co.copy(),
                pts[i].handle_left.copy(),
                pts[i].handle_right.copy(),
                pts[i].handle_left_type,
                pts[i].handle_right_type,
            )
            for i in range(n)
        ]
        saved.reverse()
        for i, (co, hl, hr, hlt, hrt) in enumerate(saved):
            pts[i].co = co
            # When the traversal direction reverses, the left and right handles swap.
            pts[i].handle_left = hr
            pts[i].handle_right = hl
            pts[i].handle_left_type = hrt
            pts[i].handle_right_type = hlt
    else:
        pts = spline.points
        n = len(pts)
        if n < 2:
            return
        saved = [pts[i].co.copy() for i in range(n)]
        saved.reverse()
        for i, co in enumerate(saved):
            pts[i].co = co


class SVGImporter:
    """Create Blender curve objects from supported SVG elements."""

    def __init__(
        self,
        scale: float = 1.0,
        height_mode: str = "PER_OBJECT",
        height_step: float = 0.01,
        stroke_overlay_offset: float = 0.001,
        intelligent_split_paths: bool = True,
    ):
        self.scale = scale
        self.height_mode = height_mode
        self.height_step = max(height_step, 0.0)
        self.stroke_overlay_offset = max(stroke_overlay_offset, 0.0)
        self.intelligent_split_paths = bool(intelligent_split_paths)
        self.curve_builder = SVGCurveBuilder(scale=scale)
        self.collections: dict[str, bpy.types.Collection] = {}
        self.gradients = {}
        self.css_rules: CSSRules = CSSRules()
        self._name_counters: dict[str, int] = {}
        self._import_object_index = 0
        self._document_size_units = 1.0
        self._svg_directory: Path | None = None
        self._skipped_images: int = 0

    def parse_svg_file(self, filepath: str):
        """Parse an SVG file and return the root XML element."""
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"SVG file not found: {filepath}")

        try:
            return ET.parse(path).getroot()
        except ET.ParseError as exc:
            raise ValueError(f"Failed to parse SVG file: {exc}") from exc

    def import_svg(self, filepath: str, context: bpy.types.Context):
        """Import an SVG file into the active scene."""
        root = self.parse_svg_file(filepath)
        self._import_object_index = 0
        self._document_size_units = self._document_size_in_blender_units(root)
        self._svg_directory = Path(filepath).parent
        self._skipped_images = 0
        self.gradients = parse_svg_gradients(root)
        self.css_rules = self._parse_css_rules(root)
        svg_name = f"{Path(filepath).stem}_SVG"
        main_collection = self._get_or_create_collection(
            svg_name,
            context.scene.collection,
        )
        main_collection[SVG_SYNTHETIC_ROOT_PROP] = True
        self._process_element(root, main_collection, context)
        return {"FINISHED"}

    def _process_element(
        self,
        element,
        parent_collection: bpy.types.Collection,
        context: bpy.types.Context,
        path_prefix: str = "",
        inherited_style: dict[str, str] | None = None,
        inherited_transform=IDENTITY_TRANSFORM,
        order_path: tuple[int, ...] = (),
    ) -> None:
        """Process an SVG element and its supported children."""
        tag = _strip_namespace(element.tag)
        combined_style = merge_style_attributes(inherited_style, extract_style_attributes(element, self.css_rules))
        combined_transform = multiply_transforms(
            inherited_transform,
            parse_svg_transform(element.get("transform")),
        )

        if is_hidden_style(combined_style):
            return

        if tag == "svg":
            for child_index, child in enumerate(element, start=1):
                self._process_element(
                    child,
                    parent_collection,
                    context,
                    path_prefix,
                    combined_style,
                    combined_transform,
                    order_path + (child_index,),
                )
            return

        if tag == "g":
            group_id = element.get("id") or self._next_name("group")
            collection_name = f"{path_prefix}{group_id}" if path_prefix else group_id
            group_collection = self._get_or_create_collection(
                collection_name,
                parent_collection,
            )
            group_collection[SVG_GROUP_ID_PROP] = group_id
            if order_path:
                group_collection[SVG_ORDER_PATH_PROP] = _serialize_order_path(order_path)
            new_prefix = f"{group_id}." if not path_prefix else f"{path_prefix}{group_id}."
            for child_index, child in enumerate(element, start=1):
                self._process_element(
                    child,
                    group_collection,
                    context,
                    new_prefix,
                    combined_style,
                    combined_transform,
                    order_path + (child_index,),
                )
            return

        if tag == "image":
            created_objects = self._create_image_plane(element, context, combined_style, combined_transform)
            if not created_objects:
                self._skipped_images += 1
                return

            self._apply_import_height_offsets(created_objects, order_path)
            for obj in created_objects:
                if order_path:
                    obj[SVG_ORDER_PATH_PROP] = _serialize_order_path(order_path)
                if obj.name not in parent_collection.objects:
                    parent_collection.objects.link(obj)
                if obj.name in context.scene.collection.objects:
                    context.scene.collection.objects.unlink(obj)
            return

        if tag not in {"rect", "circle", "ellipse", "line", "path", "polygon", "polyline"}:
            return

        created_objects = self._create_curve_from_element(element, context, combined_style, combined_transform, parent_collection)
        if not created_objects:
            return

        self._apply_import_height_offsets(created_objects, order_path)

        for obj in created_objects:
            if order_path:
                obj[SVG_ORDER_PATH_PROP] = _serialize_order_path(order_path)

            if not obj.get(SVG_SPLIT_COLLECTION_PROP) and obj.name not in parent_collection.objects:
                parent_collection.objects.link(obj)

            if obj.name in context.scene.collection.objects:
                context.scene.collection.objects.unlink(obj)

    def _get_or_create_collection(
        self,
        name: str,
        parent_collection: bpy.types.Collection,
    ) -> bpy.types.Collection:
        """Return an existing collection or create a new one under parent."""
        if name in self.collections:
            return self.collections[name]

        if name in bpy.data.collections:
            collection = bpy.data.collections[name]
        else:
            collection = bpy.data.collections.new(name)

        if collection.name not in parent_collection.children:
            parent_collection.children.link(collection)

        self.collections[name] = collection
        return collection

    # ------------------------------------------------------------------
    # Image element handling
    # ------------------------------------------------------------------

    def _create_image_plane(
        self,
        element,
        context: bpy.types.Context,
        style: dict[str, str] | None,
        transform,
    ) -> list[bpy.types.Object]:
        """Create a textured mesh plane from an SVG ``<image>`` element.

        Returns an empty list when the image cannot be resolved so that
        the caller can skip gracefully.
        """
        href = (
            element.get("href")
            or element.get("{http://www.w3.org/1999/xlink}href")
        )
        if not href:
            return []

        svg_dir = self._svg_directory or Path(".")
        image_bytes, ext = resolve_image_href(href, svg_dir)
        if image_bytes is None:
            return []

        try:
            x = float(element.get("x", 0))
            y = float(element.get("y", 0))
            w = float(element.get("width", 0))
            h = float(element.get("height", 0))
        except (TypeError, ValueError):
            return []

        if w <= 0 or h <= 0:
            return []

        element_id = element.get("id") or self._next_name("image")

        try:
            obj = self._build_image_mesh(element_id, x, y, w, h, transform, context)
            blender_image = self._load_blender_image(element_id, image_bytes, ext)
            material = self._create_image_material(element_id, blender_image)
            obj.data.materials.append(material)

            # Store roundtrip metadata.
            obj[SPECIO_IMAGE_PROP] = True
            obj[SPECIO_IMAGE_HREF_PROP] = href
            obj[SPECIO_IMAGE_X_PROP] = x
            obj[SPECIO_IMAGE_Y_PROP] = y
            obj[SPECIO_IMAGE_W_PROP] = w
            obj[SPECIO_IMAGE_H_PROP] = h
        except Exception:
            return []

        return [obj]

    def _build_image_mesh(
        self,
        name: str,
        x: float,
        y: float,
        w: float,
        h: float,
        transform,
        context: bpy.types.Context,
    ) -> bpy.types.Object:
        """Create a 4-vertex quad mesh positioned from SVG coordinates."""
        from .transform import apply_transform

        scale = self.scale
        # SVG corners in SVG-space then through the inherited transform.
        corners_svg = [
            (x, y),
            (x + w, y),
            (x + w, y + h),
            (x, y + h),
        ]
        verts = []
        for sx, sy in corners_svg:
            tx, ty = apply_transform((sx, sy), transform)
            verts.append((tx * scale, -ty * scale, 0.0))

        import bmesh
        mesh = bpy.data.meshes.new(name)
        bm = bmesh.new()
        try:
            bm_verts = [bm.verts.new(v) for v in verts]
            bm.faces.new(bm_verts)
            bm.faces.ensure_lookup_table()
            # Assign UV so the image maps correctly.
            uv_layer = bm.loops.layers.uv.new("UVMap")
            uv_coords = [(0.0, 1.0), (1.0, 1.0), (1.0, 0.0), (0.0, 0.0)]
            for face in bm.faces:
                for loop, uv in zip(face.loops, uv_coords):
                    loop[uv_layer].uv = uv
            bm.to_mesh(mesh)
        finally:
            bm.free()

        mesh.update()
        obj = bpy.data.objects.new(name, mesh)
        context.scene.collection.objects.link(obj)
        return obj

    def _load_blender_image(
        self,
        name: str,
        image_bytes: bytes,
        extension: str,
    ) -> bpy.types.Image:
        """Load raw image bytes into a packed Blender image data-block."""
        import tempfile, os

        suffix = extension if extension.startswith(".") else f".{extension}"
        fd, tmp_path = tempfile.mkstemp(suffix=suffix)
        try:
            os.write(fd, image_bytes)
            os.close(fd)
            blender_image = bpy.data.images.load(tmp_path, check_existing=False)
            blender_image.name = name
            blender_image.pack()
        finally:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        return blender_image

    @staticmethod
    def _create_image_material(
        name: str,
        blender_image: bpy.types.Image,
    ) -> bpy.types.Material:
        """Create a material with an Image Texture node wired to Principled BSDF."""
        mat = bpy.data.materials.new(name=f"SpecIO_Image_{name}")
        mat.use_nodes = True
        tree = mat.node_tree
        nodes = tree.nodes
        links = tree.links
        nodes.clear()

        output_node = nodes.new("ShaderNodeOutputMaterial")
        output_node.location = (400, 0)

        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (100, 0)

        tex_node = nodes.new("ShaderNodeTexImage")
        tex_node.location = (-300, 0)
        tex_node.image = blender_image

        links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
        if "Alpha" in bsdf.inputs and "Alpha" in tex_node.outputs:
            links.new(tex_node.outputs["Alpha"], bsdf.inputs["Alpha"])
            mat.blend_method = "BLEND" if hasattr(mat, "blend_method") else mat.blend_method

        links.new(bsdf.outputs["BSDF"], output_node.inputs["Surface"])
        return mat

    def _create_curve_from_element(
        self,
        element,
        context: bpy.types.Context,
        style: dict[str, str] | None = None,
        transform=IDENTITY_TRANSFORM,
        parent_collection: bpy.types.Collection | None = None,
    ):
        """Create one or more Blender curve objects from a supported SVG element."""
        tag = _strip_namespace(element.tag)
        element_id = element.get("id") or self._next_name(tag)
        effective_style = self._effective_render_style_for_element(element, style)
        if self._needs_stroke_helper(style):
            fill_render_style = self._fill_render_style(effective_style)
            fill_objects = self._build_curve_objects(
                element,
                element_id,
                context,
                fill_render_style,
                style,
                transform,
                parent_collection,
            )
            if not fill_objects:
                return []

            stroke_render_style = self._stroke_render_style(effective_style)
            stroke_objects = self._build_curve_objects(
                element,
                self._unique_stroke_helper_name(element_id),
                context,
                stroke_render_style,
                stroke_render_style,
                transform,
                parent_collection,
            )
            created_objects = list(fill_objects)
            for stroke_obj in stroke_objects:
                stroke_obj[SVG_STROKE_HELPER_PROP] = True
                stroke_obj[SVG_STROKE_SOURCE_PROP] = element_id
                created_objects.append(stroke_obj)
            return created_objects

        curve_objects = self._build_curve_objects(
            element,
            element_id,
            context,
            effective_style,
            style,
            transform,
            parent_collection,
        )
        return curve_objects

    def _effective_render_style_for_element(
        self,
        element,
        style: dict[str, str] | None,
    ) -> dict[str, str] | None:
        """Return render style augmented with SpecIO-only import hints."""
        import_fill_rule = element.get("data-specio-import-fill-rule")
        if not import_fill_rule:
            return style

        normalized_fill_rule = import_fill_rule.strip().lower()
        if normalized_fill_rule not in {"evenodd", "nonzero"}:
            return style

        if style and style.get("fill-rule"):
            return style

        effective_style = dict(style or {})
        effective_style["fill-rule"] = normalized_fill_rule
        return effective_style

    def _build_curve_objects(
        self,
        element,
        object_name: str,
        context: bpy.types.Context,
        render_style: dict[str, str] | None,
        metadata_style: dict[str, str] | None,
        transform,
        parent_collection: bpy.types.Collection | None = None,
    ) -> list[bpy.types.Object]:
        """Build one or more imported curve objects with separate render and export styles."""
        curve_obj = self.curve_builder.create_curve_from_element(element, object_name, context, transform=transform)
        if curve_obj is None:
            return []

        self._close_effectively_closed_splines(curve_obj.data, render_style)
        split_plan = self._intelligent_evenodd_split_plan(curve_obj.data, render_style)
        if render_style and render_style.get("fill-rule", "").strip().lower() == "evenodd" and not split_plan:
            self._apply_evenodd_fill_winding(curve_obj.data)
        apply_style_metadata(curve_obj, metadata_style)
        apply_curve_style_settings(curve_obj.data, curve_obj, render_style, scale=self.scale)
        self._apply_style_material(curve_obj, render_style)

        if split_plan:
            return self._split_curve_object_by_plan(curve_obj, object_name, context, split_plan, parent_collection)

        return [curve_obj]

    def _intelligent_evenodd_split_plan(
        self,
        curve_data: bpy.types.Curve,
        style: dict[str, str] | None,
    ) -> list[tuple[str, list[int]]]:
        """Return an evenodd split plan based on local contour families.

        The working heuristic is:

        - near-closed cyclic splines are candidates for independent islands
        - long-gap open splines stay with their nearest cyclic container so glyph
          counters and ribbon cut-ins remain attached to the family that defines
          their hole behavior
        - simple all-cyclic nested compounds stay grouped when they look like a
          small classic hole pair, such as an O-shaped counter
        """
        if not self.intelligent_split_paths or not style or not is_fill_enabled(style):
            return []
        if style.get("fill-rule", "").strip().lower() != "evenodd":
            return []
        spline_count = len(getattr(curve_data, "splines", []))
        if spline_count < 2:
            return []

        spline_infos = self._spline_split_infos(curve_data)
        cyclic_indices = [info["index"] for info in spline_infos if info["cyclic"]]
        if not cyclic_indices:
            return []
        if len(cyclic_indices) == spline_count:
            has_nested_cyclic = any(info["nearest_cyclic_parent"] is not None for info in spline_infos)
            if spline_count <= 4 and has_nested_cyclic:
                return []
            return self._independent_split_plan(curve_data)

        child_groups: dict[int, list[int]] = {}
        plan: list[tuple[str, list[int]]] = []
        assigned_indices: set[int] = set()

        for info in spline_infos:
            if info["cyclic"]:
                continue
            parent_index = info["nearest_cyclic_parent"]
            if parent_index is None:
                plan.append(("independent", [info["index"]]))
                assigned_indices.add(info["index"])
                continue
            child_groups.setdefault(parent_index, []).append(info["index"])

        for cyclic_index in cyclic_indices:
            member_indices = [cyclic_index, *sorted(child_groups.get(cyclic_index, []))]
            if len(member_indices) > 1:
                plan.append(("evenodd", member_indices))
            else:
                plan.append(("independent", [cyclic_index]))
            assigned_indices.update(member_indices)

        for info in spline_infos:
            if info["index"] not in assigned_indices:
                plan.append(("independent", [info["index"]]))

        plan.sort(key=lambda item: item[1][0])
        return plan if len(plan) > 1 else []

    def _spline_split_infos(self, curve_data: bpy.types.Curve) -> list[dict[str, object]]:
        """Return per-spline geometry used to build intelligent split families."""
        splines = list(getattr(curve_data, "splines", []))
        polygons = [_spline_sample_polygon(spline) for spline in splines]
        bounds = [_polygon_bbox(polygon) for polygon in polygons]
        representative_points = [_representative_polygon_point(polygon) for polygon in polygons]
        areas = [abs(_polygon_area(polygon)) for polygon in polygons]
        infos: list[dict[str, object]] = []

        cyclic_indices = [index for index, spline in enumerate(splines) if spline.use_cyclic_u]
        for index, spline in enumerate(splines):
            point = representative_points[index]
            nearest_cyclic_parent = None
            candidate_parents: list[tuple[float, int]] = []
            if point is not None:
                for candidate_index in cyclic_indices:
                    if candidate_index == index:
                        continue
                    candidate_polygon = polygons[candidate_index]
                    candidate_bounds = bounds[candidate_index]
                    if len(candidate_polygon) < 3 or candidate_bounds is None:
                        continue
                    min_x, min_y, max_x, max_y = candidate_bounds
                    if not (min_x <= point[0] <= max_x and min_y <= point[1] <= max_y):
                        continue
                    if _point_in_polygon(point, candidate_polygon):
                        candidate_parents.append((areas[candidate_index], candidate_index))

            if candidate_parents:
                nearest_cyclic_parent = min(candidate_parents)[1]

            infos.append(
                {
                    "index": index,
                    "cyclic": bool(spline.use_cyclic_u),
                    "nearest_cyclic_parent": nearest_cyclic_parent,
                }
            )

        return infos

    def _independent_split_plan(self, curve_data: bpy.types.Curve) -> list[tuple[str, list[int]]]:
        """Return a per-spline split plan for an existing multi-spline curve."""
        spline_count = len(getattr(curve_data, "splines", []))
        if spline_count < 2:
            return []
        return [("independent", [index]) for index in range(spline_count)]

    def split_curve_object(
        self,
        curve_obj: bpy.types.Object,
        context: bpy.types.Context,
        parent_collection: bpy.types.Collection | None = None,
    ) -> list[bpy.types.Object]:
        """Split an imported curve object using intelligent families or a spline fallback."""
        if curve_obj is None or curve_obj.type != "CURVE" or curve_obj.data is None:
            return []

        metadata_style = extract_style_metadata(curve_obj)
        split_plan = self._intelligent_evenodd_split_plan(curve_obj.data, metadata_style)
        if not split_plan:
            split_plan = self._independent_split_plan(curve_obj.data)
        if not split_plan:
            return []

        resolved_parent = parent_collection or self._preferred_parent_collection(curve_obj, context.scene.collection)
        return self._split_curve_object_by_plan(curve_obj, curve_obj.name, context, split_plan, resolved_parent)

    def _split_curve_object_by_plan(
        self,
        curve_obj: bpy.types.Object,
        base_name: str,
        context: bpy.types.Context,
        split_plan: list[tuple[str, list[int]]],
        parent_collection: bpy.types.Collection | None = None,
    ) -> list[bpy.types.Object]:
        """Split a multi-spline curve object according to a group plan."""
        source_curve = curve_obj.data
        split_objects: list[bpy.types.Object] = []
        primary_index = 0
        split_collection = None
        if parent_collection is not None:
            split_collection = self._get_or_create_split_collection(base_name, parent_collection)

        for plan_index, (group_kind, spline_indices) in enumerate(split_plan):
            split_obj = curve_obj.copy()
            split_obj.name = self._unique_split_object_name(base_name, plan_index + 1)
            split_obj.data = source_curve.copy()
            split_obj.data.name = split_obj.name

            keep_indices = set(spline_indices)
            for remove_index in range(len(split_obj.data.splines) - 1, -1, -1):
                if remove_index not in keep_indices:
                    split_obj.data.splines.remove(split_obj.data.splines[remove_index])

            if group_kind == "evenodd":
                self._apply_evenodd_fill_winding(split_obj.data)

            if split_collection is not None:
                split_collection.objects.link(split_obj)
                split_obj[SVG_SPLIT_COLLECTION_PROP] = split_collection.name
            else:
                context.scene.collection.objects.link(split_obj)
            split_objects.append(split_obj)

        bpy.data.objects.remove(curve_obj, do_unlink=True)
        bpy.data.curves.remove(source_curve, do_unlink=True)

        if split_objects:
            split_objects[primary_index].name = base_name
            split_objects[primary_index].data.name = base_name

        return split_objects

    def _preferred_parent_collection(
        self,
        curve_obj: bpy.types.Object,
        scene_collection: bpy.types.Collection,
    ) -> bpy.types.Collection:
        """Return the most useful parent collection for a split object."""
        for collection in curve_obj.users_collection:
            if collection != scene_collection:
                return collection
        if curve_obj.users_collection:
            return curve_obj.users_collection[0]
        return scene_collection

    def _needs_stroke_helper(self, style: dict[str, str] | None) -> bool:
        """Return whether an element should import as separate fill and stroke objects."""
        return is_fill_enabled(style) and is_stroke_enabled(style)

    def _fill_render_style(self, style: dict[str, str] | None) -> dict[str, str] | None:
        """Return the render style for the base filled object when stroke is split out."""
        if not style:
            return style

        render_style = dict(style)
        render_style["stroke"] = "none"
        return render_style

    def _stroke_render_style(self, style: dict[str, str] | None) -> dict[str, str] | None:
        """Return the render style for the synthetic stroke helper object."""
        if not style:
            return {"fill": "none"}

        stroke_style = {"fill": "none"}
        for key in ("stroke", "stroke-width", "stroke-linecap", "stroke-linejoin"):
            value = style.get(key)
            if value:
                stroke_style[key] = value
        return stroke_style

    def _unique_stroke_helper_name(self, base_name: str) -> str:
        """Return a deterministic object name for a synthetic stroke helper."""
        candidate = f"{base_name}__stroke"
        if candidate not in bpy.data.objects and candidate not in bpy.data.curves:
            return candidate

        suffix = 1
        while True:
            suffixed_candidate = f"{candidate}_{suffix:03d}"
            if suffixed_candidate not in bpy.data.objects and suffixed_candidate not in bpy.data.curves:
                return suffixed_candidate
            suffix += 1

    def _unique_split_object_name(self, base_name: str, spline_index: int) -> str:
        """Return a deterministic object name for a split spline object."""
        candidate = f"{base_name}__part_{spline_index:03d}"
        if candidate not in bpy.data.objects and candidate not in bpy.data.curves:
            return candidate

        suffix = 1
        while True:
            suffixed_candidate = f"{candidate}_{suffix:03d}"
            if suffixed_candidate not in bpy.data.objects and suffixed_candidate not in bpy.data.curves:
                return suffixed_candidate
            suffix += 1

    def _unique_split_collection_name(self, base_name: str) -> str:
        """Return a deterministic collection name for split path parts."""
        candidate = f"{base_name}__split"
        if candidate not in bpy.data.collections:
            return candidate

        suffix = 1
        while True:
            suffixed_candidate = f"{candidate}_{suffix:03d}"
            if suffixed_candidate not in bpy.data.collections:
                return suffixed_candidate
            suffix += 1

    def _get_or_create_split_collection(
        self,
        base_name: str,
        parent_collection: bpy.types.Collection,
    ) -> bpy.types.Collection:
        """Create a dedicated child collection for intelligently split path parts."""
        split_name = self._unique_split_collection_name(base_name)
        return self._get_or_create_collection(split_name, parent_collection)

    def _apply_import_height_offsets(
        self,
        created_objects: list[bpy.types.Object],
        order_path: tuple[int, ...],
    ) -> None:
        """Apply optional Z offsets to imported objects to reduce z-fighting."""
        if not created_objects:
            return

        base_z = self._base_height_for_order_path(order_path)
        stroke_overlay = self._stroke_overlay_offset()
        for obj in created_objects:
            obj.location.z = base_z + (stroke_overlay if obj.get(SVG_STROKE_HELPER_PROP) else 0.0)

    def _base_height_for_order_path(self, order_path: tuple[int, ...]) -> float:
        """Return the base Z height for an imported SVG element according to user settings."""
        resolved_step = self._resolved_height_step()
        if self.height_mode == "PER_OBJECT":
            base_z = self._import_object_index * resolved_step
            self._import_object_index += 1
            return base_z

        if self.height_mode == "PER_LAYER":
            layer_index = max((order_path[0] - 1) if order_path else 0, 0)
            return layer_index * resolved_step

        return 0.0

    def _stroke_overlay_offset(self) -> float:
        """Return a small overlay offset so synthetic stroke helpers sit above fill objects."""
        return self._document_size_units * self.stroke_overlay_offset

    def _resolved_height_step(self) -> float:
        """Return the effective Z step in imported Blender units."""
        return self._document_size_units * self.height_step

    def _document_size_in_blender_units(self, root) -> float:
        """Return the imported SVG document size in Blender units."""
        return max(self._document_size_from_root(root) * self.scale, 1.0)

    def _document_size_from_root(self, root) -> float:
        """Return a representative SVG document size from viewBox or width and height."""
        sizes: list[float] = []

        view_box = root.get("viewBox")
        if view_box:
            parts = [parse_numeric_style_value(part) for part in view_box.replace(",", " ").split()]
            if len(parts) >= 4:
                view_box_width = parts[2]
                view_box_height = parts[3]
                if view_box_width is not None and view_box_width > 0:
                    sizes.append(abs(view_box_width))
                if view_box_height is not None and view_box_height > 0:
                    sizes.append(abs(view_box_height))

        width = parse_numeric_style_value(root.get("width"))
        height = parse_numeric_style_value(root.get("height"))
        if width is not None and width > 0:
            sizes.append(abs(width))
        if height is not None and height > 0:
            sizes.append(abs(height))

        return max(sizes) if sizes else 1.0

    def _next_name(self, prefix: str) -> str:
        """Return a deterministic fallback name for unnamed SVG elements."""
        count = self._name_counters.get(prefix, 0) + 1
        self._name_counters[prefix] = count
        return f"{prefix}_{count:03d}"

    def _parse_css_rules(self, root) -> CSSRules:
        """Parse CSS rules from ``<style>`` elements in the SVG tree."""
        combined = CSSRules()
        for elem in root.iter():
            if _strip_namespace(elem.tag) == "style" and elem.text:
                parsed = parse_css_style_block(elem.text)
                for tag, props in parsed.by_element.items():
                    combined.by_element.setdefault(tag, {}).update(props)
                for cls, props in parsed.by_class.items():
                    combined.by_class.setdefault(cls, {}).update(props)
                for id_val, props in parsed.by_id.items():
                    combined.by_id.setdefault(id_val, {}).update(props)
        return combined

    def _apply_style_material(self, curve_obj, style: dict[str, str] | None) -> None:
        """Assign a reusable solid or gradient material from SVG paint semantics."""
        fill_value = style.get("fill") if style else None
        stroke_value = style.get("stroke") if style else None
        fill_paint = extract_paint_server_id(fill_value)
        stroke_paint = extract_paint_server_id(stroke_value)
        gradient = None
        paint_role = None
        if fill_paint and fill_value and fill_value.strip().lower() != "none":
            gradient = self.gradients.get(fill_paint)
            paint_role = "fill"
        elif stroke_paint and stroke_value and stroke_value.strip().lower() != "none":
            gradient = self.gradients.get(stroke_paint)
            paint_role = "stroke"

        if gradient is not None and paint_role is not None:
            material = create_gradient_material(curve_obj, gradient, self.scale, paint_role)
            curve_obj.color = average_gradient_color(gradient)
            if curve_obj.data.materials:
                curve_obj.data.materials[0] = material
            else:
                curve_obj.data.materials.append(material)
            return

        material_color = self._resolve_solid_material_color(curve_obj, style)
        if material_color is None:
            return

        material_name = self._material_name_for_color(material_color)
        material = bpy.data.materials.get(material_name)
        if material is None:
            material = bpy.data.materials.new(name=material_name)

        self._configure_solid_material(material, material_color)

        if curve_obj.data.materials:
            curve_obj.data.materials[0] = material
        else:
            curve_obj.data.materials.append(material)

    def _resolve_solid_material_color(
        self,
        curve_obj,
        style: dict[str, str] | None,
    ) -> tuple[float, float, float, float] | None:
        """Choose the solid material color that best represents the imported SVG paint."""
        style_map = style or {}
        fill_value = style_map.get("fill")
        stroke_value = style_map.get("stroke")
        prefers_fill = getattr(getattr(curve_obj, "data", None), "dimensions", "2D") != "3D"

        if prefers_fill:
            if fill_value is None:
                return (0.0, 0.0, 0.0, 1.0)

            fill_color = parse_color_value(fill_value)
            if fill_color is not None:
                return fill_color

        if stroke_value and stroke_value.strip().lower() != "none":
            stroke_color = parse_color_value(stroke_value)
            if stroke_color is not None:
                return stroke_color

        return None

    def _configure_solid_material(
        self,
        material: bpy.types.Material,
        rgba: tuple[float, float, float, float],
    ) -> None:
        """Configure a reusable node-based material for a solid SVG paint color."""
        material.use_nodes = True
        node_tree = material.node_tree
        nodes = node_tree.nodes
        links = node_tree.links
        nodes.clear()

        output = nodes.new("ShaderNodeOutputMaterial")
        output.location = (300, 0)
        shader = nodes.new("ShaderNodeBsdfPrincipled")
        shader.location = (0, 0)
        shader.inputs["Base Color"].default_value = rgba
        if "Alpha" in shader.inputs:
            shader.inputs["Alpha"].default_value = rgba[3]
        links.new(shader.outputs["BSDF"], output.inputs["Surface"])

        material.diffuse_color = rgba
        if hasattr(material, "blend_method"):
            material.blend_method = "BLEND" if rgba[3] < 0.999 else "OPAQUE"

    def _apply_evenodd_fill_winding(self, curve_data: bpy.types.Curve) -> None:
        """Flip inner spline winding so SVG fill-rule:evenodd creates correct holes in Blender.

        Blender 2D curves produce holes when a cyclic spline nested inside another
        has the opposite winding direction.  SVG's evenodd rule instead uses the
        parity of the crossing count regardless of winding, so SVG compound paths
        often have all sub-paths wound the same way yet rely on evenodd to identify
        holes.  This method detects each cyclic spline's nesting depth and reverses
        the winding of those at an odd depth, translating evenodd semantics to the
        Blender winding-based model.
        """
        cyclic_splines = [s for s in curve_data.splines if s.use_cyclic_u]
        if len(cyclic_splines) < 2:
            return

        polygons = [_spline_sample_polygon(s) for s in cyclic_splines]

        for i, spline in enumerate(cyclic_splines):
            poly = polygons[i]
            if not poly:
                continue
            # Use the geometric midpoint of the first Bezier segment (t=0.5) as the
            # nesting sample instead of the first anchor point.  The first anchor is
            # on the curve boundary, which makes the point-in-polygon test sensitive
            # to which side of an adjacent edge it lands on.  The segment midpoint
            # sits slightly inside the curve for convex shapes and stays near the
            # path start, keeping it away from the centroid region where large
            # spanning paths might otherwise be falsely detected as nested inside a
            # compact neighbour.
            if spline.type == "BEZIER" and len(spline.bezier_points) >= 2:
                p0 = spline.bezier_points[0]
                p1 = spline.bezier_points[1]
                sample = (
                    0.125 * p0.co.x + 0.375 * p0.handle_right.x + 0.375 * p1.handle_left.x + 0.125 * p1.co.x,
                    0.125 * p0.co.y + 0.375 * p0.handle_right.y + 0.375 * p1.handle_left.y + 0.125 * p1.co.y,
                )
            else:
                sample = poly[0]
            nesting_depth = sum(
                1
                for j, other_poly in enumerate(polygons)
                if j != i and len(other_poly) >= 3 and _point_in_polygon(sample, other_poly)
            )
            if nesting_depth % 2 == 1:
                _reverse_spline_winding(spline)

    def _close_effectively_closed_splines(
        self,
        curve_data: bpy.types.Curve,
        style: dict[str, str] | None,
    ) -> None:
        """Close splines that return to their start point when SVG fill semantics need them filled."""
        if curve_data is None or not (is_fill_enabled(style) or is_stroke_enabled(style)):
            return

        # SVG vector tools sometimes emit paths whose last point is within a tiny
        # floating-point rounding distance of the first point even though no Z command
        # was written.  Treat these as closed when the Euclidean gap is less than
        # 1.0 SVG unit (scaled to Blender space).  A plain Z-closed path produces an
        # exact match (gap == 0) so it is always caught.
        close_threshold_sq = (1.0 * self.scale) ** 2

        for spline in getattr(curve_data, "splines", []):
            if getattr(spline, "use_cyclic_u", False):
                continue

            endpoints = self._spline_endpoints_2d(spline)
            if endpoints is None:
                continue

            start, end = endpoints
            gap_sq = (start[0] - end[0]) ** 2 + (start[1] - end[1]) ** 2
            if gap_sq <= close_threshold_sq:
                spline.use_cyclic_u = True

    def _spline_endpoints_2d(self, spline) -> tuple[tuple[float, float], tuple[float, float]] | None:
        """Return the first and last 2D spline points for poly and bezier splines."""
        if hasattr(spline, "bezier_points") and len(spline.bezier_points) > 1:
            first = spline.bezier_points[0].co
            last = spline.bezier_points[-1].co
            return (float(first.x), float(first.y)), (float(last.x), float(last.y))

        if hasattr(spline, "points") and len(spline.points) > 1:
            first = spline.points[0].co
            last = spline.points[-1].co
            return (float(first.x), float(first.y)), (float(last.x), float(last.y))

        return None

    def _material_name_for_color(self, rgba: tuple[float, float, float, float]) -> str:
        """Return a deterministic shared material name for an imported solid color."""
        encoded = "".join(f"{round(max(0.0, min(channel, 1.0)) * 255):02X}" for channel in rgba)
        return f"SpecIO_Display_{encoded}"
"""Blender material generation and managed-material helpers for SVG gradients."""

from __future__ import annotations

import re

import bpy

from .gradients import SVGGradient, SVGGradientStop, average_gradient_color, gradient_from_payload, gradient_to_payload, payload_from_json, payload_to_json
from .transform import IDENTITY_TRANSFORM, invert_transform


SPECIO_GRADIENT_PAYLOAD_KEY = "specio_gradient_payload"
SPECIO_GRADIENT_ID_KEY = "specio_gradient_id"
SPECIO_GRADIENT_KIND_KEY = "specio_gradient_kind"
SPECIO_GRADIENT_UNITS_KEY = "specio_gradient_units"
SPECIO_GRADIENT_SPREAD_KEY = "specio_gradient_spread"
SPECIO_GRADIENT_ROLE_KEY = "specio_gradient_role"
SPECIO_GRADIENT_UPDATE_GUARD = "_specio_suspend_gradient_updates"


def create_gradient_material(
    obj: bpy.types.Object,
    gradient: SVGGradient,
    scale: float,
    paint_role: str,
):
    """Create or replace a Blender material node tree for a resolved SVG gradient."""
    material_name = f"SpecIO_{obj.name}_{paint_role}_{gradient.gradient_id}"
    material = bpy.data.materials.get(material_name)
    if material is None:
        material = bpy.data.materials.new(name=material_name)

    configure_material_from_gradient(material, obj, gradient, scale, paint_role)
    _sync_material_property_group(material, gradient, paint_role)
    return material


def configure_material_from_gradient(
    material: bpy.types.Material,
    obj: bpy.types.Object,
    gradient: SVGGradient,
    scale: float,
    paint_role: str,
) -> bpy.types.Material:
    """Configure a Blender material to preview a resolved SVG gradient."""

    material.use_nodes = True
    node_tree = material.node_tree
    nodes = node_tree.nodes
    links = node_tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (900, 0)
    shader = nodes.new("ShaderNodeBsdfPrincipled")
    shader.location = (650, 0)
    links.new(shader.outputs["BSDF"], output.inputs["Surface"])

    coordinates = _build_gradient_coordinates(node_tree, links, obj, gradient, scale)
    if gradient.kind == "linear":
        fac_socket = _build_linear_factor(node_tree, links, coordinates, gradient)
    else:
        fac_socket = _build_radial_factor(node_tree, links, coordinates, gradient)

    fac_socket = _apply_spread_method(node_tree, links, fac_socket, gradient.spread_method)

    color_ramp = nodes.new("ShaderNodeValToRGB")
    color_ramp.location = (420, 40)
    _configure_color_ramp(color_ramp.color_ramp, gradient)
    links.new(fac_socket, color_ramp.inputs["Fac"])
    links.new(color_ramp.outputs["Color"], shader.inputs["Base Color"])

    representative = average_gradient_color(gradient)
    material.diffuse_color = representative
    material[SPECIO_GRADIENT_ID_KEY] = gradient.gradient_id
    material[SPECIO_GRADIENT_KIND_KEY] = gradient.kind
    material[SPECIO_GRADIENT_UNITS_KEY] = gradient.gradient_units
    material[SPECIO_GRADIENT_SPREAD_KEY] = gradient.spread_method
    material[SPECIO_GRADIENT_ROLE_KEY] = paint_role
    material[SPECIO_GRADIENT_PAYLOAD_KEY] = payload_to_json(gradient_to_payload(gradient, paint_target=paint_role))
    return material


def sync_specio_gradient_material(material: bpy.types.Material, obj: bpy.types.Object | None = None, scale: float = 1.0) -> None:
    """Rebuild the preview node tree from managed material properties."""
    if material.get(SPECIO_GRADIENT_UPDATE_GUARD):
        return

    props = getattr(material, "specio_gradient", None)
    if props is None or not props.enabled:
        return

    target_object = obj or _first_curve_user(material)
    if target_object is None:
        return

    gradient = managed_properties_to_gradient(material)
    configure_material_from_gradient(material, target_object, gradient, scale, props.paint_target)


def managed_properties_to_gradient(material: bpy.types.Material) -> SVGGradient:
    """Convert managed SpecIO material properties into an SVGGradient instance."""
    props = material.specio_gradient
    stops = [
        SVGGradientStop(props.start_offset, (*props.start_color, props.start_alpha)),
        SVGGradientStop(props.end_offset, (*props.end_color, props.end_alpha)),
    ]
    gradient_id = props.gradient_id.strip() or _default_gradient_id(material.name)
    if props.gradient_type == "LINEAR":
        return SVGGradient(
            gradient_id=gradient_id,
            kind="linear",
            gradient_units="objectBoundingBox",
            spread_method=props.spread_method,
            transform=IDENTITY_TRANSFORM,
            x1=props.linear_x1,
            y1=props.linear_y1,
            x2=props.linear_x2,
            y2=props.linear_y2,
            stops=sorted(stops, key=lambda stop: stop.offset),
        )

    return SVGGradient(
        gradient_id=gradient_id,
        kind="radial",
        gradient_units="objectBoundingBox",
        spread_method=props.spread_method,
        transform=IDENTITY_TRANSFORM,
        cx=props.radial_cx,
        cy=props.radial_cy,
        r=props.radial_r,
        fx=props.radial_fx,
        fy=props.radial_fy,
        stops=sorted(stops, key=lambda stop: stop.offset),
    )


def material_gradient_payload(material: bpy.types.Material | None) -> dict[str, object] | None:
    """Return the export payload for a managed or imported SpecIO gradient material.

    The stored JSON payload is preferred when present because it carries the full
    gradient definition (all stops, original gradientUnits, gradientTransform) for
    both imported and user-edited materials.  Managed property state is used only
    as a fallback when no JSON has been persisted yet.
    """
    if material is None:
        return None

    payload = payload_from_json(material.get(SPECIO_GRADIENT_PAYLOAD_KEY))
    if payload is not None:
        return payload

    if getattr(material, "specio_gradient", None) is not None and material.specio_gradient.enabled:
        return gradient_to_payload(managed_properties_to_gradient(material), paint_target=material.specio_gradient.paint_target.lower())

    return None


def _sync_material_property_group(material: bpy.types.Material, gradient: SVGGradient, paint_role: str) -> None:
    props = getattr(material, "specio_gradient", None)
    if props is None:
        return

    material[SPECIO_GRADIENT_UPDATE_GUARD] = True
    try:
        props.enabled = True
        props.paint_target = paint_role.upper()
        props.gradient_id = gradient.gradient_id
        props.gradient_type = gradient.kind.upper()
        props.spread_method = gradient.spread_method
        first = (gradient.stops or [SVGGradientStop(0.0, (1.0, 1.0, 1.0, 1.0))])[0]
        last = (gradient.stops or [SVGGradientStop(1.0, (0.0, 0.0, 0.0, 1.0))])[-1]
        props.start_offset = first.offset
        props.end_offset = last.offset
        props.start_color = first.color[:3]
        props.start_alpha = first.color[3]
        props.end_color = last.color[:3]
        props.end_alpha = last.color[3]
        props.linear_x1 = gradient.x1 if gradient.x1 is not None else 0.0
        props.linear_y1 = gradient.y1 if gradient.y1 is not None else 0.0
        props.linear_x2 = gradient.x2 if gradient.x2 is not None else 1.0
        props.linear_y2 = gradient.y2 if gradient.y2 is not None else 0.0
        props.radial_cx = gradient.cx if gradient.cx is not None else 0.5
        props.radial_cy = gradient.cy if gradient.cy is not None else 0.5
        props.radial_r = gradient.r if gradient.r is not None else 0.5
        props.radial_fx = gradient.fx if gradient.fx is not None else props.radial_cx
        props.radial_fy = gradient.fy if gradient.fy is not None else props.radial_cy
    finally:
        material[SPECIO_GRADIENT_UPDATE_GUARD] = False


def _default_gradient_id(material_name: str) -> str:
    sanitized = re.sub(r"[^A-Za-z0-9_]+", "_", material_name).strip("_")
    return sanitized or "specioGradient"


def _first_curve_user(material: bpy.types.Material) -> bpy.types.Object | None:
    for obj in bpy.data.objects:
        if obj.type != "CURVE" or not obj.data:
            continue
        if material in obj.data.materials[:]:
            return obj
    return None


def _build_gradient_coordinates(node_tree, links, obj, gradient: SVGGradient, scale: float):
    geometry = node_tree.nodes.new("ShaderNodeNewGeometry")
    geometry.location = (-1800, 200)

    to_object = node_tree.nodes.new("ShaderNodeVectorTransform")
    to_object.location = (-1550, 200)
    to_object.convert_from = "WORLD"
    to_object.convert_to = "OBJECT"
    to_object.vector_type = "POINT"
    links.new(geometry.outputs["Position"], to_object.inputs["Vector"])

    object_space = _convert_object_to_svg_space(node_tree, links, to_object.outputs["Vector"], scale)
    if gradient.gradient_units == "objectBoundingBox":
        min_x, min_y, max_x, max_y = _local_bounds_svg(obj, scale)
        width = max(max_x - min_x, 1e-6)
        height = max(max_y - min_y, 1e-6)
        object_space = _normalize_object_bbox_space(node_tree, links, object_space, min_x, min_y, width, height)

    inverse_transform = invert_transform(gradient.transform)
    return _apply_affine_transform(node_tree, links, object_space, inverse_transform)


def _convert_object_to_svg_space(node_tree, links, vector_socket, scale: float):
    separate = node_tree.nodes.new("ShaderNodeSeparateXYZ")
    separate.location = (-1320, 200)
    links.new(vector_socket, separate.inputs["Vector"])

    scale_x = node_tree.nodes.new("ShaderNodeMath")
    scale_x.location = (-1100, 280)
    scale_x.operation = "MULTIPLY"
    scale_x.inputs[1].default_value = 1.0 / max(scale, 1e-12)
    links.new(separate.outputs["X"], scale_x.inputs[0])

    scale_y = node_tree.nodes.new("ShaderNodeMath")
    scale_y.location = (-1100, 200)
    scale_y.operation = "MULTIPLY"
    scale_y.inputs[1].default_value = -1.0 / max(scale, 1e-12)
    links.new(separate.outputs["Y"], scale_y.inputs[0])

    combine = node_tree.nodes.new("ShaderNodeCombineXYZ")
    combine.location = (-860, 200)
    links.new(scale_x.outputs[0], combine.inputs["X"])
    links.new(scale_y.outputs[0], combine.inputs["Y"])
    return combine.outputs["Vector"]


def _normalize_object_bbox_space(node_tree, links, vector_socket, min_x: float, min_y: float, width: float, height: float):
    separate = node_tree.nodes.new("ShaderNodeSeparateXYZ")
    separate.location = (-620, 200)
    links.new(vector_socket, separate.inputs["Vector"])

    x_offset = node_tree.nodes.new("ShaderNodeMath")
    x_offset.location = (-400, 280)
    x_offset.operation = "SUBTRACT"
    x_offset.inputs[1].default_value = min_x
    links.new(separate.outputs["X"], x_offset.inputs[0])

    x_scale = node_tree.nodes.new("ShaderNodeMath")
    x_scale.location = (-180, 280)
    x_scale.operation = "DIVIDE"
    x_scale.inputs[1].default_value = width
    links.new(x_offset.outputs[0], x_scale.inputs[0])

    y_offset = node_tree.nodes.new("ShaderNodeMath")
    y_offset.location = (-400, 180)
    y_offset.operation = "SUBTRACT"
    y_offset.inputs[1].default_value = min_y
    links.new(separate.outputs["Y"], y_offset.inputs[0])

    y_scale = node_tree.nodes.new("ShaderNodeMath")
    y_scale.location = (-180, 180)
    y_scale.operation = "DIVIDE"
    y_scale.inputs[1].default_value = height
    links.new(y_offset.outputs[0], y_scale.inputs[0])

    combine = node_tree.nodes.new("ShaderNodeCombineXYZ")
    combine.location = (40, 200)
    links.new(x_scale.outputs[0], combine.inputs["X"])
    links.new(y_scale.outputs[0], combine.inputs["Y"])
    return combine.outputs["Vector"]


def _apply_affine_transform(node_tree, links, vector_socket, transform):
    separate = node_tree.nodes.new("ShaderNodeSeparateXYZ")
    separate.location = (280, 200)
    links.new(vector_socket, separate.inputs["Vector"])

    x_socket = _build_affine_component(node_tree, links, separate.outputs["X"], separate.outputs["Y"], transform[0], transform[2], transform[4], (520, 260))
    y_socket = _build_affine_component(node_tree, links, separate.outputs["X"], separate.outputs["Y"], transform[1], transform[3], transform[5], (520, 120))

    combine = node_tree.nodes.new("ShaderNodeCombineXYZ")
    combine.location = (760, 200)
    links.new(x_socket, combine.inputs["X"])
    links.new(y_socket, combine.inputs["Y"])
    return combine.outputs["Vector"]


def _build_affine_component(node_tree, links, x_socket, y_socket, coefficient_x: float, coefficient_y: float, offset: float, location):
    multiply_x = node_tree.nodes.new("ShaderNodeMath")
    multiply_x.location = location
    multiply_x.operation = "MULTIPLY"
    multiply_x.inputs[1].default_value = coefficient_x
    links.new(x_socket, multiply_x.inputs[0])

    multiply_y = node_tree.nodes.new("ShaderNodeMath")
    multiply_y.location = (location[0], location[1] - 80)
    multiply_y.operation = "MULTIPLY"
    multiply_y.inputs[1].default_value = coefficient_y
    links.new(y_socket, multiply_y.inputs[0])

    add_terms = node_tree.nodes.new("ShaderNodeMath")
    add_terms.location = (location[0] + 180, location[1] - 40)
    add_terms.operation = "ADD"
    links.new(multiply_x.outputs[0], add_terms.inputs[0])
    links.new(multiply_y.outputs[0], add_terms.inputs[1])

    translate = node_tree.nodes.new("ShaderNodeMath")
    translate.location = (location[0] + 360, location[1] - 40)
    translate.operation = "ADD"
    translate.inputs[1].default_value = offset
    links.new(add_terms.outputs[0], translate.inputs[0])
    return translate.outputs[0]


def _build_linear_factor(node_tree, links, vector_socket, gradient: SVGGradient):
    separate = node_tree.nodes.new("ShaderNodeSeparateXYZ")
    separate.location = (980, 200)
    links.new(vector_socket, separate.inputs["Vector"])

    x_start = node_tree.nodes.new("ShaderNodeMath")
    x_start.location = (1200, 280)
    x_start.operation = "SUBTRACT"
    x_start.inputs[1].default_value = gradient.x1 or 0.0
    links.new(separate.outputs["X"], x_start.inputs[0])

    y_start = node_tree.nodes.new("ShaderNodeMath")
    y_start.location = (1200, 180)
    y_start.operation = "SUBTRACT"
    y_start.inputs[1].default_value = gradient.y1 or 0.0
    links.new(separate.outputs["Y"], y_start.inputs[0])

    delta_x = (gradient.x2 or 0.0) - (gradient.x1 or 0.0)
    delta_y = (gradient.y2 or 0.0) - (gradient.y1 or 0.0)

    x_project = node_tree.nodes.new("ShaderNodeMath")
    x_project.location = (1420, 280)
    x_project.operation = "MULTIPLY"
    x_project.inputs[1].default_value = delta_x
    links.new(x_start.outputs[0], x_project.inputs[0])

    y_project = node_tree.nodes.new("ShaderNodeMath")
    y_project.location = (1420, 180)
    y_project.operation = "MULTIPLY"
    y_project.inputs[1].default_value = delta_y
    links.new(y_start.outputs[0], y_project.inputs[0])

    add = node_tree.nodes.new("ShaderNodeMath")
    add.location = (1640, 240)
    add.operation = "ADD"
    links.new(x_project.outputs[0], add.inputs[0])
    links.new(y_project.outputs[0], add.inputs[1])

    divide = node_tree.nodes.new("ShaderNodeMath")
    divide.location = (1860, 240)
    divide.operation = "DIVIDE"
    divide.inputs[1].default_value = max(delta_x * delta_x + delta_y * delta_y, 1e-6)
    links.new(add.outputs[0], divide.inputs[0])
    return divide.outputs[0]


def _build_radial_factor(node_tree, links, vector_socket, gradient: SVGGradient):
    separate = node_tree.nodes.new("ShaderNodeSeparateXYZ")
    separate.location = (980, 200)
    links.new(vector_socket, separate.inputs["Vector"])

    fx = gradient.fx if gradient.fx is not None else gradient.cx or 0.5
    fy = gradient.fy if gradient.fy is not None else gradient.cy or 0.5
    cx = gradient.cx or 0.5
    cy = gradient.cy or 0.5
    radius = max(gradient.r or 0.5, 1e-6)

    vx = _offset_component(node_tree, links, separate.outputs["X"], fx, (1200, 320))
    vy = _offset_component(node_tree, links, separate.outputs["Y"], fy, (1200, 220))

    fcx = fx - cx
    fcy = fy - cy

    vx2 = _multiply_socket(node_tree, links, vx, 1.0, (1420, 360))
    vy2 = _multiply_socket(node_tree, links, vy, 1.0, (1420, 260))
    a = _sum_of_squares(node_tree, links, vx2, vy2, (1640, 300))

    dot_x = _multiply_socket(node_tree, links, vx, fcx, (1420, 140))
    dot_y = _multiply_socket(node_tree, links, vy, fcy, (1420, 40))
    dot = _add_sockets(node_tree, links, dot_x, dot_y, (1640, 90))
    b = _multiply_socket(node_tree, links, dot, 2.0, (1860, 90))

    c_value = fcx * fcx + fcy * fcy - radius * radius

    b2 = _multiply_sockets(node_tree, links, b, b, (2080, 90))
    four_a = _multiply_socket(node_tree, links, a, 4.0, (1860, 300))
    four_ac = _multiply_socket(node_tree, links, four_a, c_value, (2080, 300))
    discriminant = _subtract_sockets(node_tree, links, b2, four_ac, (2300, 190))
    max_disc = node_tree.nodes.new("ShaderNodeMath")
    max_disc.location = (2520, 190)
    max_disc.operation = "MAXIMUM"
    max_disc.inputs[1].default_value = 0.0
    links.new(discriminant, max_disc.inputs[0])

    sqrt_disc = node_tree.nodes.new("ShaderNodeMath")
    sqrt_disc.location = (2740, 190)
    sqrt_disc.operation = "SQRT"
    links.new(max_disc.outputs[0], sqrt_disc.inputs[0])

    neg_b = _multiply_socket(node_tree, links, b, -1.0, (2960, 90))
    numerator = _add_sockets(node_tree, links, neg_b, sqrt_disc.outputs[0], (3180, 140))
    denominator = _multiply_socket(node_tree, links, a, 2.0, (2960, 300))
    denominator_max = node_tree.nodes.new("ShaderNodeMath")
    denominator_max.location = (3180, 300)
    denominator_max.operation = "MAXIMUM"
    denominator_max.inputs[1].default_value = 1e-6
    links.new(denominator, denominator_max.inputs[0])

    root = node_tree.nodes.new("ShaderNodeMath")
    root.location = (3400, 220)
    root.operation = "DIVIDE"
    links.new(numerator, root.inputs[0])
    links.new(denominator_max.outputs[0], root.inputs[1])

    safe_root = node_tree.nodes.new("ShaderNodeMath")
    safe_root.location = (3620, 220)
    safe_root.operation = "MAXIMUM"
    safe_root.inputs[1].default_value = 1e-6
    links.new(root.outputs[0], safe_root.inputs[0])

    fac = node_tree.nodes.new("ShaderNodeMath")
    fac.location = (3840, 220)
    fac.operation = "DIVIDE"
    fac.inputs[0].default_value = 1.0
    links.new(safe_root.outputs[0], fac.inputs[1])
    return fac.outputs[0]


def _apply_spread_method(node_tree, links, fac_socket, spread_method: str):
    normalized = (spread_method or "pad").lower()
    if normalized == "repeat":
        fract = node_tree.nodes.new("ShaderNodeMath")
        fract.location = (4060, 220)
        fract.operation = "FRACT"
        links.new(fac_socket, fract.inputs[0])
        return fract.outputs[0]

    if normalized == "reflect":
        modulo = node_tree.nodes.new("ShaderNodeMath")
        modulo.location = (4060, 280)
        modulo.operation = "MODULO"
        modulo.inputs[1].default_value = 2.0
        links.new(fac_socket, modulo.inputs[0])

        subtract = node_tree.nodes.new("ShaderNodeMath")
        subtract.location = (4280, 280)
        subtract.operation = "SUBTRACT"
        subtract.inputs[1].default_value = 1.0
        links.new(modulo.outputs[0], subtract.inputs[0])

        absolute = node_tree.nodes.new("ShaderNodeMath")
        absolute.location = (4500, 280)
        absolute.operation = "ABSOLUTE"
        links.new(subtract.outputs[0], absolute.inputs[0])

        reflect = node_tree.nodes.new("ShaderNodeMath")
        reflect.location = (4720, 280)
        reflect.operation = "SUBTRACT"
        reflect.inputs[0].default_value = 1.0
        links.new(absolute.outputs[0], reflect.inputs[1])
        return reflect.outputs[0]

    return fac_socket


def _configure_color_ramp(color_ramp, gradient: SVGGradient) -> None:
    stops = gradient.stops or []
    while len(color_ramp.elements) > 2:
        color_ramp.elements.remove(color_ramp.elements[-1])
    while len(color_ramp.elements) < 2:
        color_ramp.elements.new(1.0)

    if not stops:
        color_ramp.elements[0].position = 0.0
        color_ramp.elements[0].color = (0.8, 0.8, 0.8, 1.0)
        color_ramp.elements[1].position = 1.0
        color_ramp.elements[1].color = (0.2, 0.2, 0.2, 1.0)
        return

    first = stops[0]
    color_ramp.elements[0].position = first.offset
    color_ramp.elements[0].color = first.color

    if len(stops) == 1:
        color_ramp.elements[1].position = 1.0
        color_ramp.elements[1].color = first.color
        return

    color_ramp.elements[1].position = stops[-1].offset
    color_ramp.elements[1].color = stops[-1].color
    for stop in stops[1:-1]:
        element = color_ramp.elements.new(stop.offset)
        element.color = stop.color


def _local_bounds_svg(obj: bpy.types.Object, scale: float) -> tuple[float, float, float, float]:
    points: list[tuple[float, float]] = []
    for spline in obj.data.splines:
        if spline.type == "BEZIER":
            for bezier_point in spline.bezier_points:
                points.append((float(bezier_point.co.x) / scale, -float(bezier_point.co.y) / scale))
        else:
            for point in spline.points:
                points.append((float(point.co.x) / scale, -float(point.co.y) / scale))

    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return (min(xs), min(ys), max(xs), max(ys))


def _offset_component(node_tree, links, socket, value: float, location):
    node = node_tree.nodes.new("ShaderNodeMath")
    node.location = location
    node.operation = "SUBTRACT"
    node.inputs[1].default_value = value
    links.new(socket, node.inputs[0])
    return node.outputs[0]


def _multiply_socket(node_tree, links, socket, value: float, location):
    node = node_tree.nodes.new("ShaderNodeMath")
    node.location = location
    node.operation = "MULTIPLY"
    node.inputs[1].default_value = value
    links.new(socket, node.inputs[0])
    return node.outputs[0]


def _multiply_sockets(node_tree, links, left_socket, right_socket, location):
    node = node_tree.nodes.new("ShaderNodeMath")
    node.location = location
    node.operation = "MULTIPLY"
    links.new(left_socket, node.inputs[0])
    links.new(right_socket, node.inputs[1])
    return node.outputs[0]


def _add_sockets(node_tree, links, left_socket, right_socket, location):
    node = node_tree.nodes.new("ShaderNodeMath")
    node.location = location
    node.operation = "ADD"
    links.new(left_socket, node.inputs[0])
    links.new(right_socket, node.inputs[1])
    return node.outputs[0]


def _subtract_sockets(node_tree, links, left_socket, right_socket, location):
    node = node_tree.nodes.new("ShaderNodeMath")
    node.location = location
    node.operation = "SUBTRACT"
    links.new(left_socket, node.inputs[0])
    links.new(right_socket, node.inputs[1])
    return node.outputs[0]


def _sum_of_squares(node_tree, links, x_socket, y_socket, location):
    x2 = _multiply_sockets(node_tree, links, x_socket, x_socket, location)
    y2 = _multiply_sockets(node_tree, links, y_socket, y_socket, (location[0], location[1] - 100))
    return _add_sockets(node_tree, links, x2, y2, (location[0] + 220, location[1] - 50))
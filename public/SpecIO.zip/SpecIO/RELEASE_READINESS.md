# SpecIO Test Matrix and Release-Readiness Checklist

This document defines the minimum validation bar for shipping a SpecIO release.

It separates:

- automated checks that should pass on every release candidate
- manual checks that confirm Blender UX and extension packaging behavior
- known coverage boundaries so releases do not imply unsupported SVG behavior

## Release Gate Summary

Treat a build as release-ready only when all of the following are true:

- pure Python regression tests pass
- Blender headless smoke tests pass for all supported scenarios
- the one-command validation runner completes successfully
- optional visual roundtrip regression passes for the current complex sample gate
- clean-profile extension validate, build, install, runtime check, and removal smoke passes
- extension manifest metadata is aligned with addon metadata
- install, enable, import, export, and uninstall work in Blender 5.1+
- no new unsupported behavior is exposed in the UI without documentation
- README and release notes describe the current supported SVG subset accurately

## Automated Test Matrix

### Pure Python Regression Tests

Preferred one-command workflow:

```powershell
python scripts/validate.py
```

Expanded release-candidate workflow:

```powershell
python scripts/validate.py --with-visual-roundtrip --with-package-smoke
```

Run from the repository root:

```powershell
python -m unittest tests.test_svg_gradients tests.test_svg_path_parser tests.test_svg_document tests.test_svg_style tests.test_svg_transform
```

| Area | File | What it validates | Release expectation |
| --- | --- | --- | --- |
| Gradient helpers | `tests/test_svg_gradients.py` | Gradient stop parsing, href inheritance, spread behavior, and managed-gradient payload helpers | Must pass |
| Path parsing | `tests/test_svg_path_parser.py` | Absolute and relative commands, H/V, cubic, smooth cubic, quadratic to cubic normalization, arcs, malformed trailing input | Must pass |
| SVG document assembly | `tests/test_svg_document.py` | Nested groups, deterministic ordering, bounds, viewBox, path presentation attributes | Must pass |
| Style helpers | `tests/test_svg_style.py` | Style parsing, inheritance merge, hidden content filtering, color parsing, stroke and fill metadata, practical curve display mapping | Must pass |
| Transform helpers | `tests/test_svg_transform.py` | SVG transform parsing, composition, and coordinate mapping helpers | Must pass |

### Blender Headless Smoke Tests

Run from the repository root:

```powershell
blender -b --factory-startup --python tests/blender_smoke.py -- --scenario all
```

The smoke runner currently covers these scenarios:

| Scenario | Primary goal | Expected release result |
| --- | --- | --- |
| `path-rich` | Import and export mixed relative, line, and cubic path content | `FINISHED` import and export |
| `rotated-arc` | Import rotated elliptical arc data as BEZIER and export as cubic path data | `FINISHED` import and export |
| `large-arc` | Validate large-arc flag handling and cubic segment expansion | `FINISHED` import and export |
| `compound-fill` | Confirm implicit fill closure and multi-spline hole handling for compound shapes | `FINISHED` import |
| `height-offsets` | Validate flat, per-object, and per-layer Z placement for imported SVG content | `FINISHED` import with expected offsets |
| `scene-defaults-reset` | Confirm the reset operator reapplies addon or RNA defaults to the active scene settings | `FINISHED` operator result |
| `collection-hierarchy` | Preserve collection to SVG group hierarchy on roundtrip | `FINISHED` import and export |
| `malformed-input` | Confirm parse failures cancel cleanly without creating data | `CANCELLED` import with explicit parse failure |
| `style-roundtrip` | Preserve style metadata and practical stroke display behavior | `FINISHED` import and export |
| `gradient-material` | Rebuild imported gradient materials with stable node-tree state | `FINISHED` import and export |
| `managed-gradient-export` | Export SpecIO-managed gradient materials back to SVG defs and paint references | `FINISHED` export |
| `multi-spline-export` | Export deterministic path ids for multi-spline curve objects | `FINISHED` import and export |
| `hierarchy-order-roundtrip` | Preserve original group ids and sibling order through import and export loops | `FINISHED` import, export, and reimport |
| `sample-camera-roundtrip` | Stress roundtrip geometry, styles, gradients, and hierarchy on a real-world sample | `FINISHED` import, export, and reimport |
| `transform-stack-roundtrip` | Stress nested transforms and stable group survival on the transform torture fixture | `FINISHED` import, export, and reimport |

### Visual Roundtrip Regression

Run from the repository root:

```powershell
blender -b --factory-startup --python tests/blender_visual_roundtrip.py
```

This regression currently uses `sample_svgs/AJ_Digital_Camera.svg` as the default visual gate and compares imported versus roundtripped renders with bounded pixel-drift thresholds.

### Packaging Validation

Run before tagging a release:

```powershell
blender --command extension validate
blender --command extension build
python scripts/package_smoke.py --blender "C:/Program Files/Blender Foundation/Blender 5.1/blender.exe"
```

Packaging validation must confirm:

- `blender_manifest.toml` is valid
- built extension packaging completes without warnings that affect installation
- release zip installs in Blender 5.1+
- clean-profile install, enable, operator registration, export, and removal all succeed

## Manual Test Matrix

Manual testing is required because current automated coverage does not fully exercise Blender UI behavior, extension installation flow, or unsupported SVG handling feedback.

| Area | Test | Expected result |
| --- | --- | --- |
| Install and enable | Install built extension zip in a clean Blender 5.1+ profile | Extension installs and enables without manual fixes |
| Uninstall and disable | Disable and remove the extension | No orphaned errors on restart |
| N-panel UX | Open the SVG panel in a clean scene and populated scene | Panel draws cleanly, operators are available, no broken controls |
| Import operator | Import a supported SVG through the file picker | Objects and collections are created predictably |
| Export operator | Export selected supported objects through the file picker | SVG file is written with deterministic output |
| Raster image behavior | Import an SVG containing local-file and embedded `<image>` elements, then export with both `Embed` and `Link` image modes | Imported images become textured planes and export preserves usable `<image>` references |
| Undo behavior | Undo immediately after import and export | Scene returns to prior state cleanly |
| Selection behavior | Export with mixed selection and with no selected curves | Curves export correctly; invalid selection reports a clear error |
| Style display | Inspect imported colored and stroked curves in viewport and object data | Display color, bevel depth, caps, and material assignment match documented behavior |
| Hierarchy behavior | Import nested groups with and without ids | Collections are created deterministically and export groups remain stable |
| Scene defaults | Change scene settings, run `Reset Scene Defaults`, and compare against addon preferences | Active scene settings return to the documented defaults |

## Metadata Alignment Checklist

Before release, confirm these values are aligned across files:

- addon version in `__init__.py`
- extension version in `blender_manifest.toml`
- transitional version in `manifest.json`
- minimum Blender version in `__init__.py`, `blender_manifest.toml`, and `manifest.json`
- project URLs, maintainer, and release packaging metadata

## Known Coverage Boundaries

Do not describe these areas as fully supported in a release unless code and tests are added first:

- comprehensive SVG unit and layout handling beyond the validated transform fixtures and sample files
- full SVG paint-server reconstruction beyond the current `linearGradient` and `radialGradient` support
- exact roundtrip preservation of original nested group ids in every duplicate-id or malformed-id case
- dedicated automated smoke coverage for raster image import/export paths
- optional `svgelements` backend integration
- broad SVG feature coverage outside the currently supported group, shape, path, gradient, and raster-image subset
- full support for `text`, `use`, `clipPath`, `mask`, filters, animation, and script content
- remote raster image URL imports
- user-facing summaries for skipped unsupported SVG content

## Release-Readiness Checklist

Use this checklist for the final release candidate review.

### Code and Tests

- [ ] `python scripts/validate.py` passes locally
- [ ] `python scripts/validate.py --with-visual-roundtrip --with-package-smoke` passes locally for release candidates
- [ ] Pure Python regression tests pass locally
- [ ] Blender smoke suite passes with `--scenario all`
- [ ] No workspace diagnostics are introduced by the release changes
- [ ] New features include regression coverage where practical
- [ ] Unsupported behavior is either hidden from UI or documented clearly

### Packaging and Metadata

- [ ] `blender --command extension validate` passes
- [ ] `blender --command extension build` produces the release artifact
- [ ] `__init__.py`, `blender_manifest.toml`, and `manifest.json` versions match
- [ ] Blender minimum version is consistent across metadata files
- [ ] Permissions in `blender_manifest.toml` are still minimal and accurate

### Product Behavior

- [ ] Import works for the supported SVG subset described in the README
- [ ] Export works for selected supported curve and raster image objects
- [ ] Malformed SVG fails cleanly with a useful error
- [ ] Undo works after import and export operations
- [ ] Style-aware roundtrip behavior matches the documented feature set
- [ ] Group hierarchy behavior is stable and documented within current limits
- [ ] Raster image handling matches the documented local-file and embedded-image behavior

### Documentation and Release Notes

- [ ] README reflects the current Blender baseline and supported SVG subset
- [ ] Any removed or renamed files are no longer referenced in docs
- [ ] Release notes call out new support, changed behavior, and known limits
- [ ] Release notes do not imply transform or unit support that does not exist

### Final Manual Signoff

- [ ] Install the built extension in a clean Blender 5.1+ profile
- [ ] Enable the extension and verify the SVG panel appears
- [ ] Run one import and one export end-to-end through the UI
- [ ] Disable and uninstall cleanly
- [ ] Archive command output or notes for the release record

## Recommended Release Order

1. Run pure Python tests.
2. Run Blender smoke tests.
3. Validate and build the extension artifact.
4. Perform manual install, UI, import, export, and undo checks in Blender.
5. Verify documentation and release notes.
6. Tag and publish only after all checklist items are complete.
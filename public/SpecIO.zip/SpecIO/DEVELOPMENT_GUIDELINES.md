# SpecIO Development Guidelines

This document defines the working development baseline for SpecIO.

SpecIO is a Blender 5.1+ SVG import and export addon. The repository is no longer aligned to a Blender 4.3-era addon layout, so development guidance should match the current extension packaging workflow, current module structure, and current validation commands.

## Project Baseline

- Target Blender 5.1 and newer.
- Treat SpecIO as an SVG pipeline addon, not a generic Blender UI sandbox.
- Keep import and export behavior predictable, debuggable, and safe to undo.
- Prefer a narrower, tested SVG feature set over broad but weakly validated claims.

## Current Repository Structure

```text
SpecIO/
|-- __init__.py
|-- blender_manifest.toml
|-- manifest.json
|-- README.md
|-- RELEASE_READINESS.md
|-- io_svg/
|   |-- __init__.py
|   |-- curve_builder.py
|   |-- document.py
|   |-- exporter.py
|   |-- formatting.py
|   |-- importer.py
|   |-- path_parser.py
|   `-- style.py
|-- operators/
|   |-- __init__.py
|   |-- svg_importer.py
|   `-- svg_operators.py
|-- panels/
|   |-- __init__.py
|   `-- svg_panel.py
|-- properties/
|   |-- __init__.py
|   `-- svg_properties.py
|-- scripts/
|   `-- validate.py
`-- tests/
    |-- blender_smoke.py
    |-- test_svg_document.py
    |-- test_svg_path_parser.py
    `-- test_svg_style.py
```

## Packaging and Metadata

### Required Metadata Files

- `blender_manifest.toml` is the primary extension manifest for Blender 5.1+
- `__init__.py` contains `bl_info` for addon metadata compatibility
- `manifest.json` remains in the repo as transitional metadata and must stay aligned

### Metadata Rules

- Keep version values aligned across `__init__.py`, `blender_manifest.toml`, and `manifest.json`
- Keep the Blender minimum version aligned across all metadata files
- Keep extension permissions minimal and accurate
- Update project URLs and maintainer values consistently when they change

### Packaging Commands

Run from the repository root:

```powershell
blender --command extension validate
blender --command extension build
```

## Registration and Module Boundaries

### Registration Order

Maintain strict registration order:

1. properties
2. operators
3. panels

Unregister in reverse order.

### Separation of Concerns

- `panels/` draws UI only
- `operators/` handles Blender operator flow, validation, reporting, and undo boundaries
- `io_svg/` contains SVG parsing, formatting, style, import, export, and document helpers
- `properties/` owns scene properties and addon preferences

Avoid moving SVG parsing or serialization logic back into panels or operator `execute()` methods.

## Naming and API Conventions

### Blender Types

- Operators: `SPECIO_OT_<action_name>`
- Panels: `SPECIO_PT_<panel_name>`
- Property groups: descriptive `SpecIO...Properties`
- Operator ids: `specio.<action_name>`

### Scene State

Per-scene settings belong on `context.scene.specio` through a `PointerProperty`.

Use addon preferences only for persistent addon-wide defaults or optional behaviors. Do not scatter new top-level `Scene` properties outside the grouped `specio` property set.

## SVG Scope and Expectations

### Supported Import Shapes

The current importer supports these shape categories:

- `rect`
- `circle`
- `ellipse`
- `line`
- `polyline`
- `polygon`
- `path`
- `g`
- `svg`

The importer also applies affine SVG transforms on supported geometry and group hierarchies.

### Supported Path Commands

The current parser and importer support:

- `M` and `m`
- `L` and `l`
- `H` and `h`
- `V` and `v`
- `C` and `c`
- `S` and `s`
- `Q` and `q`
- `T` and `t`
- `A` and `a`
- `Z` and `z`

Smooth quadratic and arc content is normalized to cubic segments for Blender curve handling and SVG export.

### Supported Export Scope

The current exporter supports:

- selected Blender curve objects only
- poly and bezier spline export as SVG path data
- deterministic ordering and deterministic per-spline ids
- collection hierarchy export through SVG `g` elements where supported
- style metadata export for supported presentation attributes

### Known Unsupported or Partial Areas

Do not describe these as fully supported unless implementation and tests are added:

- general SVG unit conversion on import
- full viewBox-aware import transforms
- separate simultaneous fill and stroke gradient reconstruction, gradient export, and broader paint-server coverage beyond imported `linearGradient` and `radialGradient`
- exact preservation of original nested group ids in every export case
- optional `svgelements` runtime integration
- complete user-facing summaries for skipped unsupported SVG elements

## Code Quality Standards

### Style

- Follow PEP 8
- Keep formatting Black-friendly
- Use 4 spaces for indentation
- Use type hints for new or materially changed functions
- Add docstrings for public classes and non-trivial helpers

### Complexity

- Prefer early returns over deep nesting
- Keep logical nesting to roughly 4 levels or less
- Extract parsing and conversion branches into helpers when functions grow large

### Error Handling

- Validate file paths before reading or writing
- Raise or report actionable errors
- Use `self.report()` for Blender operator feedback
- Do not use bare `except:` blocks
- Treat SVG input as untrusted data

### Data Integrity

- Preserve undo behavior for import and export operations
- Do not create Blender data blocks for degenerate geometry
- Do not silently mutate unrelated user scene state
- Avoid unnecessary use of `bpy.ops` where direct data API access is sufficient

## UI Guidance

- Keep the N-panel compact and task-oriented
- Only expose controls that correspond to implemented behavior
- Avoid expensive work in `draw()` methods
- Group controls into import, export, and addon sections
- Use Blender terminology and accurate tooltips

If a setting is exposed in the UI, it should either affect behavior or be clearly documented as not yet wired. Hidden dead settings are preferable to misleading UI.

## Testing Workflow

### One-Command Validation

Run the full automated validation suite from the repository root:

```powershell
python scripts/validate.py
```

Optional examples:

```powershell
python scripts/validate.py --scenario style-roundtrip
python scripts/validate.py --blender "C:/Program Files/Blender Foundation/Blender 5.1/blender.exe"
```

The validation runner executes:

1. Pure Python regression tests
2. Blender headless smoke tests

### Direct Test Commands

Pure Python regression tests:

```powershell
python -m unittest tests.test_svg_path_parser tests.test_svg_document tests.test_svg_style
```

Blender headless smoke tests:

```powershell
blender -b --factory-startup --python tests/blender_smoke.py -- --scenario all
```

### Smoke Scenarios Currently Covered

- `path-rich`
- `rotated-arc`
- `large-arc`
- `collection-hierarchy`
- `malformed-input`
- `style-roundtrip`
- `multi-spline-export`
- `all`

### Manual Validation Expectations

Before release, also verify:

- extension install and enable in a clean Blender 5.1+ profile
- panel visibility and operator availability
- import via file picker
- export via file picker
- undo behavior after import and export
- uninstall and disable flow

See `RELEASE_READINESS.md` for the release checklist and validation matrix.

## Documentation Expectations

- Keep `README.md` aligned with the actual supported SVG subset
- Remove references to deleted files or retired workflows
- Update `RELEASE_READINESS.md` when the validation surface changes
- If you add or remove supported SVG behavior, update docs in the same change

## Recommended Change Review Checklist

Before finishing a substantive change, verify:

- the code matches the Blender 5.1+ baseline
- metadata values remain aligned
- registration and unregistration still work
- tests were added or updated where practical
- UI does not overstate unsupported functionality
- release docs still describe the current behavior truthfully
        raise ValueError("File must have .svg extension")
    
    try:
        # Parse SVG file
        tree = ET.parse(filepath)
        root = tree.getroot()
        
    except ET.ParseError as e:
        raise ValueError(f"Invalid SVG file format: {e}")
    
    except PermissionError:
        raise PermissionError(f"Permission denied accessing: {filepath}")
    
    try:
        # Process SVG elements
        objects = []
        for element in root:
            obj = process_svg_element(element, context)
            if obj:
                objects.append(obj)
        
        if not objects:
            raise RuntimeError("No valid SVG elements found to import")
        
        return objects
        
    except Exception as e:
        # Clean up any partially created objects
        cleanup_failed_import(objects)
        raise RuntimeError(f"SVG import failed: {e}")
```

**User-Friendly Error Messages:**
```python
class SPECIO_OT_import_svg(Operator):
    def execute(self, context):
        try:
            objects = import_svg_file(self.filepath, context)
            self.report({'INFO'}, f"Successfully imported {len(objects)} objects")
            return {'FINISHED'}
            
        except FileNotFoundError:
            self.report({'ERROR'}, "SVG file not found. Please check the file path.")
            return {'CANCELLED'}
            
        except ValueError as e:
            self.report({'ERROR'}, f"Invalid SVG file: {str(e)}")
            return {'CANCELLED'}
            
        except PermissionError:
            self.report({'ERROR'}, "Permission denied. Check file permissions.")
            return {'CANCELLED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {str(e)}")
            return {'CANCELLED'}
```

## Testing Guidelines

### Unit Testing Structure

**Test Organization:**
```
tests/
├── __init__.py
├── test_svg_importer.py
├── test_svg_operators.py
├── test_properties.py
└── test_data/
    ├── simple_rect.svg
    ├── complex_path.svg
    └── invalid.svg
```

**Test Implementation:**
```python
import unittest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os

class TestSVGImporter(unittest.TestCase):
    """Test SVG import functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.importer = SVGImporter()
        self.test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    
    def test_import_simple_rectangle(self):
        """Test importing simple rectangle SVG"""
        svg_path = os.path.join(self.test_data_dir, 'simple_rect.svg')
        
        # Mock Blender context
        mock_context = Mock()
        mock_context.collection = Mock()
        
        with patch('bpy.data.curves.new') as mock_curve_new:
            with patch('bpy.data.objects.new') as mock_object_new:
                result = self.importer.import_file(svg_path, mock_context)
                
                # Verify object creation was called
                mock_curve_new.assert_called_once()
                mock_object_new.assert_called_once()
                
                # Verify result
                self.assertIsInstance(result, list)
                self.assertGreater(len(result), 0)
    
    def test_invalid_svg_file(self):
        """Test handling of invalid SVG file"""
        invalid_path = os.path.join(self.test_data_dir, 'invalid.svg')
        mock_context = Mock()
        
        with self.assertRaises(ValueError):
            self.importer.import_file(invalid_path, mock_context)
    
    def test_nonexistent_file(self):
        """Test handling of nonexistent file"""
        mock_context = Mock()
        
        with self.assertRaises(FileNotFoundError):
            self.importer.import_file("nonexistent.svg", mock_context)
```

### Manual Testing Checklist

**Functional Testing:**
- [ ] Import various SVG file types (shapes, paths, groups)
- [ ] Export curves to SVG format
- [ ] Test roundtrip import/export consistency
- [ ] Verify UI responsiveness and feedback
- [ ] Test with different scale factors and resolutions
- [ ] Validate error handling with invalid files

**Compatibility Testing:**
- [ ] Test with Blender 4.3.0 minimum version
- [ ] Test with latest stable Blender release
- [ ] Verify addon installation/uninstallation
- [ ] Test with different operating systems
- [ ] Validate with various Blender scene configurations

**Performance Testing:**
- [ ] Test with large SVG files (>1MB)
- [ ] Test with complex SVG paths (>1000 points)
- [ ] Measure import/export times
- [ ] Check memory usage during operations
- [ ] Test UI responsiveness during long operations

## Performance Guidelines

### UI Performance

**Avoid Expensive Operations in draw() Methods:**
```python
# Good: Cache expensive computations
class SPECIO_PT_svg_info(Panel):
    def draw(self, context):
        layout = self.layout
        
        # Use cached or pre-computed values
        if hasattr(context.scene, 'specio_svg_info'):
            info = context.scene.specio_svg_info
            layout.label(text=f"Objects: {info.object_count}")
        else:
            layout.label(text="No SVG data")

# Avoid: Expensive computation in draw()
class SPECIO_PT_svg_info(Panel):
    def draw(self, context):
        layout = self.layout
        
        # Don't do this - expensive operation on every redraw
        svg_objects = [obj for obj in context.scene.objects 
                      if obj.name.startswith("SVG_")]
        layout.label(text=f"Objects: {len(svg_objects)}")
```

**Lazy Loading:**
```python
class SVGProcessor:
    """SVG processor with lazy loading"""
    
    def __init__(self):
        self._svgelements = None
    
    @property
    def svgelements(self):
        """Lazy load SVGElements library"""
        if self._svgelements is None:
            try:
                from .libs import svgelements
                self._svgelements = svgelements
            except ImportError:
                self._svgelements = False
        return self._svgelements
```

### Memory Management

**Clean Up Resources:**
```python
def import_large_svg(filepath: str, context: Context) -> List[Object]:
    """Import large SVG with proper cleanup"""
    temp_objects = []
    created_materials = []
    
    try:
        # Processing logic
        for element in svg_elements:
            obj = create_object_from_element(element)
            temp_objects.append(obj)
            
            # Track created resources
            if obj.data.materials:
                created_materials.extend(obj.data.materials)
        
        return temp_objects
        
    except Exception as e:
        # Clean up on failure
        for obj in temp_objects:
            bpy.data.objects.remove(obj, do_unlink=True)
        
        for mat in created_materials:
            bpy.data.materials.remove(mat, do_unlink=True)
        
        raise e
```

**Efficient Data Structures:**
```python
# Good: Use appropriate data structures
def build_element_lookup(svg_root):
    """Build efficient lookup table for SVG elements"""
    lookup = {}  # Dictionary for O(1) lookups
    
    for element in svg_root.iter():
        element_id = element.get('id')
        if element_id:
            lookup[element_id] = element
    
    return lookup

# Avoid: Inefficient linear searches
def find_element_by_id(svg_root, target_id):
    """Avoid - inefficient O(n) search"""
    for element in svg_root.iter():
        if element.get('id') == target_id:
            return element
    return None
```

## Security Considerations

### Input Validation

**File Path Validation:**
```python
def validate_file_path(filepath: str) -> bool:
    """Validate file path for security"""
    # Resolve path to prevent directory traversal
    resolved_path = os.path.realpath(filepath)
    
    # Check if file exists and is readable
    if not os.path.exists(resolved_path):
        raise FileNotFoundError(f"File not found: {filepath}")
    
    if not os.access(resolved_path, os.R_OK):
        raise PermissionError(f"Cannot read file: {filepath}")
    
    # Validate file extension
    if not resolved_path.lower().endswith('.svg'):
        raise ValueError("Only SVG files are allowed")
    
    return True
```

**SVG Content Validation:**
```python
def sanitize_svg_content(svg_content: str) -> str:
    """Sanitize SVG content to prevent security issues"""
    # Remove potentially dangerous elements
    dangerous_tags = ['script', 'object', 'embed', 'iframe']
    
    for tag in dangerous_tags:
        # Remove script tags and content
        pattern = f'<{tag}[^>]*>.*?</{tag}>'
        svg_content = re.sub(pattern, '', svg_content, flags=re.IGNORECASE | re.DOTALL)
        
        # Remove self-closing tags
        pattern = f'<{tag}[^>]*/?>'
        svg_content = re.sub(pattern, '', svg_content, flags=re.IGNORECASE)
    
    return svg_content
```

### Safe Resource Limits

**Limit Resource Usage:**
```python
MAX_SVG_FILE_SIZE = 50 * 1024 * 1024  # 50MB
MAX_ELEMENTS_PER_SVG = 10000
MAX_PATH_POINTS = 50000

def validate_svg_complexity(svg_root):
    """Validate SVG complexity to prevent resource exhaustion"""
    element_count = len(list(svg_root.iter()))
    
    if element_count > MAX_ELEMENTS_PER_SVG:
        raise ValueError(f"SVG too complex: {element_count} elements (max: {MAX_ELEMENTS_PER_SVG})")
    
    # Count path points
    total_points = 0
    for path in svg_root.iter('{http://www.w3.org/2000/svg}path'):
        path_data = path.get('d', '')
        points = count_path_points(path_data)
        total_points += points
    
    if total_points > MAX_PATH_POINTS:
        raise ValueError(f"SVG too complex: {total_points} path points (max: {MAX_PATH_POINTS})")
```

This comprehensive development guidelines document provides the foundation for consistent, high-quality development of the SpecIO Blender addon, ensuring compatibility with Blender 4.3+ and adherence to industry best practices.
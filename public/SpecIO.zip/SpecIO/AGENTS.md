# SpecIO Blender Addon Development Rules

## Purpose

SpecIO is a Blender 5.1+ SVG import/export addon. This file defines how agents should change the codebase so the addon stays compatible with Blender's extension model, preserves SVG fidelity, and remains maintainable as the importer and exporter mature.

Use this file as the repo-specific source of truth for AI-assisted development. Prefer these rules over generic Blender addon advice when there is a conflict.

## Project Priorities

- Keep the addon compatible with Blender 5.1 and newer.
- Treat this as an SVG pipeline addon, not a generic UI experiment.
- Preserve user data and scene state during import and export.
- Prefer predictable behavior and debuggable code over ambitious but fragile features.
- Make incremental improvements that move the addon toward a robust importer/exporter architecture.

## Current Repository Shape

The current repository is small and modular:

- `__init__.py`: addon entry point and registration order.
- `operators/`: operators plus the current importer implementation.
- `panels/`: N-panel UI.
- `properties/`: scene properties and addon preferences.
- `libs/`: optional third-party code.

This structure is acceptable for now, but future work should keep import/export parsing logic separate from UI and operator glue. If the importer or exporter grows, move pure SVG parsing and serialization code into dedicated modules instead of making operator files larger.

## Blender 5.1+ Baseline

### Extension Packaging

- Target Blender 5.1+ first, not Blender 4.3 compatibility first.
- Follow the modern Blender extension workflow.
- Prefer the official `blender_manifest.toml` format for extension packaging in Blender 5.1+.
- Keep addon metadata aligned across packaging files and `bl_info` when both are present.
- Use semantic versioning for addon releases.
- Keep permission declarations minimal and accurate.
- If bundled Python dependencies are required, prefer wheel-based distribution that matches Blender's supported extension packaging model.

### Python Compatibility

- Assume Blender 5.1 ships with Python 3.13.
- Avoid relying on deprecated Python behavior or old compatibility shims.
- Use standard library modules when possible before adding dependencies.
- Any third-party dependency must be justified by clear SVG handling value and packaging feasibility.

### API Compatibility

- Avoid deprecated Blender API patterns when adding new code.
- Check context assumptions carefully in operators, panels, and object creation code.
- Prefer explicit and stable Blender data access over shortcuts that depend on UI state.
- When touching compatibility-sensitive areas, design for Blender 5.1 behavior first and only retain older behavior if it adds little maintenance cost.

## Architecture Rules

### Separation of Concerns

- Panels draw UI only.
- Operators coordinate Blender interaction, validation, undo boundaries, and reporting.
- Import and export logic should live in pure or mostly pure Python helpers where possible.
- SVG parsing, coordinate conversion, naming, style handling, and geometry conversion should be isolated into focused helpers instead of being mixed into one large method.

### Preferred Module Direction

As the addon grows, prefer a structure like this:

- `operators/`: Blender operators only.
- `panels/`: UI panels only.
- `properties/`: scene settings and preferences only.
- `svg/` or `io_svg/`: SVG parsing, serialization, transforms, units, style handling, and conversion helpers.
- `libs/`: vendored optional libraries only.

Do not force this refactor for tiny changes, but move in this direction whenever a feature would otherwise increase coupling.

### Registration Order

Keep registration order strict:

1. properties
2. operators
3. panels

Unregister in reverse order.

### Naming Conventions

- Operators: `SPECIO_OT_<action_name>`
- Panels: `SPECIO_PT_<panel_name>`
- Property groups: `SpecIO<PropertyArea>Properties`
- Preferences: `SpecIOPreferences`
- Operator ids: `specio.<action_name>`

Use descriptive names tied to SVG behavior. Avoid vague names like `process_data`, `handle_item`, or `do_import`.

## Properties and Preferences

### Scene State

- Prefer grouped scene state through a `PointerProperty` on `bpy.types.Scene` for new work.
- Avoid scattering many top-level `Scene` properties when a cohesive property group is more maintainable.
- Keep per-scene import/export settings separate from addon-wide preferences.

### Addon Preferences

- Use addon preferences for defaults, optional library toggles, debug behavior, and persistent user choices.
- Scene properties should represent the values used by the active file or current operation.
- New settings must include clear names, descriptions, defaults, and bounds when applicable.

### Validation

- Validate property ranges before performing import or export work.
- Clamp or reject invalid user input with helpful reports.
- Do not silently ignore settings that materially affect geometry or file output.

## SVG Import Standards

### Import Goals

Imported SVG data should produce Blender objects that are:

- correctly named
- organized predictably
- geometrically faithful within documented limits
- safe to undo
- usable for further Blender editing

### Minimum Import Expectations

When improving the importer, prefer this support order:

1. `svg`, `g`, `path`
2. `rect`, `circle`, `ellipse`, `line`, `polyline`, `polygon`
3. transforms, viewBox, units, and nested group transforms
4. Bezier curve fidelity for path commands
5. style-aware import where it affects geometry or object organization

### Geometry Rules

- Honor SVG coordinate systems intentionally. Document every conversion between SVG space and Blender space.
- Support `viewBox` and width and height units correctly when possible.
- Apply nested transforms in the correct order.
- Prefer generating curve data directly instead of converting through temporary meshes unless there is a strong reason.
- Closed SVG shapes should become closed splines when appropriate.
- Bezier data should stay Bezier where fidelity matters.
- Do not create invalid Blender data blocks for empty or degenerate SVG elements.

### Naming and Hierarchy

- Preserve SVG ids when they are valid and useful.
- Use deterministic fallback names when ids are missing.
- Preserve group hierarchy with Blender collections when possible.
- Avoid name collisions by using predictable suffixing instead of random names.

### Error Handling

- Fail per file with a clear message when the SVG cannot be parsed.
- Skip unsupported or malformed elements gracefully when partial import is reasonable.
- Surface a useful summary to the user when elements were skipped, simplified, or approximated.
- Do not use bare `except:` blocks.

## SVG Export Standards

### Export Goals

Exported SVG should be readable by common vector tools and should preserve as much curve intent as practical from Blender curve objects.

### Minimum Export Expectations

- Export selected supported curve objects only, unless the operator explicitly offers a broader scope.
- Convert Blender spline data into valid SVG elements or path data.
- Respect user-configured scale and numeric precision.
- Preserve closed curves as closed SVG path output.
- Write deterministic output so repeated exports are stable when scene data is unchanged.

### Export Rules

- Prefer path output when it preserves more geometry than simpler SVG primitives.
- Keep numeric formatting stable and avoid unnecessary decimal noise.
- Validate output file paths and extensions before writing.
- Never overwrite files silently if Blender's file selector or operator flow expects confirmation.
- When style export is unsupported, keep geometry export correct rather than inventing incomplete style behavior.

## Blender UI Rules

### Panels

- Keep the N-panel compact and task-oriented.
- Group controls into import, export, and utility sections.
- Avoid expensive computation in `draw()`.
- Use sub-panels or boxed sections when settings start to grow.
- Only expose controls that are implemented or clearly marked as not yet implemented.

### Operators

- Most file and geometry-changing operators should use `{'REGISTER', 'UNDO'}`.
- `execute()` should validate state early and return quickly on invalid input.
- Use `self.report()` for user-facing success, warning, and error messages.
- Long-running work should provide progress feedback when practical.

### UX Consistency

- Use Blender terminology where possible.
- Tooltips should explain the actual behavior, not restate the label.
- Do not add flashy UI behavior that does not help import/export workflows.

## Code Quality Rules

### General Style

- Follow PEP 8 and keep formatting Black-friendly.
- Use 4 spaces for indentation.
- Use type hints for new or materially changed functions.
- Add docstrings for public classes and non-trivial helpers.
- Prefer small focused functions over monolithic operator methods.

### Complexity Limits

- Prefer early returns over deep nesting.
- Keep logical nesting to about 4 levels or less.
- Extract parsing branches or geometry builders into helpers when one function starts handling multiple SVG element types.

### Logging and Diagnostics

- Use structured, actionable error messages.
- Use `self.report()` for user feedback and plain logging or print only when there is a real debugging reason.
- Do not leave noisy debug output in normal addon behavior.

## Performance Rules

- Avoid repeated collection lookups and data-block creation when results can be reused safely.
- Be careful with large SVG files containing many path segments.
- Minimize mode switches and unnecessary context-dependent Blender ops.
- Prefer direct data API usage over `bpy.ops` when creating or editing objects programmatically.
- Avoid work in panel drawing that scales with scene size.

## Safety and Data Integrity

- Validate all file paths before reading or writing.
- Treat SVG input as untrusted data.
- Do not execute embedded scripts or external references from SVG files.
- Handle malformed XML, unsupported commands, and missing attributes gracefully.
- Do not delete or relink user objects unless the operator clearly owns the created data.
- Keep undo behavior correct for all scene mutations.

## Testing Expectations

### Validation Commands

- Use `python scripts/test_quick.py` after meaningful code changes as the default validation step.
- Use `python scripts/test_full.py` when a change touches registration, packaging, install or enable flow, manifests, release checks, or other extension-lifecycle behavior.
- If you need a narrower Blender run while iterating, pass through the existing `scripts/validate.py` flags such as `--scenario style-roundtrip` to `scripts/test_quick.py`.
- Do not treat a change as complete until the appropriate validation command has been run successfully.

### Manual Testing

For meaningful importer or exporter changes, test at least these scenarios when feasible:

- import a simple SVG with rect, circle, ellipse, and path
- import nested groups with ids
- import a file with missing ids
- import malformed SVG and confirm clear failure behavior
- export simple Bezier and poly splines
- export closed and open curves
- verify undo after import and export operations
- verify panel behavior in a clean scene and a populated scene

### Automated Testing

- Add pure Python tests for parsing, unit conversion, path tokenization, and serialization logic when that logic can be isolated from Blender runtime.
- Keep Blender-dependent logic thin enough that the hardest logic can still be tested outside Blender.
- If a parser bug is fixed, add a regression test or at least document the input shape that failed.

## Dependency Rules

- Optional libraries must have a graceful fallback path.
- Vendored libraries in `libs/` must be clearly isolated from project code.
- Do not add a dependency if a focused standard-library implementation is sufficient.
- Before depending on a library for SVG parsing, evaluate packaging compatibility with Blender 5.1 extension distribution.

## Review Checklist For Changes

Before finishing a change, verify:

- Blender 5.1+ assumptions are still valid.
- Metadata and version values remain aligned.
- Registration and unregistration are still correct.
- UI only exposes implemented functionality.
- Import or export changes preserve undo behavior.
- File handling and error reporting are explicit.
- New SVG behavior is documented in code or README when needed.
- The change improves the importer or exporter at the root cause instead of layering workarounds on top.

## Anti-Patterns To Avoid

- Do not put parsing logic directly in panel code.
- Do not grow `execute()` into the whole import/export engine.
- Do not rely on ad hoc object naming that changes between runs.
- Do not hide unsupported SVG behavior without warning when it affects output meaningfully.
- Do not add placeholder buttons or settings without clearly scoping follow-up work.
- Do not introduce compatibility hacks for old Blender versions unless explicitly required.

## Guidance For AI Agents Working In This Repo

- Make small, defensible changes unless a broader refactor is clearly required.
- If you touch addon metadata, check both packaging metadata and `bl_info`.
- If you touch operators or panels, check whether properties and preferences still line up.
- After making updates, run `python scripts/test_quick.py` at minimum. If the change affects installation, registration, packaging, or release readiness, run `python scripts/test_full.py` instead.
- If you improve SVG support, prefer correctness for a narrower supported subset over claiming broad support with weak fidelity.
- If a change reveals that the repo still reflects Blender 4.3-era assumptions, update the relevant guidance or metadata instead of reinforcing outdated patterns.

The standard for this repository is not just "works in Blender". The standard is "works predictably in Blender 5.1+, is packageable as an extension, and behaves like a serious SVG import/export tool."
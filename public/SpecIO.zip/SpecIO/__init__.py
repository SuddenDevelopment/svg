"""SpecIO Blender addon entry point for Blender 5.1+."""

bl_info = {
    "name": "SpecIO",
    "description": "SVG Import and Export Tools for Blender",
    "author": "SuddenDevelopment",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "3D Viewport > Sidebar > SVG Tab",
    "category": "Import-Export",
    "support": "COMMUNITY",
    "doc_url": "https://github.com/SuddenDevelopment/SpecIO",
    "tracker_url": "https://github.com/SuddenDevelopment/SpecIO/issues",
}

import bpy
from . import panels, operators, properties


def register():
    """Register all addon components"""
    properties.register()
    operators.register()
    panels.register()


def unregister():
    """Unregister all addon components"""
    panels.unregister()
    operators.unregister()
    properties.unregister()


if __name__ == "__main__":
    register()